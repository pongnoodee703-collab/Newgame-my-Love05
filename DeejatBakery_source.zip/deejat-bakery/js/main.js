'use strict';
/* =====================================================================
   main.js — เริ่มเกม: โหลดค่า, ผูกปุ่ม, จัดการจอมือถือ
   ===================================================================== */

/* ความสูงจอจริง (แก้ปัญหา 100vh บน iPhone/Android ที่แถบเบราว์เซอร์ยุบ-ขยาย)
   แถบเบราว์เซอร์ยุบ-ขยายยิง resize ถี่มาก → รวมเป็นครั้งเดียวต่อเฟรม และข้ามถ้าความสูงไม่เปลี่ยน
   (ทุกอย่างที่ใช้ --vh ต้องคำนวณใหม่ทั้งหน้า จึงไม่ควรอัปเดตบ่อยเกินจำเป็น) */
let _vh = 0, _vhQ = 0;
function applyVH() {
  _vhQ = 0;
  const h = Math.round((window.visualViewport && window.visualViewport.height) || window.innerHeight);
  if (!h || h === _vh) return;
  _vh = h;
  document.documentElement.style.setProperty('--vh', h * .01 + 'px');
}
function setVH() { if (!_vhQ) _vhQ = requestAnimationFrame(applyVH); }

function boot() {
  applyVH();
  addEventListener('resize', setVH);
  addEventListener('orientationchange', () => setTimeout(setVH, 300));
  if (window.visualViewport) visualViewport.addEventListener('resize', setVH);

  safeCall(() => Settings.load(), 'Settings.load');
  safeCall(() => Progress.load(), 'Progress.load');
  document.body.classList.toggle('calm', Settings.d.calm);   // ก่อนสร้างรูปเชฟ เพื่อเลือกรูปขยับ/นิ่งให้ถูก
  document.body.classList.toggle('lite', Env.lite);          // เครื่องสเปกต่ำ: ปิดแอนิเมชันตกแต่ง เล่นลื่นขึ้น
  // แต่ละส่วนเริ่มแยกกัน: ถ้าส่วนตกแต่งพัง ปุ่มและตัวเกมยังใช้ได้
  safeCall(() => Assets.init(), 'Assets.init');
  safeCall(() => Chars.refresh(), 'Chars.refresh');
  safeCall(() => G.init(), 'G.init');
  safeCall(() => StageFit.init(), 'StageFit.init');
  safeCall(() => StartScreen.init(), 'StartScreen.init');
  safeCall(() => Shop.init(), 'Shop.init');
  safeCall(() => BackNav.init(), 'BackNav.init');
  safeCall(() => HowTo.init(), 'HowTo.init');
  safeCall(() => Coach.init(), 'Coach.init');
  safeCall(() => Tutor.init(), 'Tutor.init');
  safeCall(() => WallShelf.init(), 'WallShelf.init');
  safeCall(() => Pests.init(), 'Pests.init');

  /* แตะเชฟ = ดีใจ */
  $('#char').addEventListener('click', () => { Chars.mood('cheer', 900); Sound.play('tap'); vibrate(10); });

  /* แตะครั้งแรก → เปิดเสียง + เพลง (iOS/Android ต้องให้ผู้เล่นแตะก่อน) */
  const first = () => {
    Sound.unlock(); Sound.startMusic();
    ['pointerdown', 'touchend', 'keydown'].forEach(ev => document.removeEventListener(ev, first, true));
  };
  ['pointerdown', 'touchend', 'keydown'].forEach(ev => document.addEventListener(ev, first, true));

  /* สลับแอป/ล็อกจอ → พักเสียง ; กลับมา → เล่นต่อ */
  document.addEventListener('visibilitychange', () => { document.hidden ? Sound.pause() : Sound.wake(); });
  addEventListener('pagehide', () => Sound.pause());
  addEventListener('pageshow', () => Sound.wake());

  /* กันซูม/เมนูค้างกดที่ทำให้เล่นสะดุดบนมือถือ */
  document.addEventListener('gesturestart', e => e.preventDefault());           // iOS pinch
  document.addEventListener('contextmenu', e => { if (e.target.closest('#screen-game,.draggable,.ing')) e.preventDefault(); });
  document.addEventListener('dblclick', e => e.preventDefault(), { passive: false });

  /* ปุ่มนำทาง */
  // เข้าเกม (กดเริ่มเกมครั้งแรกของการเปิดเกมแต่ละครั้ง): แนะนำวิธีเล่นก่อน แล้วค่อยไปหน้าเลือกเมนู
  $('#btn-play').onclick = () => { Sound.play('ding'); HowTo.shown ? Screens.show('menu') : HowTo.open(() => Screens.show('menu')); };
  $('#btn-set-start').onclick = () => { buildSettings(); openModal('settings'); };
  $('#menu-back').onclick = () => { Sound.play('click'); Screens.show('start'); };
  $('#game-back').onclick = () => { G.abort(); Sound.play('click'); Screens.show('menu'); };
  $('#res-again').onclick = () => { Sound.play('click'); G.r ? G.start(G.r.id) : Screens.show('menu'); };
  $('#res-menu').onclick = () => { Sound.play('click'); Screens.show('menu'); };
  // แพ้ → เริ่มเมนูเดิมใหม่ตั้งแต่ขั้นแรก หรือกลับไปเลือกเมนู
  $('#lose-again').onclick = () => { Sound.play('click'); G.r ? G.start(G.r.id) : Screens.show('menu'); };
  $('#lose-menu').onclick = () => { G.abort(); Sound.play('click'); Screens.show('menu'); };
  $('#btn-book').onclick = () => { buildBook(); openModal('book'); };
  $$('[data-open="settings"]').forEach(b => (b.onclick = () => { buildSettings(); openModal('settings'); }));
  $$('[data-close]').forEach(b => (b.onclick = closeModals));
  $$('.overlay').forEach(o => o.addEventListener('pointerdown', e => { if (e.target === o) closeModals(); }));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModals(); });

  /* ตั้งค่า */
  $('#s-music').oninput = e => Settings.set('music', +e.target.value);
  $('#s-sfx').oninput = e => Settings.set('sfx', +e.target.value);
  $('#s-sfx').onchange = () => Sound.play('ding');
  $('#s-mute').onchange = e => Settings.set('mute', e.target.checked);
  $('#s-hap').onchange = e => { Settings.set('haptics', e.target.checked); vibrate(30); };
  $('#s-cap').onchange = e => Settings.set('captions', e.target.checked);
  $('#s-hint').onchange = e => Settings.set('hints', e.target.checked);
  $('#s-calm').onchange = e => Settings.set('calm', e.target.checked);
  $$('#s-assist button').forEach(b => (b.onclick = () => {
    if (b.dataset.v === Settings.d.assist) return;
    Settings.set('assist', b.dataset.v); buildSettings(); Sound.play('click');
    if (Screens.is('menu')) buildMenu();                 // ป้าย "🎯 ความยาก: ..." บนหัวหน้าเลือกเมนูเปลี่ยนตามทันที (เดิมค้างค่าเก่า)
  }));

  /* ภาษา ไทย / English (อยู่ในหน้าตั้งค่า) */
  $$('#s-lang button').forEach(b => (b.onclick = () => {
    if (b.dataset.v === Settings.d.lang) return;
    Settings.set('lang', b.dataset.v); Sound.play('ding'); vibrate(10); buildSettings();
  }));
  $('#s-reset').onclick = () => {
    const b = $('#s-reset');
    if (b.dataset.armed !== '1') { b.dataset.armed = '1'; b.textContent = t('set.confirm'); setTimeout(() => { b.dataset.armed = ''; if (b.textContent !== t('set.cleared')) b.textContent = t('set.reset'); }, 2500); return; }
    b.dataset.armed = ''; Progress.best = {}; Progress.save(); Sound.play('pop'); b.textContent = t('set.cleared');
    if (Screens.is('menu')) buildMenu();
  };

  safeCall(() => Settings.apply(), 'Settings.apply');
}

/* เปิดให้ทดสอบ/ดีบักจากคอนโซลได้ เช่น DeejatBakery.G.start('cookie') (NJ ยังใช้ได้เหมือนเดิม) */
window.DeejatBakery = window.NJ = { G, Settings, Progress, Sound, Screens, RECIPES, Safe, HowTo, Tutor, Pests, Conveyor, Helpers, WallShelf, CookFx, StageFit, KitchenLayout, VERSION };
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
