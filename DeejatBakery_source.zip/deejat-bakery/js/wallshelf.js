'use strict';
/* =====================================================================
   wallshelf.js — ชั้นวางขนมบนผนังครัว (ขนมของเมนู + ของทำขนม + ขนมปังอบ) เล่นได้ทุกด่าน
   - ปัด/ลากซ้าย-ขวา = เลื่อนชั้น: ของวิ่งวน พ้นขอบด้านหนึ่งแล้วโผล่อีกด้าน
     ปัดแรงแล้วปล่อย = ไหลต่อแล้วค่อย ๆ หยุด ; หมุนล้อเมาส์ก็เลื่อนได้ ; ของเอนตามแรงตอนเลื่อน
   - ลากของขึ้น/ลงออกจากชั้น = หยิบมาขยับเล่นได้ทั่วจอ ปล่อยแล้วลอยกลับที่เดิม (ปล่อยบนชั้น = ย้ายช่อง)
   - แตะของ = เด้งดึ๋ง + ลูกเล่นเล็ก ๆ (ไข่ → ลูกเจี๊ยบ 🐣, นม → 💧, น้ำผึ้ง → 🐝 ...)
   - แตะที่ว่างบนชั้น = ของทั้งชั้นกระโดดเป็นคลื่น ; ตอนสายพานวัตถุดิบกระโดด ชั้นบนผนังก็กระโดดตาม
   - ตำแหน่ง/ขนาดชั้น: stage.js (StageFit + KitchenLayout) วางบนผนังข้างภาพทำอาหาร หรือแถวบนสุดใต้กันสาด
     แล้วจัดฉากทำอาหารให้อยู่ใต้ชั้นพอดี → ชั้นไม่ทับภาพทำอาหารทุกด่าน ทุกขนาดจอ (ที่แคบ = เห็นน้อยช่องลง ปัดดูที่เหลือ)
   - ประสิทธิภาพ: มีลูป rAF เฉพาะตอนลาก/ไหล/ลอยกลับ ตอนนิ่งไม่มีลูปเลย ;
     ขยับด้วย translate/transform อย่างเดียว ; วัดขนาดตอนจัดฉาก (เริ่มขั้น/เปลี่ยนขนาดจอ) เท่านั้น
   - เป็นของตกแต่ง ไม่มีผลกับคะแนน/การแพ้ (แตะทะลุไปปัดของแปลกปลอมได้ เพราะชั้นแมลงอยู่ข้างบน)
   ===================================================================== */
const WS_FX = { '🥚': '🐣', '🥛': '💧', '🍯': '🐝', '🧈': '✨', '🍮': '💛', '🍓': '💗', '🍒': '💗', '🧁': '✨', '🍪': '😋', '🍫': '😋', '🌾': '✨',
  '🥐': '✨', '🍞': '😋', '🍩': '💗', '🥖': '✨', '🥨': '😋', '🥯': '✨' };

const WallShelf = {
  el: null, items: [], off: 0, L: 0, gapX: 0, slot: 0, W: 0, pl: 0,
  raf: 0, last: 0, fling: 0, vx: 0, lean: 0, sliding: false, dirty: false,
  ghost: null, gIt: null, gx: 0, gy: 0, gdx: 0, gdy: 0, hx: 0, hy: 0,

  init() {
    const el = this.el = $('.wshelf');
    if (!el) return;
    el.addEventListener('pointerdown', e => safeCall(() => this.down(e), 'WallShelf'));
    el.addEventListener('wheel', e => {
      const d = Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
      if (!d || !this.ready()) return;
      e.preventDefault();
      this.fling = 0; this.off -= clamp(d, -100, 100) * .5; this.dirty = true; this.run();
    }, { passive: false });
    // เปลี่ยนขนาดจอ: StageFit จัดฉาก → KitchenLayout วางชั้นใหม่ แล้วเรียก layout() ให้เอง (ไม่วัดซ้ำที่นี่)
  },

  /* เริ่มเมนูใหม่: วางของของเมนูนั้นบนชั้น (วัดขนาดหลังหน้าครัวแสดงแล้ว) */
  start(list) {
    this.stop();
    const el = this.el;
    if (!el) return;
    el.innerHTML = list.map(e => `<i>${e}</i>`).join('');
    this.items = Array.from(el.children);
    this.off = 0; this.L = 0; this.key = '';
    requestAnimationFrame(() => safeCall(() => this.layout(), 'WallShelf'));
  },
  ready() { if (!this.L) this.layout(); return !!this.L; },

  /* L = ความยาวหนึ่งรอบของชั้น (อย่างน้อยกว้างกว่าช่องมองเห็น 1 ช่อง ของจะได้ไม่โผล่กลางชั้น) */
  layout() {
    const el = this.el, k = this.items;
    if (!el || !k.length || !el.offsetParent) { this.L = 0; return; }   // ชั้นถูกซ่อนบนจอนี้
    const cs = getComputedStyle(el);
    this.pl = parseFloat(cs.paddingLeft) || 0;
    this.W = el.clientWidth - this.pl - (parseFloat(cs.paddingRight) || 0);
    this.slot = k[0].offsetWidth + 6;
    if (!this.slot || this.W <= 0) { this.L = 0; return; }
    // ระยะห่างของเท่ากันเสมอ ; ถ้ารอบยาวกว่าของทั้งหมด ช่องว่างที่เหลือรวมเป็นช่องเดียวอยู่นอกจอตอนเริ่ม
    this.L = Math.max(k.length * this.slot, this.W + this.slot);
    this.gapX = this.slot;
    // ขนาดชั้นเปลี่ยน (เมนูใหม่/หมุนจอ/จำนวนช่องที่เห็นเปลี่ยน) → เริ่มโดยชิ้นแรกชิดขอบซ้าย ; ขนาดเดิม (เปลี่ยนขั้น) = ค้างตำแหน่งที่ผู้เล่นเลื่อนไว้
    const key = this.L.toFixed(1) + '|' + this.W.toFixed(1);
    if (key !== this.key) { this.key = key; this.off = this.L - this.W; }
    this.place();
  },
  pos(i) {
    let x = (i * this.gapX + this.off) % this.L;
    if (x < 0) x += this.L;
    return x - (this.L - this.W);
  },
  place() {
    if (!this.L) return;
    this.items.forEach((it, i) => { it.style.translate = (this.pl + this.pos(i)).toFixed(1) + 'px 0'; });
  },
  setLean(d) {
    d = clamp(Math.round(d * 2) / 2, -12, 12);
    if (d === this.lean || !this.el) return;
    this.lean = d;
    this.el.style.setProperty('--wl', d + 'deg');
  },

  /* แตะ = เด้ง ; ลากแนวนอน = เลื่อนชั้น ; ลากขึ้น/ลงจากตัวของ = หยิบมาขยับ */
  down(e) {
    if (e.button > 0 || !this.ready() || this.ghost) return;
    e.preventDefault();
    Sound.unlock();
    const t = e.target, it = t && t.parentElement === this.el ? t : null;
    const id = e.pointerId, sx = e.clientX, sy = e.clientY, o0 = this.off;
    let mode = '', lx = sx, lt = performance.now();
    this.fling = 0; this.vx = 0;
    const mv = ev => {
      if (ev.pointerId !== id) return;
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (!mode) {
        if (Math.hypot(dx, dy) < 7) return;
        mode = it && Math.abs(dy) > Math.abs(dx) * .8 ? 'lift' : 'slide';
        if (mode === 'lift') this.lift(it, sx, sy); else this.sliding = true;
        this.run();
      }
      if (mode === 'slide') {
        const now = performance.now(), dt = Math.max(1, now - lt);
        this.vx = this.vx * .6 + ((ev.clientX - lx) / dt * 1000) * .4; lx = ev.clientX; lt = now;
        this.off = o0 + dx; this.dirty = true;
      } else { this.gx = ev.clientX; this.gy = ev.clientY; }
    };
    const up = ev => {
      if (ev.pointerId !== id) return;
      removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
      if (!mode) {
        if (ev.type === 'pointerup') it ? this.boing(it) : this.wave(true);   // แตะของ = เด้ง ; แตะที่ว่างบนชั้น = ทั้งชั้นกระโดด
        return;
      }
      if (mode === 'slide') {
        this.sliding = false;
        if (Env.motion && Math.abs(this.vx) > 200 && performance.now() - lt < 90) this.fling = clamp(this.vx, -1500, 1500);
        this.run();
      } else this.drop();
    };
    addEventListener('pointermove', mv, { passive: true });
    addEventListener('pointerup', up);
    addEventListener('pointercancel', up);
  },

  /* หยิบของออกจากชั้น: ตัวจริงซ่อนไว้ ตัวที่ลากเป็นสำเนาลอยตามนิ้ว (ไม่โดนขอบชั้นตัด) */
  lift(it, x, y) {
    const r = it.getBoundingClientRect(), host = $('#screen-game'), hr = host.getBoundingClientRect();
    const g = document.createElement('i');
    g.className = 'wghost'; g.textContent = it.textContent; g.setAttribute('aria-hidden', 'true');
    g.style.fontSize = getComputedStyle(it).fontSize;
    host.appendChild(g);
    this.ghost = g; this.gIt = it; this.hx = hr.left; this.hy = hr.top;
    this.gdx = x - r.left; this.gdy = y - r.top; this.gx = x; this.gy = y;
    it.classList.add('away');
    Sound.play('pop'); vibrate(8);
    this.paintGhost();
  },
  paintGhost() {
    if (!this.ghost) return;
    const x = this.gx - this.gdx - this.hx, y = this.gy - this.gdy - this.hy;
    this.ghost.style.transform = `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) rotate(-8deg) scale(1.25)`;
  },
  /* ปล่อยเหนือชั้น = ย้ายของไปวางช่องนั้น (ของข้าง ๆ ขยับหลบ) ; ปล่อยที่อื่น = ลอยกลับที่เดิม แล้วเด้ง */
  drop() {
    const g = this.ghost, it = this.gIt;
    if (!g) return;
    this.ghost = null;
    const fin = () => {
      if (!g.isConnected) return;
      g.remove(); it.classList.remove('away');
      if (it.isConnected) this.boing(it, true);
    };
    const sr = this.el.getBoundingClientRect(), hr = $('#screen-game').getBoundingClientRect();
    if (this.gx > sr.left - 12 && this.gx < sr.right + 12 && this.gy > sr.top - 36 && this.gy < sr.bottom + 24) this.moveTo(it, this.gx - sr.left - this.pl);
    const r = it.getBoundingClientRect(), x = sr.left + this.pl + this.pos(this.items.indexOf(it));
    const to = `translate3d(${(x - hr.left).toFixed(1)}px,${(r.top - hr.top).toFixed(1)}px,0) rotate(0deg) scale(1)`;
    if (!Env.motion) { fin(); return; }
    const a = g.animate([{ transform: g.style.transform }, { transform: to }], { duration: 420, easing: 'cubic-bezier(.3,1.35,.5,1)', fill: 'forwards' });
    a.onfinish = fin;
    setTimeout(fin, 650);                                // กันค้าง ถ้าเฟรมไม่ถูกวาด
  },

  /* ย้ายของไปช่องที่ใกล้จุดปล่อยที่สุด (ในช่วงที่มองเห็น) — ของที่อยู่ระหว่างทางเลื่อนไปทีละช่องแบบนุ่ม ๆ */
  moveTo(it, lx) {
    const k = this.items, i = k.indexOf(it), w = it.offsetWidth;
    let best = i, bd = Infinity;
    for (let j = 0; j < k.length; j++) {
      const c = this.pos(j) + w / 2;
      if (c < 0 || c > this.W) continue;
      const d = Math.abs(c - lx);
      if (d < bd) { bd = d; best = j; }
    }
    if (best === i || i < 0) return;
    k.splice(i, 1); k.splice(best, 0, it);
    this.el.classList.add('settle');
    clearTimeout(this._st); this._st = setTimeout(() => this.el && this.el.classList.remove('settle'), 340);
    this.place();
  },

  /* เล่นท่าเด้ง/กระโดดใหม่ทุกครั้ง โดยไม่บังคับคำนวณเลย์เอาต์ (ถอดท่าเดิม แล้วใส่ใหม่ใน 2 เฟรมถัดไป) */
  hop(it, cls = 'hop') {
    it.classList.remove('hop', 'jump');
    cancelAnimationFrame(it._r); clearTimeout(it._t);
    // นับเวลาถอดท่าหลังใส่ท่าแล้ว (ถ้าเฟรมถูกหน่วงตอนสลับแอป ท่าจะไม่ค้างอยู่)
    it._r = requestAnimationFrame(() => { it._r = requestAnimationFrame(() => { it.classList.add(cls); it._t = setTimeout(() => it.classList.remove(cls), 760); }); });
  },
  /* ทั้งชั้นกระโดดเป็นคลื่นจากซ้ายไปขวา (แตะที่ว่างบนชั้น หรือสายพานวัตถุดิบกระโดดพร้อมกัน) */
  wave(loud) {
    if (!this.items.length || !this.L || !Env.motion) return;
    this.items.map((it, i) => [it, this.pos(i)]).sort((a, b) => a[1] - b[1])
      .forEach(([it], k) => { clearTimeout(it._w); it._w = setTimeout(() => this.hop(it, 'jump'), k * 70); });
    if (loud) { Sound.play('pop'); vibrate(10); }
  },
  /* แตะของ = เด้งดึ๋ง + ลูกเล่นตามของ */
  boing(it, quiet) {
    this.hop(it);
    if (quiet) return;
    Sound.play('pop'); vibrate(8);
    const fx = WS_FX[it.textContent];
    if (fx && Env.motion) {
      const r = it.getBoundingClientRect(), k = $('#kitchen').getBoundingClientRect();
      puff($('#kitchen'), fx, r.left - k.left + r.width * .2, r.top - k.top - 6, 10, { size: '1.4rem', life: 900 });
    }
  },

  /* ลูปทำงานเฉพาะตอนมีอะไรขยับ แล้วหยุดเองเมื่อนิ่ง */
  run() {
    if (this.raf) return;
    this.last = performance.now();
    const loop = now => {
      const dt = Math.min(.05, (now - this.last) / 1000); this.last = now;
      if (this.fling) {
        this.off += this.fling * dt;
        this.fling *= Math.pow(.05, dt);
        if (Math.abs(this.fling) < 12) this.fling = 0;
        this.dirty = true;
      }
      this.setLean(this.sliding ? -this.vx * .012 : this.fling ? -this.fling * .01 : this.lean * Math.max(0, 1 - dt * 8));
      if (this.dirty) { this.dirty = false; this.place(); }
      if (this.ghost) this.paintGhost();
      if (this.sliding || this.fling || this.ghost || this.lean) this.raf = requestAnimationFrame(loop);
      else this.raf = 0;
    };
    this.raf = requestAnimationFrame(loop);
  },

  /* ออกจากครัว/เปลี่ยนเมนู: หยุดลูป เก็บของที่ลากค้าง */
  stop() {
    cancelAnimationFrame(this.raf); this.raf = 0;
    this.fling = 0; this.sliding = false; this.vx = 0;
    if (this.ghost) { this.ghost.remove(); this.ghost = null; }
    $$('.wghost').forEach(g => g.remove());
    if (this.gIt) { this.gIt.classList.remove('away'); this.gIt = null; }
    this.setLean(0);
  }
};
