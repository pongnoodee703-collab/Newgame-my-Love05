'use strict';
/* =====================================================================
   assets.js — ไฟล์ภาพของเกม (ตัวละครเชฟ GIF)
   - ตอนเปิดจากโฟลเดอร์: โหลดจาก assets/
   - ตอนเป็นไฟล์เดียว (dist): build.py ฝังไฟล์ไว้ใน window.NJ_INLINE_ASSETS
     แล้วแปลงเป็น blob URL ครั้งเดียว ทุกตัวละครใช้รูปเดียวกัน (ประหยัดหน่วยความจำ)
   อยากเปลี่ยนตัวละคร: แทนที่ assets/chef.gif (และ chef-still.png) แล้วแก้ CHEF_W/CHEF_H
   ===================================================================== */
const ASSET_FILES = {
  chef: { path: 'assets/chef.gif', type: 'image/gif' },             // ตัวละครขยับ
  chefStill: { path: 'assets/chef-still.png', type: 'image/png' }   // ท่านิ่ง (โหมดลดการเคลื่อนไหว)
};
const CHEF_W = 367, CHEF_H = 594;     // ขนาดรูปจริง (ใช้จองพื้นที่ก่อนรูปโหลดเสร็จ จอไม่กระตุก)

function b64ToBlob(b64, type) {
  const bin = atob(b64), n = bin.length, u = new Uint8Array(n);
  for (let i = 0; i < n; i++) u[i] = bin.charCodeAt(i);
  return new Blob([u], { type });
}

const Assets = {
  urls: {},
  init() {
    const inl = window.NJ_INLINE_ASSETS || {};
    Object.keys(ASSET_FILES).forEach(k => {
      const f = ASSET_FILES[k];
      let u = f.path;
      if (inl[k]) {
        try { u = URL.createObjectURL(b64ToBlob(inl[k], f.type)); }
        catch (e) { u = `data:${f.type};base64,${inl[k]}`; }
      }
      this.urls[k] = u;
    });
    window.NJ_INLINE_ASSETS = null;          // คืนหน่วยความจำของข้อความ base64
    [this.urls.chef, this.urls.chefStill].forEach(u => { const i = new Image(); i.decoding = 'async'; i.src = u; });

    /* ถ้ารูปโหลดไม่ได้ (เช่น ลืมโฟลเดอร์ assets) → ใช้ท่านิ่ง → ถ้ายังไม่ได้ ใช้อีโมจิแทน เกมไม่พัง */
    document.addEventListener('error', e => {
      const im = e.target;
      if (!im || !im.classList || !im.classList.contains('chef-img')) return;
      if (im.dataset.fallback !== '1' && im.getAttribute('src') !== this.urls.chefStill) {
        im.dataset.fallback = '1'; im.src = this.urls.chefStill;
      } else {
        im.hidden = true;
        if (im.parentNode && im.parentNode.classList) im.parentNode.classList.add('missing');
      }
    }, true);
  },
  chefSrc() { return Env.motion ? this.urls.chef : this.urls.chefStill; },
  chefHTML() {
    return `<img class="chef-img" src="${this.chefSrc()}" width="${CHEF_W}" height="${CHEF_H}" alt="" draggable="false" decoding="async">`;
  },
  /* สลับรูปขยับ/รูปนิ่ง เมื่อเปิด-ปิดโหมดลดการเคลื่อนไหว */
  sync() {
    const s = this.chefSrc();
    $$('img.chef-img').forEach(i => { if (i.getAttribute('src') !== s) { i.dataset.fallback = ''; i.src = s; } });
  }
};
