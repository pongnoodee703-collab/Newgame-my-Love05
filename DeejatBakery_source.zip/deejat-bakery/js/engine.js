'use strict';
/* =====================================================================
   engine.js — ตัวควบคุมเกม: เริ่มเมนู → โหลดทีละขั้น → ให้ดาว → สรุปผล
   ===================================================================== */
/* ห้องครัวเบเกอรี่ของแต่ละเมนู: th = [สีอ่อน, สีเข้ม] ของกันสาด/ผ้าม่าน (สีเดียวกับการ์ดเมนู)
   shelf = ชั้นวางขนมบนผนัง (ขนมของเมนู + ของทำขนม + ขนมปังอบ — มากกว่าช่องที่เห็น ต้องปัดเลื่อนดู) ; ชิ้นแรก = ขนมของเมนู (ใช้บนกระดานชอล์ก) */
const THEMES = {
  custard: { th: ['#f2c07a', '#c27f36'], shelf: ['🍮', '🥚', '🥛', '🍯', '🧈', '🥐', '🍞'], sign: 'Pudding Time 🍮' },
  cupcake: { th: ['#f4a9ba', '#cf6f8b'], shelf: ['🧁', '🍓', '🥛', '🧈', '🍒', '🍩', '🥖'], sign: 'Cupcake Party 🧁' },
  cookie:  { th: ['#c99467', '#7a4b2c'], shelf: ['🍪', '🥛', '🍫', '🧈', '🌾', '🥨', '🥯'], sign: 'Naughty Cookies 😈' }
};

const G = {
  r: null, i: 0, S: {}, scores: [], busy: false, cleanup: null, mech: null, base: '', timer: null, firstDrop: false,

  init() {
    const s = $('#stage');
    // ส่ง pointer event ของฉากไปให้กลไกที่กำลังเล่นอยู่ (stir / swipe)
    s.addEventListener('pointerdown', e => this.mech && this.mech.down(e));
    s.addEventListener('pointermove', e => this.mech && this.mech.move(e));
    s.addEventListener('pointerup', e => this.mech && this.mech.up(e));
    s.addEventListener('pointercancel', e => this.mech && this.mech.up(e));
  },

  /* จำนวนดาวจากจำนวนครั้งที่พลาด (โหมดง่ายพลาดได้ 2 ครั้งต่อ 1 ดาว) */
  stars(mist) {
    if (Tutor.on) return 3;                              // โหมดสอนเล่น: พลาดได้ ไม่เสียดาว
    return 3 - Math.min(2, Math.floor(mist / Settings.assist().forgive));
  },

  freshS() {
    return { scene: 'pot', fill: 0, liquid: '#f6f1e6', heat: false, boil: false, bake: 0, cups: [], items: this.r.items,
      dial: 0, hot: false, door: 0, baked: false, water: false, spoon: 0, spoonOn: false, sieve: false, sieveX: 0, dust: false, temp: '25°C' };
  },

  start(id) {
    this.abort();
    if (!RECIPES[id]) { Safe.report('G.start', 'unknown recipe ' + id); Screens.show('menu'); return; }
    this.r = RECIPES[id]; this.i = 0; this.scores = []; this.S = this.freshS();
    Tutor.begin(id);                                     // เมนูที่ยังไม่เคยทำจบ → โหมดสอนเล่น
    this.lives = Settings.assist().lives || 3;           // หัวใจ: ทำผิดเสีย 1 ดวง หมด = แพ้
    UI.lives(this.lives);
    $('#lose').hidden = true;
    $('#g-name').textContent = this.r.name;
    const T = THEMES[id] || THEMES.custard, K = $('#kitchen');
    K.style.setProperty('--th', T.th[0]); K.style.setProperty('--th2', T.th[1]);
    K.dataset.theme = id;
    WallShelf.start(T.shelf);                            // ชั้นวางขนมบนผนัง: ปัดเลื่อน/หยิบ/แตะเล่นได้ (js/wallshelf.js)
    $('#sign').textContent = T.sign;
    // กระดานชอล์กเมนูวันนี้: ขนมทั้ง 3 เมนู + ราคา (เมนูที่กำลังทำขีดเส้นใต้)
    $('#chalk-list').innerHTML = Object.values(RECIPES).map(r =>
      `<li class="${r.id === id ? 'on' : ''}">${(THEMES[r.id] || THEMES.custard).shelf[0]} ฿${+r.price || 0}</li>`).join('');
    Pests.clear(); Pests.firstTold = false; Conveyor.told = false;
    Screens.show('game');
    safeCall(() => Helpers.render(), 'Helpers.render');   // เพื่อน 2 ตัวยืนช่วยข้างเตา
    safeCall(() => UI.levelBanner(), 'levelBanner');     // ป้าย ด่าน + ความยาก + ความท้าทาย
    safeCall(() => Chars.refresh(), 'Chars.refresh');
    this.load();
  },

  abort() {
    clearTimeout(this.timer);
    Coach.hide(); Tutor.stop(); Pests.clear(); Conveyor.stop(); Helpers.hush(); WallShelf.stop(); CookFx.stop(); UI.hideBanner();
    clearTimeout(UI.sayT);
    $('#lose').hidden = true;
    const c = this.cleanup;
    this.cleanup = null;
    if (c) safeCall(c, 'cleanup');
    $('#shelf').innerHTML = '';                          // ตู้โชว์ขนมบนสายพานก็เก็บด้วย
    this.mech = null; this.assist = null; this.busy = false;
  },

  /* โหลดขั้นตอน — ถ้าขั้นไหนพัง จะข้ามไปขั้นถัดไปให้เอง (ได้ 2 ดาว) แทนที่เกมจะค้าง */
  load() {
    try { this._load(); }
    catch (e) {
      Safe.report('step ' + this.i, e);
      this.busy = false;
      this.finish(2);
    }
  },

  _load() {
    const st = this.r.steps[this.i];
    this.busy = false;
    if (!st || !MECH[st.t]) throw new Error('bad step');
    CookFx.settle();                                     // ของที่เพิ่งใส่ขั้นก่อน: ระดับ/สีไปถึงค่าสุดท้ายก่อนเริ่มขั้นนี้
    const set = { ...(st.set || {}) };
    if (set.cupsN) { this.S.cups = Array.from({ length: set.cupsN }, () => ({})); delete set.cupsN; }
    Object.assign(this.S, set);
    this.base = st.say;
    clearTimeout(UI.sayT);
    UI.say(st.say);
    $('#tip').textContent = '💡 ' + st.tip;
    UI.dots(); UI.meter('off'); UI.instr('');
    $('#act').hidden = true;
    this.assist = null;                                  // กลไกของขั้นนี้ตั้งเอง ถ้าเพื่อนช่วยได้ (pests.js → Helpers.lend)
    this.cleanup = MECH[st.t](st);                       // ขั้นหยิบของ: MECH.drag วางวัตถุดิบบนสายพานเอง
    if (st.t !== 'drag') safeCall(() => Conveyor.showcase(), 'showcase');   // ขั้นอื่น: สายพานเป็นตู้โชว์ขนม (ชั้นไม่หาย จอไม่กระตุก)
    drawStage();
    StageFit.fit();
    Tutor.step(st);                                      // ด่านแรก (ครั้งแรก): ส่องไฟ + ป้ายสั้น ๆ + มือสาธิต ทุกขั้น
    Pests.step(st);                                      // แมลงก่อกวนระหว่างทำขนม (ตามด่าน/ความยาก)
  },

  finish(n) {
    if (this.busy) return;
    this.busy = true;
    Coach.hide(); Tutor.release(); Pests.clear(true);
    this.scores.push(n);
    const c = this.cleanup;
    this.cleanup = null;
    if (c) safeCall(c, 'cleanup');
    this.mech = null; this.assist = null;
    if (!$('#shelf').children.length) safeCall(() => Conveyor.showcase(), 'showcase');
    // ส่วนแสดงผล: ถ้าพังก็ไม่เป็นไร ขอแค่ไปขั้นต่อไปได้
    safeCall(() => {
      const st = this.r.steps[this.i] || {};
      Object.assign(this.S, st.done || {});
      drawStage();
      UI.instr('');
      Sound.play(n === 3 ? 'star' : 'ding');
      vibrate(n === 3 ? [20, 40, 20] : 20);
      Chars.mood(n > 1 ? 'cheer' : 'happy', 1500);
      Helpers.cheer();                                   // เพื่อน ๆ กระโดดดีใจด้วย
      UI.pstars(n, t('ps.' + n));
      const dot = $('#dots').children[this.i];
      if (dot) { dot.classList.remove('now'); dot.classList.add('done'); }
    }, 'finish');
    const r = this.r;
    this.timer = setTimeout(() => {
      if (this.r !== r || !Screens.is('game')) return;   // ผู้เล่นออกไปแล้ว
      this.i++;
      this.i >= r.steps.length ? safeCall(() => this.end(), 'end', null) : this.load();
    }, Settings.assist().next);
  },

  /* ทำผิด 1 ครั้ง (ใส่ของผิด / คนแรงเกิน): เสียหัวใจ 1 ดวง — หมดหัวใจ = แพ้ (โหมดสอนเล่นไม่เสียหัวใจ) */
  miss() {
    if (this.busy) return;
    Helpers.oops();
    if (Tutor.on) return;
    this.lives = Math.max(0, this.lives - 1);
    UI.lives(this.lives, true);
    if (this.lives <= 0) this.fail('mistakes');
  },

  /* แพ้: ขนมไหม้ ('burnt') / ไม่สุก ('raw') / ทำผิดจนหมดหัวใจ ('mistakes') / ของแปลกปลอมตกใส่ขนม ('dirty')
     → หน้าแพ้ ให้เริ่มเมนูนี้ใหม่ตั้งแต่ขั้นแรก
     ทุกโหมดรวมด่านฝึก: แพ้แล้วต้องเริ่มเมนูนี้ใหม่ (ด่านฝึกเริ่มใหม่ก็ยังสอนต่อ เพราะยังไม่เคยทำจบ) */
  fail(kind) {
    if (this.busy) return;
    this.busy = true;
    Coach.hide(); Tutor.release(); Pests.clear(true);
    const c = this.cleanup;
    this.cleanup = null;
    if (c) safeCall(c, 'cleanup');
    this.mech = null; this.assist = null;
    if (!$('#shelf').children.length) safeCall(() => Conveyor.showcase(), 'showcase');
    const r = this.r, retry = false;                     // ขนมไหม้/ปนเปื้อน = แพ้เสมอ (เดิมด่านฝึกแค่ลองขั้นเดิมใหม่)
    safeCall(() => {
      clearTimeout(UI.sayT);
      UI.say(t(retry ? 'tu.retry.' + kind : 'tm.' + kind));
      UI.instr('');
      Sound.play('fail'); vibrate([60, 40, 60]);
      Chars.mood('oops', 1800);
      if (kind === 'burnt') UI.smoke();
    }, 'fail');
    this.timer = setTimeout(() => {
      if (this.r !== r || !Screens.is('game')) return;   // ผู้เล่นออกไปแล้ว
      if (retry) this.load();                            // ลองขั้นเดิมอีกครั้ง
      else this.showLose(kind);
    }, retry ? 1700 : kind === 'burnt' ? 950 : 1300);   // ไหม้ = ควันขึ้นแล้วขึ้นหน้าแพ้เร็ว
  },

  showLose(kind) {
    this.lost = kind;
    $('#lose-ico').innerHTML = iconSVG(this.r.id);
    $('#lose').dataset.kind = kind;
    this.loseText();
    $('#lose').hidden = false;
    Sound.play('lose');
    safeCall(() => $('#lose-again').focus({ preventScroll: true }), 'focus');
  },
  loseText() {
    if (!this.lost) return;
    $('#lose-title').textContent = t('lose.' + this.lost + '.t');
    $('#lose-msg').textContent = t('lose.' + this.lost + '.d');
  },

  end() {
    const avg = this.scores.length ? this.scores.reduce((a, b) => a + b, 0) / this.scores.length : 1;
    const fin = this.fin = clamp(Math.round(avg) || 1, 1, 3), id = this.r.id;
    this.learned = Tutor.on; Tutor.stop();               // จบด่านฝึก → หน้าสรุปผลมีป้าย "ผ่านด่านฝึกแล้ว"
    Pests.clear(); Conveyor.stop(); Helpers.hush(); WallShelf.stop(); CookFx.stop(); $('#shelf').innerHTML = '';
    Progress.best[id] = Math.max(Progress.best[id] || 0, fin);
    Progress.save();
    $('#res-stars').innerHTML = [1, 2, 3].map(i => starSVG(i <= fin)).join('');
    this.showResult();
    Screens.show('result');
    Sound.play('win');
  },

  /* รูปขนม + เชฟ + ข้อความหน้าสรุปผล (เรียกซ้ำตอนสลับภาษา/เปลี่ยนเชฟ) */
  showResult() {
    if (!this.r) return;
    $('#res-ico').innerHTML = iconSVG(this.r.id) + `<span class="res-chef cbox">${charHTML(Settings.d.char, 'cheer')}</span>`;
    $('#res-title').textContent = t('res.done', this.r.name);
    $('#res-msg').textContent = t('res.msg' + (this.fin || 1));
    const ln = $('#res-learn');
    ln.hidden = !this.learned; ln.textContent = t('tu.done');
  },

  /* สลับภาษากลางขั้น: เขียนชื่อเมนู คำพูด เคล็ดลับ คำสั่ง ปุ่ม และวัตถุดิบบนชั้นใหม่ */
  relabel() {
    if (!this.r) return;
    $('#g-name').textContent = this.r.name;
    const st = this.r.steps[this.i];
    if (!st) return;
    if (!this.busy) { this.base = st.say; clearTimeout(UI.sayT); UI.say(st.say); }
    $('#tip').textContent = '💡 ' + st.tip;
    UI.instr(UI._ik);
    const act = $('#act');
    if (st.timing && !act.hidden) act.textContent = st.timing.label;
    $$('#shelf .ing[data-src]').forEach(el => labelIng(el));
    Conveyor.relabel();
  }
};
