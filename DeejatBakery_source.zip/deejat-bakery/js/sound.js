'use strict';
/* =====================================================================
   sound.js — เสียงสังเคราะห์ด้วย Web Audio (ไม่ต้องโหลดไฟล์เสียง)
   - ปลดล็อกเสียงด้วยการแตะครั้งแรก (จำเป็นสำหรับ iPhone/Safari)
   - หยุดเพลงอัตโนมัติเมื่อสลับแอป/ล็อกจอ เพื่อประหยัดแบต
   ===================================================================== */
const N = { C4: 261.6, C5: 523.3, D5: 587.3, E5: 659.3, G5: 784, A5: 880, C6: 1046.5 };
const MEL = [N.E5,0,N.G5,N.E5,N.A5,0,N.G5,0, N.E5,0,N.D5,N.C5,N.D5,0,N.E5,0, N.G5,0,N.A5,N.G5,N.E5,0,N.C5,0, N.D5,N.E5,N.D5,N.C5,N.C5,0,0,0];
const BASS = [130.8,130.8,110,110,87.3,87.3,98,98];

const Sound = {
  ctx: null, on: false, next: 0, beat: 0, timer: null, unlocked: false,

  init() {
    if (this.ctx) return;
    try {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return;
      const c = this.ctx = new C();
      this.master = c.createGain(); this.mus = c.createGain(); this.sfx = c.createGain();
      this.mus.connect(this.master); this.sfx.connect(this.master); this.master.connect(c.destination);
      const buf = c.createBuffer(1, c.sampleRate, c.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.noise = buf;
      this.setVolumes();
    } catch (e) { this.ctx = null; }
  },

  /* เรียกจาก event การแตะ/คลิกเท่านั้น */
  unlock() {
    this.init();
    const c = this.ctx;
    if (!c) return;
    if (c.state !== 'running' && !document.hidden) c.resume().catch(() => {});
    if (!this.unlocked) {
      try { // เล่นเสียงเงียบ 1 sample เพื่อปลดล็อก iOS
        const s = c.createBufferSource(); s.buffer = c.createBuffer(1, 1, 22050); s.connect(c.destination); s.start(0);
        this.unlocked = true;
      } catch (e) { /* ignore */ }
    }
  },
  resume() { this.unlock(); },
  pause() { if (this.ctx && this.ctx.state === 'running') this.ctx.suspend().catch(() => {}); },
  wake() { if (this.ctx && this.unlocked && this.ctx.state !== 'running') this.ctx.resume().catch(() => {}); },

  setVolumes() {
    if (!this.ctx) return;
    this.master.gain.value = Settings.d.mute ? 0 : 1;
    this.mus.gain.value = Settings.d.music * .45;
    this.sfx.gain.value = Settings.d.sfx;
  },

  tone(f, t, dur, type = 'sine', vol = .2, dest) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + .012);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(dest || this.sfx); o.start(t); o.stop(t + dur + .05);
  },
  slide(f1, f2, t, dur, type, vol) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f1, t); o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(this.sfx); o.start(t); o.stop(t + dur + .05);
  },
  hiss(t, dur, freq, q, vol) {
    const c = this.ctx, s = c.createBufferSource(); s.buffer = this.noise;
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.sfx); s.start(t); s.stop(t + dur);
  },

  play(n) {
    if (!this.ctx || Settings.d.mute || Settings.d.sfx <= 0 || this.ctx.state === 'closed') return;
    const t = this.ctx.currentTime;
    try {
      switch (n) {
        case 'pop': this.slide(420, 900, t, .12, 'sine', .25); break;
        case 'click': this.tone(880, t, .08, 'triangle', .2); break;
        case 'tap': this.slide(600, 1000, t, .1, 'triangle', .25); this.tone(1500, t + .05, .08, 'sine', .12); break;
        case 'ding': [N.E5, N.G5, N.C6].forEach((f, i) => this.tone(f, t + i * .08, .35, 'triangle', .25)); break;
        case 'star': [N.C5, N.E5, N.G5, N.C6, N.E5 * 2].forEach((f, i) => this.tone(f, t + i * .07, .45, 'triangle', .25)); break;
        case 'oops': this.slide(380, 200, t, .3, 'sawtooth', .12); this.slide(300, 160, t + .12, .3, 'sawtooth', .1); break;
        case 'splash': this.hiss(t, .35, 900, .8, .5); this.slide(500, 250, t, .15, 'sine', .15); break;
        case 'crunch': this.hiss(t, .07, 2600, 1.2, .5); this.hiss(t + .08, .06, 3200, 1.2, .4); this.hiss(t + .15, .08, 2200, 1, .35); this.tone(N.G5, t + .2, .25, 'triangle', .18); break;
        case 'whoosh': this.hiss(t, .18, 1800, 1.5, .12); break;
        case 'sizzle': this.hiss(t, .5, 5000, .6, .18); break;
        case 'win': [N.C5, N.E5, N.G5, N.C6, N.G5, N.C6, N.E5 * 2, N.G5 * 2].forEach((f, i) => this.tone(f, t + i * .11, .5, 'triangle', .28)); break;
        case 'swat': this.hiss(t, .09, 1400, 1.1, .45); this.slide(340, 110, t, .12, 'square', .1); this.tone(N.E5, t + .08, .12, 'triangle', .14); break;   // ปัดแมลง "ผัวะ!"
        case 'pour': this.hiss(t, .55, 700, .9, .32); this.hiss(t + .08, .4, 1400, 1.4, .14); this.slide(260, 420, t, .5, 'sine', .05); break;   // เทของเหลว "ซู่"
        case 'crack': this.hiss(t, .03, 3600, 2, .55); this.hiss(t + .06, .04, 2800, 2, .5); this.tone(180, t + .02, .06, 'square', .05); this.hiss(t + .3, .25, 900, .8, .25); break;   // ตอกไข่ "ก๊อก-แป๊ก" แล้วหยดลง
        case 'sprinkle': for (let i = 0; i < 6; i++) this.hiss(t + i * .045, .05, 5200 + i * 300, 3, .12); this.hiss(t + .3, .3, 1800, .7, .1); break;   // โรยผง "ซ่า ๆ" เบา ๆ
        case 'warn': this.tone(N.A5, t, .09, 'square', .07); this.tone(N.E5, t + .11, .12, 'square', .07); break;   // ของแปลกปลอมกำลังหล่น "ติ๊ด-ตื๊อ"
        case 'fail': this.hiss(t, .45, 3200, .7, .3); this.slide(520, 170, t + .05, .55, 'sawtooth', .13); break;           // ฟู่ + เสียงตก (ขนมเสีย)
        case 'lose': [N.G5, N.E5, N.D5, N.C5].forEach((f, i) => this.tone(f, t + i * .2, .5, 'triangle', .22)); break;    // ดนตรีเศร้า ๆ สั้น ๆ
      }
    } catch (e) { /* ignore */ }
  },

  startMusic() {
    this.unlock();
    if (!this.ctx || this.on) return;
    this.on = true; this.beat = 0; this.next = this.ctx.currentTime + .1;
    this.timer = setInterval(() => this.sched(), 150);
  },
  sched() {
    const c = this.ctx;
    if (!c || c.state !== 'running') return;
    const spb = 60 / 116 / 2;
    if (this.next < c.currentTime) this.next = c.currentTime + .05; // หลังพักแอป อย่ารัวโน้ตที่ค้าง
    const silent = Settings.d.mute || Settings.d.music <= 0;
    while (this.next < c.currentTime + .4) {
      if (!silent) {
        const b = this.beat % 32, m = MEL[b];
        if (m) this.tone(m, this.next, spb * 1.8, 'triangle', .22, this.mus);
        if (b % 4 === 0) this.tone(BASS[b / 4], this.next, spb * 3.4, 'sine', .32, this.mus);
        if (b % 8 === 4) this.tone(N.C6, this.next, spb, 'sine', .05, this.mus);
      }
      this.next += spb; this.beat++;
    }
  }
};
