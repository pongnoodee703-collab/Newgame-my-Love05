'use strict';
/* =====================================================================
   screens.js — สลับหน้าจอ / หน้าเลือกเมนู / หน้าต่างตั้งค่า / สมุดสูตร
   ===================================================================== */
/* สีแถบสถานะ/แถบเบราว์เซอร์มือถือ ให้กลืนกับส่วนบนของแต่ละหน้า */
const BAR_COLOR = { start: '#8a5a35', menu: '#fffaf2', game: '#ffffff', result: '#e7c398' };

const Screens = {
  cur: 'start',
  show(n) {
    if (!$('#screen-' + n)) n = 'start';                 // ชื่อหน้าผิด → กลับหน้าแรก ไม่ค้างจอขาว
    this.cur = n;
    closeModals();                                       // กันหน้าต่างค้างทับหน้าใหม่
    $$('.screen').forEach(s => s.classList.toggle('active', s.id === 'screen-' + n));
    if (n === 'menu') safeCall(buildMenu, 'buildMenu');
    if (n === 'game') requestAnimationFrame(() => safeCall(() => StageFit.fit(), 'StageFit'));
    const bar = $('meta[name="theme-color"]');
    if (bar) bar.content = BAR_COLOR[n];
    if (n !== 'start') BackNav.arm();
  },
  is(n) { return this.cur === n; }
};

/* ปุ่มย้อนกลับของมือถือ (Android) / ปัดขอบจอย้อนกลับ (iPhone)
   ถอยทีละหน้าในเกม (หน้าต่าง → ครัว → เมนู → หน้าแรก) แทนที่จะหลุดออกจากเกมกลางคัน
   ทำโดยจองประวัติไว้ 1 ช่องเมื่อออกจากหน้าแรก; ที่หน้าแรกกดย้อนกลับจะออกจากเกมตามปกติ */
const BackNav = {
  armed: false,
  arm() {
    if (this.armed) return;
    try { history.pushState({ deejat: 1 }, ''); this.armed = true; } catch (e) { /* เบราว์เซอร์ไม่ยอม → ใช้ปุ่มย้อนกลับแบบเดิม */ }
  },
  init() {
    addEventListener('popstate', () => {
      this.armed = false;
      if ($('.overlay.open')) closeModals();
      else if (Screens.is('game')) { G.abort(); Screens.show('menu'); }
      else if (Screens.is('result')) Screens.show('menu');
      else if (Screens.is('menu')) Screens.show('start');
      else return;                                       // หน้าแรก: ปล่อยให้ย้อนกลับออกจากเกม
      Sound.play('click');
      if (!Screens.is('start')) this.arm();
    });
  }
};

/* ---------- หน้าเลือกเมนู (ข้อความทั้งหมดอยู่ใน i18n.js) ---------- */
function buildMenu() {
  const STICKERS = t('menu.sticker'), LEVELS = t('menu.level');
  const mp = $('#menu-pal');
  if (!$('#menu-chef', mp)) mp.innerHTML = '<div class="say"></div><div id="menu-chef" class="cbox"></div>';
  const mc = $('#menu-chef', mp);
  if (mc.dataset.k !== Settings.d.char) { mc.dataset.k = Settings.d.char; mc.innerHTML = charHTML(Settings.d.char, 'cheer'); }
  Shop.crew();                                           // เพื่อน ๆ ตัวเล็กในครัว (2 ตัวที่ไม่ได้เลือกเป็นเชฟ)
  $('.say', mp).textContent = tPick('menu.say');
  $('#menu-diff').textContent = t('set.assist') + ': ' + t('lv.' + Settings.d.assist) + ' ›';   // แตะเพื่อเปลี่ยนความยาก
  const say = $('.say', mp);
  say.classList.remove('hide');
  clearTimeout(buildMenu._t);
  buildMenu._t = setTimeout(() => say.classList.add('hide'), 3500);   // ซ่อนเองจะได้ไม่บังการ์ด
  $('#cards').innerHTML = SHOP_SIGN + Object.values(RECIPES).map((r, i) => {
    const b = Progress.best[r.id] || 0;
    return `<article class="card" data-id="${r.id}">
      <span class="badge">${i + 1}</span>
      <div class="peek cbox">${charHTML(CHAR_KEYS[i % 3])}</div>
      <div class="ico"><i class="stand"></i>${iconSVG(r.id)}<i class="dome"></i><span class="sticker">${STICKERS[i] || ''}</span>${r.price ? `<span class="price">฿${r.price}</span>` : ''}</div>
      <h3>${r.name}</h3>
      <p class="sub">${r.sub}</p>
      <span class="chip">${LEVELS[r.stars - 1]}</span>
      <p class="chal">${(t('chal') || [])[i] || ''}</p>
      <p class="meta">${t('menu.steps', r.steps.length)}</p>
      <div class="diff" aria-label="${t('menu.diffAria', r.stars)}">${t('menu.diff')} ${[1, 2, 3].map(k => starSVG(k <= r.stars)).join('')}</div>
      <div class="best">${b ? t('menu.best') + ' ' + [1, 2, 3].map(k => starSVG(k <= b)).join('') : t('menu.never')}</div>
      <button class="btn pri" type="button" data-play="${r.id}">${t('menu.go')}</button>
    </article>`;
  }).join('');

  if (Env.mouse) $$('.card').forEach(c => {   // เอียงการ์ดตามเมาส์ (เฉพาะคอม)
    c.addEventListener('pointermove', e => {
      const r = c.getBoundingClientRect();
      c.style.setProperty('--ry', ((e.clientX - r.left) / r.width - .5) * 10 + 'deg');
      c.style.setProperty('--rx', -((e.clientY - r.top) / r.height - .5) * 10 + 'deg');
    });
    c.addEventListener('pointerleave', () => { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); });
  });
  // เริ่มทำขนมได้เฉพาะปุ่ม "▶ เริ่มทำเลย!" ของการ์ดแต่ละใบ (แตะส่วนอื่นของการ์ด/เลื่อนรายการ ไม่เริ่มเกมโดยไม่ตั้งใจ)
  $$('#cards [data-play]').forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    Sound.unlock(); Sound.play('click');
    G.start(b.dataset.play);
  }));
}

/* ---------- หน้าต่าง ---------- */
let _lastFocus = null;
function openModal(id) {
  _lastFocus = document.activeElement;
  $('#' + id).classList.add('open');
  BackNav.arm();                                         // กดย้อนกลับของมือถือ = ปิดหน้าต่างนี้
  Sound.play('pop');
  const btn = $('#' + id + ' [data-close]');
  if (btn && Env.mouse) btn.focus({ preventScroll: true });
}
function closeModals() {
  const open = $$('.overlay.open');
  if (!open.length) return;
  open.forEach(o => o.classList.remove('open'));
  if (_lastFocus && _lastFocus.focus && Env.mouse) _lastFocus.focus({ preventScroll: true });
  _lastFocus = null;
  // ปิดหน้าแนะนำวิธีเล่นด้วยวิธีไหนก็ได้ (ปุ่มย้อนกลับมือถือ / Esc / แตะนอกกรอบ) = ข้าม → ไปหน้าเลือกเมนูต่อ (เดิมค้างอยู่หน้าแรก)
  if (open.some(o => o.id === 'howto')) HowTo.done();
}

function buildSettings() {
  const d = Settings.d;
  $('#s-reset').textContent = t('set.reset');
  $('#s-ver').textContent = 'DeejatBakery v' + VERSION;
  $$('#s-lang button').forEach(b => { const on = b.dataset.v === d.lang; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
  $('#s-music').value = d.music; $('#s-sfx').value = d.sfx;
  $('#s-mute').checked = d.mute; $('#s-hap').checked = d.haptics;
  $('#s-cap').checked = d.captions; $('#s-hint').checked = d.hints; $('#s-calm').checked = d.calm;
  $$('#s-assist button').forEach(b => b.classList.toggle('on', b.dataset.v === d.assist));
  $('#s-char').innerHTML = CHAR_KEYS.map(k =>
    `<button type="button" data-k="${k}" class="${k === d.char ? 'on' : ''}" aria-label="${t('char.' + k)}" aria-pressed="${k === d.char}"><span class="cbox">${charHTML(k)}</span><small>${t('char.' + k)}</small></button>`).join('');
  $$('#s-char button').forEach(b => (b.onclick = () => {
    if (b.dataset.k === Settings.d.char) return;
    Settings.set('char', b.dataset.k); Sound.play('ding'); vibrate(10);
    buildSettings(); if (Screens.is('menu')) buildMenu();
    if (Screens.is('game')) safeCall(() => Helpers.render(), 'Helpers.render');   // เปลี่ยนเชฟกลางเกม → เพื่อนข้างเตาไม่ซ้ำกับเชฟ
    if (Screens.is('result')) safeCall(() => G.showResult(), 'G.showResult');      // หน้าสรุปผล: รูปเชฟเปลี่ยนตาม
  }));
}

function buildBook() {
  const r = G.r;
  if (!r) return;
  $('#book-title').textContent = '📖 ' + r.name;
  $('#book-body').innerHTML = r.book.map(s => `<h3>${s.h}</h3><ul>${s.l.map(x => `<li>${x}</li>`).join('')}</ul>`).join('');
}
