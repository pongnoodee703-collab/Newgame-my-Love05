'use strict';
/* =====================================================================
   i18n.js — สลับภาษา ไทย / English ทั้งเกม
   - t('คีย์')            ข้อความตามภาษาที่เลือก (ถ้าไม่มีคำแปล ใช้ภาษาไทยแทน ไม่พัง)
   - data-i18n="คีย์"      ใน index.html = เปลี่ยน textContent ตามภาษา
   - data-i18n-aria="คีย์" = เปลี่ยน aria-label (โปรแกรมอ่านหน้าจอ)
   - ข้อความในสูตรขนม: ภาษาไทยอยู่ใน recipes.js, อังกฤษอยู่ใน recipes-en.js
     I18N.apply() สลับข้อความใน RECIPES ทีละช่อง (ตัวเลข/สี/ขั้นตอนไม่แตะ)
   เพิ่มข้อความใหม่: ใส่คีย์เดียวกันทั้งใน STR.th และ STR.en
   ===================================================================== */
const STR = {
  th: {
    'scr.start': 'หน้าเริ่มเกม', 'scr.menu': 'เลือกเมนู', 'scr.game': 'ห้องครัว', 'scr.result': 'สรุปผล',
    'start.tagline': 'ร้านขนมปังอบสดของแก๊งเรา มาอบขนมด้วยกันนะ 🥐☕', 'start.play': '▶ เริ่มเกม',
    'settings': 'ตั้งค่า', 'back': 'กลับ', 'game.back': 'กลับไปเลือกเมนู', 'book': 'สูตรอาหาร', 'mychef': 'เชฟของฉัน', 'close': 'ปิด',
    'menu.title': 'เลือกเมนูวันนี้',
    'menu.say': ['วันนี้ทำอะไรดีน้า~ 🍰', 'เลือกเมนูที่ชอบเลย! 💖', 'ดาวเยอะ = ยากขึ้นน้า ⭐', 'เริ่มจากเมนูแรกก็ได้นะ 🌱'],
    'menu.sticker': ['เหมาะกับมือใหม่ 🌱', 'หวานฟูนุ่ม 💕', 'ท้าทายสุด ๆ 🔥'],
    'menu.level': ['ง่ายมาก', 'ปานกลาง', 'ท้าทาย'],
    'menu.steps': n => `🥣 ${n} ขั้นตอน`, 'menu.diff': 'ความยาก', 'menu.diffAria': n => `ความยาก ${n} ดาว`,
    'menu.best': 'ทำได้ดีที่สุด', 'menu.never': 'ยังไม่เคยทำ', 'menu.go': '▶ เริ่มทำเลย!',
    'res.again': '🔁 ทำอีกครั้ง', 'res.menu': '🍰 เลือกเมนูอื่น', 'res.done': name => `${name} เสร็จแล้ว!`,
    'res.msg3': 'สุดยอดเชฟประจำร้าน DeejatBakery! อร่อยที่สุดในโลกเลย 🎉',
    'res.msg2': 'อร่อยมาก ๆ เลย! อีกนิดเดียวก็เต็มสามดาวแล้วนะ 💖',
    'res.msg1': 'ใช้ได้เลย! ลองทำอีกครั้ง รับรองเก่งขึ้นแน่ ๆ 🌈',
    'ps.3': 'สุดยอด!', 'ps.2': 'เก่งมาก!', 'ps.1': 'ลองใหม่นะ~',
    'in.drag.touch': 'แตะวัตถุดิบที่อยู่ในสูตร (หรือลากไปใส่ก็ได้) 👆', 'in.drag.mouse': 'คลิกหรือลากวัตถุดิบที่อยู่ในสูตรไปใส่ 👆',
    'oops.ing': n => `อุ๊ย! ${n}ไม่ได้อยู่ในสูตรนะ ลองตัวอื่นน้า 🙈`,
    'in.stir.gentle': 'ถูนิ้ววนช้า ๆ บนชาม หรือแตะเบา ๆ ทีละครั้ง 🌀', 'in.stir.fast': 'ถูนิ้ววนเร็ว ๆ บนชาม หรือแตะรัว ๆ ก็ได้ 🌀',
    'flash.slow': 'ช้าลงหน่อยน้า ฟองเยอะแล้ว! 💧',
    'in.swipe': 'ถูนิ้วซ้าย-ขวาเพื่อเขย่ากระชอน หรือแตะที่กระชอนก็ได้ ☁️',
    'in.tap.dial': 'แตะที่เตาอบเพื่อหมุนปุ่มตั้งไฟ 🔥', 'in.tap.door': 'แตะที่ตู้เย็นเพื่อเปิด-ปิดประตู ❄️', 'in.tap.cups': 'แตะที่ฉาก ทีละครั้งจนครบทุกถ้วย 👆',
    'in.timing': 'กดปุ่มตอนเข็มอยู่ในโซนสีเขียว! (แตะที่ภาพก็ได้)',
    'tm.3': 'สุกกำลังดีเลย! 😍', 'tm.2': 'ใช้ได้เลยน้า~ 😊', 'tm.raw': 'อุ๊ย! ยังไม่สุกเลย 🥺', 'tm.burnt': 'อ๊ากก! ไหม้แล้ว 🔥😱', 'tm.mistakes': 'โอ๊ะ ผิดเยอะไปหน่อย ขนมเสียแล้ว 😢', 'tm.dirty': 'อี๋! ของแปลกปลอมตกใส่ขนม ขนมเสียแล้ว 🤢',
    'tu.retry.burnt': 'ไหม้แล้ว! ไม่เป็นไรนะ ลองอีกครั้ง กดตอนเข็มอยู่ในโซนสีเขียว 💪',
    'tu.retry.raw': 'เร็วไปนิด! ลองอีกครั้ง รอให้เข็มเข้าโซนสีเขียวก่อนนะ 💪',
    'lives.aria': n => `หัวใจเหลือ ${n} ดวง`,
    'lose.again': '🔁 เริ่มใหม่', 'lose.menu': '🍰 เลือกเมนูอื่น',
    'lose.burnt.t': 'อุ๊ย! ขนมไหม้แล้ว 🔥',
    'lose.burnt.d': 'กดช้าไปนิดเดียว เข็มเลยโซนสีเขียวไปแล้ว ขนมเลยไหม้ ลองเริ่มใหม่อีกครั้งนะ!',
    'lose.raw.t': 'ยังไม่สุกเลย! 🥺',
    'lose.raw.d': 'กดเร็วไปหน่อย ขนมยังไม่สุก รอให้เข็มเข้าโซนสีเขียวก่อนแล้วค่อยกด ลองเริ่มใหม่นะ!',
    'lose.mistakes.t': 'ทำผิดบ่อยเกินไป 😵',
    'lose.mistakes.d': 'ใส่ของผิดหรือคนแรงเกินไปหลายครั้ง หัวใจหมดแล้ว ขนมเลยเสีย ลองเริ่มใหม่ (ดูสูตรได้ที่ปุ่ม 📖)',
    'lose.dirty.t': 'ขนมปนเปื้อน! 🤢',
    'lose.dirty.d': 'มีของแปลกปลอมตกลงไปในขนม ต้องแตะหรือกวาดนิ้วปัดทิ้งก่อนถึงวงสีแดงนะ ลองเริ่มใหม่อีกครั้ง!',
    'flash.early': 'ยังไม่ถึงน้า รอเข็มเข้าโซนสีเขียวก่อน ⏳',
    'stage.aria': 'ฉากทำอาหาร',
    'set.title': '⚙️ ตั้งค่า',
    'set.g.play': '🎮 การเล่น', 'set.g.sound': '🔊 เสียง', 'set.g.help': '✨ ตัวช่วย', 'set.g.chef': '🧑‍🍳 เชฟของฉัน',
    'set.lang': '🌐 ภาษา', 'set.assist': '🎯 ความยาก',
    'lv.easy': 'ง่าย', 'lv.normal': 'ปกติ', 'lv.hard': 'ยาก',
    'set.music': '🎵 เพลง', 'set.sfx': '🔔 เสียงเอฟเฟกต์', 'set.mute': '🔇 ปิดเสียงทั้งหมด', 'set.hap': '📳 สั่น (Android)',
    'set.cap': '💬 คำพูดเชฟ', 'set.hint': '💡 ไฮไลต์ตัวที่ถูก', 'set.calm': '🍃 ลดการเคลื่อนไหว', 'set.char': '🧑‍🍳 เชฟของฉัน',
    'set.resetLabel': '🗑 ล้างคะแนนดาว', 'set.reset': 'ล้าง', 'set.confirm': 'แตะอีกครั้งเพื่อยืนยัน', 'set.cleared': 'ล้างแล้ว ✓',
    'book.title': '📖 สูตร',
    'pest.first': 'ระวัง! ของแปลกปลอมหล่นลงมา แตะปัดทิ้งเลย ถ้าตกใส่ขนม = แพ้นะ 👋', 'pest.landed': 'แย่แล้ว! ของแปลกปลอมตกลงไปในขนม 🤢',
    'pest.teach': 'ของแปลกปลอม! แตะที่มันเพื่อปัดทิ้ง 👆 (ถ้าตกใส่ขนม = แพ้)', 'pest.good': 'เก่งมาก! เห็นของหล่นมาเมื่อไหร่ ปัดทิ้งแบบนี้เลย 👍',
    'pest.tutor': 'ตกใส่ขนมแล้ว! ถ้าเล่นจริงจะแพ้นะ รอบหน้าแตะปัดทิ้งก่อนถึงวงแดง 🤢', 'pest.caught': 'เพื่อนช่วยปัดตกพื้นให้แล้ว! 👋',
    'kd.menu': 'เมนูวันนี้', // ความท้าทายของแต่ละด่าน (การ์ดเมนู + ป้ายตอนเข้าครัว)
    'chal': ['🌱 ฝึกพื้นฐาน • ของหล่นช้า • โซนเขียวกว้าง', '🔄 สายพานกลับทิศ • ของหลอกเพิ่ม • ของหล่นถี่ขึ้น', '⚡ เข็มเร็ว โซนแคบ • สายพานเดินถี่ขึ้น • ของหล่นทีละ 2'],
    'lvl.n': n => `ด่าน ${n}`,
    'belt.flip': '🔄 สายพานกลับทิศ!', 'belt.rush': '⚡ สายพานเร่งความเร็ว!', 'belt.jump': '🦘 ของบนสายพานกระโดด!', 'mt.raw': 'ดิบ', 'mt.ok': 'พอดี', 'mt.burn': 'ไหม้',
    // คำพูดสั้น ๆ ของเพื่อนข้างเตา (สุ่ม 1 ประโยค)
    'hs.st.drag': ['ส่งให้นะ!', 'หยิบจากสายพานเลย!', 'ของมาแล้ว~'], 'hs.st.stir': ['คนเลย ๆ!', 'วน ๆ เลย~'], 'hs.st.swipe': ['ร่อนแป้งกัน!', 'ปัดซ้ายขวาเลย!'],
    'hs.st.tap': ['แตะเลย!', 'ทีละอันนะ~'], 'hs.st.timing': ['รอเข็มเขียวนะ', 'อย่าเพิ่งกด~'], 'hs.zone': ['กดเลย!', 'ตอนนี้แหละ!'],
    'hs.help': ['ส่งให้นะ!', 'ช่วยอีกแรง!', 'เยี่ยม!'], 'hs.swat': ['ปัดตก!', 'ไปไกล ๆ!', 'ฮึบ!'], 'hs.cheer': ['สุดยอด!', 'เก่งมาก!', 'เย้!'],
    'hs.oops': ['โอ๊ะ!', 'ไม่เป็นไรนะ'], 'hs.flip': ['กลับทิศแล้ว!'], 'hs.rush': ['เร็วขึ้นแล้ว!'], 'hs.jump': ['กระโดด!', 'ฮึบ ๆ!', 'ดึ๋ง ๆ!'],
    'hs.jumptip': ['แตะสายพาน = กระโดด!', 'แตะที่ว่าง ของกระโดด!'],
    'hs.do.stir': ['ช่วยคนนะ!', 'คนด้วยกัน~'], 'hs.do.swipe': ['ช่วยร่อนนะ!', 'ฟู่ ๆ ~'], 'hs.do.tap': ['ทำให้อันนึง!', 'ช่วยแต่งนะ!'], 'hs.do.drag': ['อันนี้เลย!', 'หยิบอันนี้!'],
    'hs.warn': ['ระวัง! มีของหล่น!', 'ปัดทิ้งเร็ว!'],
    'tu.badge': '🎓 ด่านฝึก',
    'tu.drag': names => `แตะ ${names} 👆`,
    'tu.stir': 'ถูนิ้ววน ๆ บนชาม 🌀',
    'tu.stir.gentle': 'วนนิ้วช้า ๆ บนชาม 🌀',
    'tu.swipe': 'ถูนิ้วซ้าย-ขวา ☁️',
    'tu.tap': 'แตะชิ้นที่กระพริบ 👆',
    'tu.tap.dial': 'แตะปุ่มเตาอบ 🔥',
    'tu.tap.door': 'แตะตู้เย็น ❄️',
    'tu.wait': 'รอเข็มเข้าโซนเขียว… ⏳',
    'tu.press': 'กดเลย! 👆',
    'tu.done': '🎓 ผ่านด่านฝึกแล้ว! ครั้งหน้าลองเล่นเองได้เลย',
    'howto.aria': 'แนะนำเกมและวิธีเล่น', 'ht.skip': 'ข้าม', 'ht.next': 'ถัดไป ›', 'ht.go': '▶ เริ่มเลย!', 'ht.press': 'กดเลย!',
    'ht.0.t': 'ยินดีต้อนรับสู่ Deejat Bakery! 🥐',
    'ht.0.d': 'มาอบขนมกัน! ทำตามเชฟทีละขั้น ขนมเสร็จได้ดาว ⭐',
    'ht.1.t': 'ทำตามเชฟ 👆',
    'ht.1.d': 'แตะหรือลากของจากสายพานใส่ชาม ถูนิ้ววน ๆ เพื่อคน เพื่อน ๆ ช่วยด้วย ระวังพริก 🌶️ • ของที่หล่นลงมา 🦟 ต้องแตะปัดทิ้ง ถ้าตกใส่ขนม = แพ้',
    'ht.2.t': 'กดตอนเข็มเขียว ⏱️',
    'ht.2.d': 'เข็มเข้าโซนเขียวแล้วกด! ช้าไป = ขนมไหม้ แพ้ต้องเริ่มใหม่ 🔥 • ทำผิดเสียหัวใจ ❤️ หมดก็เริ่มใหม่',
    'char.girl': 'เชฟแว่นตา', 'char.cat': 'มีโอ', 'char.bear': 'หมีหม่ำ',
    'pal.girl': ['ยินดีต้อนรับค่ะ~ 💕', 'มาทำขนมกันเถอะ! 🍰', 'จั๊กจี้นะ~ 🙈', 'กดเริ่มเกมได้เลยค่ะ ▶'],
    'pal.cat': ['เมี๊ยว~ 🐱', 'ขอคุกกี้หน่อยสิ! 🍪', 'หิวแล้วน้า~ 🤤'],
    'pal.bear': ['หม่ำ ๆ ๆ 🐻', 'ฉันชอบพุดดิ้ง! 🍮', 'กอดหน่อยนะ~ 💕'],
    'pal.grumble': 'คิดถึงพ่อหนุ่มกราฟฟิกจังโว้ยยยย 😩'   // เพื่อน ๆ หน้าแรกบ่นสุ่ม ๆ (js/start-screen.js)
  },
  en: {
    'scr.start': 'Start screen', 'scr.menu': 'Choose a menu', 'scr.game': 'Kitchen', 'scr.result': 'Results',
    'start.tagline': "Our gang's fresh-baked bakery — let's bake together! 🥐☕", 'start.play': '▶ Play',
    'settings': 'Settings', 'back': 'Back', 'game.back': 'Back to menu', 'book': 'Recipe', 'mychef': 'My chef', 'close': 'Close',
    'menu.title': "Today's menu",
    'menu.say': ['What shall we bake today~ 🍰', 'Pick your favorite! 💖', 'More stars = harder ⭐', 'Try the first one to start 🌱'],
    'menu.sticker': ['Great for beginners 🌱', 'Sweet & fluffy 💕', 'Super challenging 🔥'],
    'menu.level': ['Very easy', 'Medium', 'Challenging'],
    'menu.steps': n => `🥣 ${n} steps`, 'menu.diff': 'Difficulty', 'menu.diffAria': n => `Difficulty ${n} stars`,
    'menu.best': 'Best', 'menu.never': 'Not tried yet', 'menu.go': "▶ Let's bake!",
    'res.again': '🔁 Bake again', 'res.menu': '🍰 Other menus', 'res.done': name => `${name} — done!`,
    'res.msg3': 'Top chef of DeejatBakery! The yummiest in the world 🎉',
    'res.msg2': 'So yummy! Just a little more for three stars 💖',
    'res.msg1': "Not bad! Try again — you'll get even better 🌈",
    'ps.3': 'Amazing!', 'ps.2': 'Great job!', 'ps.1': 'Try again~',
    'in.drag.touch': 'Tap the ingredients in the recipe (or drag them in) 👆', 'in.drag.mouse': 'Click or drag the recipe ingredients in 👆',
    'oops.ing': n => `Oops! ${n} isn't in the recipe — try another one 🙈`,
    'in.stir.gentle': 'Rub slow circles on the bowl, or tap gently one at a time 🌀', 'in.stir.fast': 'Rub fast circles on the bowl, or tap rapidly 🌀',
    'flash.slow': 'Slow down a little — too many bubbles! 💧',
    'in.swipe': 'Swipe left and right to shake the sieve, or just tap it ☁️',
    'in.tap.dial': 'Tap the oven to turn the dial 🔥', 'in.tap.door': 'Tap the fridge to open and close the door ❄️', 'in.tap.cups': 'Tap the scene, once per cup until all are done 👆',
    'in.timing': 'Press when the needle is in the green zone! (or tap the picture)',
    'tm.3': 'Perfectly done! 😍', 'tm.2': 'Pretty good~ 😊', 'tm.raw': "Oops! It's not cooked yet 🥺", 'tm.burnt': "Argh! It's burnt 🔥😱", 'tm.mistakes': 'Oh no, too many mistakes — it is ruined 😢', 'tm.dirty': 'Eww! Junk fell into the food — it is ruined 🤢',
    'tu.retry.burnt': "It's burnt! That's okay — try again and press while the needle is in the green zone 💪",
    'tu.retry.raw': 'A bit too early! Try again — wait for the needle to reach the green zone 💪',
    'lives.aria': n => `${n} hearts left`,
    'lose.again': '🔁 Start over', 'lose.menu': '🍰 Other menus',
    'lose.burnt.t': "Oops! It's burnt 🔥",
    'lose.burnt.d': 'You pressed a little too late and the needle passed the green zone. Start over and try again!',
    'lose.raw.t': "It's not cooked yet! 🥺",
    'lose.raw.d': 'You pressed a little too early. Wait for the needle to reach the green zone, then press. Start over and try again!',
    'lose.mistakes.t': 'Too many mistakes 😵',
    'lose.mistakes.d': 'Wrong ingredients or stirring too hard used up all your hearts. Start over and try again (check the recipe with 📖)!',
    'lose.dirty.t': 'The food got dirty! 🤢',
    'lose.dirty.d': 'Some junk fell into the food. Tap or swipe it away before it reaches the red ring. Start over and try again!',
    'flash.early': 'Not yet — wait for the needle to reach the green zone ⏳',
    'stage.aria': 'Cooking scene',
    'set.title': '⚙️ Settings',
    'set.g.play': '🎮 Play', 'set.g.sound': '🔊 Sound', 'set.g.help': '✨ Helpers', 'set.g.chef': '🧑‍🍳 My chef',
    'set.lang': '🌐 Language', 'set.assist': '🎯 Difficulty',
    'lv.easy': 'Easy', 'lv.normal': 'Normal', 'lv.hard': 'Hard',
    'set.music': '🎵 Music', 'set.sfx': '🔔 Sound effects', 'set.mute': '🔇 Mute all', 'set.hap': '📳 Vibration (Android)',
    'set.cap': '💬 Chef talk', 'set.hint': '💡 Highlight answers', 'set.calm': '🍃 Reduce motion', 'set.char': '🧑‍🍳 My chef',
    'set.resetLabel': '🗑 Reset stars', 'set.reset': 'Reset', 'set.confirm': 'Tap again to confirm', 'set.cleared': 'Cleared ✓',
    'book.title': '📖 Recipe',
    'pest.first': 'Watch out! Junk is falling. Tap it away — if it lands in the food, you lose 👋', 'pest.landed': 'Oh no! Something fell into the food 🤢',
    'pest.teach': 'Junk! Tap it to swat it away 👆 (if it lands in the food, you lose)', 'pest.good': 'Great! Whenever something falls, swat it like that 👍',
    'pest.tutor': 'It landed in the food! In a real game you would lose — next time swat it before the red ring 🤢', 'pest.caught': 'Your friend knocked it to the floor! 👋',
    'kd.menu': "Today's menu", 'chal': ['🌱 Basics • slow falling junk • wide green zone', '🔄 Belt reverses • more decoys • junk falls more often', '⚡ Fast needle, narrow zone • belt speeds up • 2 pieces of junk at once'],
    'lvl.n': n => `Level ${n}`,
    'belt.flip': '🔄 The belt reversed!', 'belt.rush': '⚡ The belt sped up!', 'belt.jump': '🦘 The items are jumping!', 'mt.raw': 'Raw', 'mt.ok': 'Perfect', 'mt.burn': 'Burnt',
    'hs.st.drag': ['Here you go!', 'Grab it from the belt!', 'Incoming~'], 'hs.st.stir': ['Stir stir!', 'Round and round~'], 'hs.st.swipe': ['Sift it!', 'Swipe left, right!'],
    'hs.st.tap': ['Tap tap!', 'One at a time~'], 'hs.st.timing': ['Wait for green', 'Not yet~'], 'hs.zone': ['Press now!', 'Now!'],
    'hs.help': ['Here!', 'I got you!', 'Nice!'], 'hs.swat': ['Swat!', 'Shoo!', 'Hup!'], 'hs.cheer': ['Yay!', 'Great job!', 'Woo!'],
    'hs.oops': ['Oops!', 'No worries'], 'hs.flip': ['Reversed!'], 'hs.rush': ['Faster!'], 'hs.jump': ['Jump!', 'Hop hop!', 'Boing!'],
    'hs.jumptip': ['Tap belt = jump!', 'Tap a gap: jump!'],
    'hs.do.stir': ['I will stir!', 'Stir together~'], 'hs.do.swipe': ['I will sift!', 'Fwoosh~'], 'hs.do.tap': ['I did one!', 'Let me help!'], 'hs.do.drag': ['This one!', 'Grab this!'],
    'hs.warn': ['Look out!', 'Swat it!'],
    'tu.badge': '🎓 Training',
    'tu.drag': names => `Tap ${names} 👆`,
    'tu.stir': 'Rub circles on the bowl 🌀',
    'tu.stir.gentle': 'Rub slow circles on the bowl 🌀',
    'tu.swipe': 'Swipe left and right ☁️',
    'tu.tap': 'Tap the blinking one 👆',
    'tu.tap.dial': 'Tap the oven dial 🔥',
    'tu.tap.door': 'Tap the fridge ❄️',
    'tu.wait': 'Wait for the green zone… ⏳',
    'tu.press': 'Press now! 👆',
    'tu.done': '🎓 Training complete! Next time, try it on your own',
    'howto.aria': 'Welcome and how to play', 'ht.skip': 'Skip', 'ht.next': 'Next ›', 'ht.go': "▶ Let's go!", 'ht.press': 'Press!',
    'ht.0.t': 'Welcome to Deejat Bakery! 🥐',
    'ht.0.d': "Let's bake! Follow the chef step by step — finish a treat to earn stars ⭐",
    'ht.1.t': 'Follow the chef 👆',
    'ht.1.d': 'Tap or drag things from the belt into the bowl, rub circles to stir — friends help too. Skip the chili 🌶️ • Swat falling junk 🦟 away: if it lands in the food, you lose',
    'ht.2.t': 'Press on green ⏱️',
    'ht.2.d': 'Press when the needle is in the green zone! Too late = burnt: you lose and start over 🔥 • Mistakes cost hearts ❤️',
    'char.girl': 'Chef Specs', 'char.cat': 'Mio', 'char.bear': 'Munchy Bear',
    'pal.girl': ['Welcome~ 💕', "Let's bake together! 🍰", 'That tickles~ 🙈', 'Tap Play to start ▶'],
    'pal.cat': ['Meow~ 🐱', 'Can I have a cookie? 🍪', "I'm hungry~ 🤤"],
    'pal.bear': ['Nom nom nom 🐻', 'I love pudding! 🍮', 'Hug me~ 💕'],
    'pal.grumble': 'I miss the graphics guy sooo muchhh 😩'
  }
};
const LANGS = ['th', 'en'];

function t(k, ...a) {
  let s = (STR[I18N.lang] || STR.th)[k];
  if (s == null) s = STR.th[k];
  if (s == null) return k;
  return typeof s === 'function' ? s(...a) : s;
}
/* สุ่ม 1 ข้อความจากรายการ เช่น คำพูดเพื่อน ๆ */
const tPick = k => { const L = t(k); return Array.isArray(L) ? L[Math.random() * L.length | 0] : L; };

const I18N = {
  lang: 'th', _shown: '',

  /* เก็บข้อความภาษาไทยเดิมของสูตรไว้ครั้งแรก แล้วสลับข้อความในวัตถุ RECIPES เดิม
     (ทุกส่วนของเกมอ้าง RECIPES ตัวเดียวกัน จึงเปลี่ยนตามทันทีโดยไม่ต้องแก้ที่อื่น) */
  _recipes(lang) {
    if (!this._decoysTh) this._decoysTh = DECOYS.map(d => d.n);
    DECOYS.forEach((d, i) => (d.n = (lang === 'en' && DECOYS_EN[i]) || this._decoysTh[i]));
    Object.values(RECIPES).forEach(r => {
      if (!r._th) r._th = { name: r.name, sub: r.sub, book: r.book, steps: r.steps.map(s => ({ title: s.title, say: s.say, tip: s.tip, label: s.timing && s.timing.label, items: s.items && s.items.map(x => ({ n: x.n, amt: x.amt })) })) };
      const en = lang === 'en' && RECIPES_EN[r.id], th = r._th;
      r.name = (en && en.name) || th.name;
      r.sub = (en && en.sub) || th.sub;
      r.book = (en && en.book) || th.book;
      r.steps.forEach((s, i) => {
        const a = th.steps[i], b = (en && en.steps && en.steps[i]) || {};
        s.title = b.title || a.title; s.say = b.say || a.say; s.tip = b.tip || a.tip;
        if (s.timing) s.timing.label = b.label || a.label;
        if (s.items) s.items.forEach((x, j) => { const y = (b.items && b.items[j]) || {}; x.n = y.n || a.items[j].n; x.amt = y.amt != null ? y.amt : a.items[j].amt; });
      });
    });
  },

  /* เรียกจาก Settings.apply() — ทำงานจริงเฉพาะตอนภาษาเปลี่ยน (เลื่อนแถบเสียงจะไม่วาดหน้าจอใหม่) */
  apply() {
    const lang = LANGS.includes(Settings.d.lang) ? Settings.d.lang : 'th';
    if (lang === this._shown) return;
    this.lang = this._shown = lang;
    document.documentElement.lang = lang;
    safeCall(() => this._recipes(lang), 'i18n.recipes');
    $$('[data-i18n]').forEach(el => (el.textContent = t(el.dataset.i18n)));
    $$('[data-i18n-aria]').forEach(el => el.setAttribute('aria-label', t(el.dataset.i18nAria)));
    // หน้าที่เปิดอยู่: วาดข้อความใหม่ทันที
    if (Screens.is('menu')) safeCall(buildMenu, 'buildMenu');
    if (Screens.is('game')) { safeCall(() => G.relabel(), 'G.relabel'); safeCall(() => { G.loseText(); UI.lives(G.lives); }, 'G.loseText'); }
    if (Screens.is('result')) safeCall(() => G.showResult(), 'G.showResult');
    if ($('#book.open')) safeCall(buildBook, 'buildBook');
    if ($('#howto.open')) safeCall(() => HowTo.render(), 'HowTo.render');
    if (Tutor.on && Tutor.spot && Tutor.spot.classList.contains('on')) safeCall(() => Tutor._show(Tutor.st, Tutor.phase), 'Tutor');
  }
};
