'use strict';
/* =====================================================================
   shop.js — หน้าเลือกเมนู: ฉากห้องครัวเบเกอรี่ (สไตล์อยู่ใน css/shop.css)
   - ป้ายร้านไม้ห้อยโซ่ "Deejat Bakery" ที่ buildMenu() ใส่ไว้บนสุดของรายการเมนู
   - เพื่อน ๆ ตัวเล็กที่ยืนทำขนมหลังโต๊ะ = ตัวละคร 2 ตัวที่ไม่ได้เลือกเป็นเชฟ
     (เชฟที่เลือกยืนมุมขวาล่างอยู่แล้ว) วาดใหม่เฉพาะตอนเปลี่ยนเชฟ
   ===================================================================== */
const SHOP_SIGN = '<div class="shop-sign" aria-hidden="true"><b><i>🥐</i>Deejat Bakery<i>🥖</i></b></div>';

const Shop = {
  _crewFor: '',
  init() { this.crew(); },
  crew() {
    const el = $('#kit-crew'), me = Settings.d.char;
    if (!el || this._crewFor === me) return;
    this._crewFor = me;
    el.innerHTML = CHAR_KEYS.filter(k => k !== me).map(k => `<span class="cbox">${charHTML(k, 'happy')}</span>`).join('');
  }
};
