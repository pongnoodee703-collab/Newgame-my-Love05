'use strict';
/* =====================================================================
   pests.js — ความท้าทายระหว่างทำขนม + เพื่อน ๆ ช่วยทำขนม
   - Pests    : ของแปลกปลอม (แมลง ใบไม้ ใยแมงมุม) หล่นจากเพดานส่ายไปมาลงหม้อ/ชาม → แตะ/กวาดนิ้วเพื่อปัดทิ้ง
                ถ้าปล่อยให้ตกลงไปในขนม = ขนมปนเปื้อน → แพ้ ต้องเริ่มเมนูใหม่ (ทุกโหมด ; ด่านฝึกชิ้นแรกหยุดรอให้ลองปัดก่อน)
                ผู้เล่นต้องปัดเอง (เพื่อนกระโดดตามไปช่วยปัดตอนผู้เล่นแตะ และตะโกนเตือน แต่ไม่ปัดแทน)
                มีวงเตือนสีแดงตรงจุดที่จะตก ยิ่งใกล้ยิ่งชัด
                ด่าน 1 มาห่าง ๆ หล่นช้า → ด่าน 3 มาบ่อย หล่นเร็ว มาได้ทีละ 2 ชิ้น (ปรับตามความยากด้วย)
                ห้ามปล่อยให้ตกใส่ขนม ต้องปัดทิ้ง: แตะโดน = กระเด็นหมุนตกพื้นไป ; โหมดง่าย/ด่านฝึก เพื่อน ๆ ช่วยปัดตกให้บ้าง
                เคลื่อนที่ด้วย Web Animations (การ์ดจอทำให้ ไม่กระตุก) พักเองตอนเปิดหน้าต่าง/สลับแอป/ไฟส่องสอนเล่น
                หล่นมาทุกด่านเสมอ (เป็นส่วนหนึ่งของเกม ไม่มีตัวเลือกปิดในตั้งค่า)
   - Helpers  : เพื่อน 2 ตัว (ที่ไม่ได้เลือกเป็นเชฟ) ยืนข้างเตา ถืออุปกรณ์ตามขั้น และ "ลงมือช่วยทำขนมจริง":
                ทุก ๆ ไม่กี่วินาทีโยนของ/ช่วยคน/ช่วยร่อน/ช่วยแต่งหน้า (ความคืบหน้าขยับจริงนิดหน่อย ไม่ทำแทนจนจบ),
                ขั้นหยิบของ = ชี้ของที่ถูกบนสายพาน, ขั้นเตาอบ = ตะโกนบอกตอนเข็มเขียว,
                กระโดดปัดของแปลกปลอม, เชียร์ตอนทำสำเร็จ, ตกใจตอนพลาด
   - Conveyor : ชั้นวางแบบสายพานวน อยู่บนจอทุกขั้นทั้ง 3 ด่าน ลากเลื่อนเองได้ (ขั้นที่ไม่ได้หยิบของ = ตู้โชว์ขนมเลื่อนผ่าน)
                มีลูกเล่นต่างกันแต่ละด่าน: ด่าน 1 วิ่งนิ่ม ๆ / ด่าน 2 กลับทิศ / ด่าน 3 เร่งความเร็วเป็นช่วง ๆ
   ===================================================================== */
const PEST_EMOJI = ['🦟', '🐜', '🐛', '🍂', '🦗', '🕸️'];
const PEST_SPIN = { '🍂': 1, '🕸️': 1 };                 // ใบไม้/ใยแมงมุม หมุนคว้างตอนหล่น
/* ด่านที่กำลังเล่น 0–2 (ลำดับเมนูใน recipes.js) */
const gameLevel = () => clamp(Object.keys(RECIPES).indexOf(G.r && G.r.id), 0, 2);
/* ระยะจากจุด (px,py) ถึงเส้นที่นิ้วลากผ่าน (ax,ay)→(bx,by) */
function segDist(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
  const k = L ? clamp(((px - ax) * dx + (py - ay) * dy) / L, 0, 1) : 0;
  return Math.hypot(px - ax - dx * k, py - ay - dy * k);
}

/* ---------- เพื่อน ๆ ช่วยทำขนม ---------- */
const Helpers = {
  els: [],
  render() {
    const me = Settings.d.char, ks = CHAR_KEYS.filter(k => k !== me);
    this.els = ['#helper-l', '#helper-r'].map((s, i) => {
      const el = $(s);
      if (el && el.dataset.k !== ks[i]) { el.dataset.k = ks[i]; el.innerHTML = charHTML(ks[i], 'happy'); }
      return el;
    }).filter(Boolean);
  },
  /* เล่นท่า (class CSS) ใหม่ทุกครั้ง: ถอดท่าเดิม แล้วใส่ท่าใหม่ใน 2 เฟรมถัดไป
     (ไม่ใช้ offsetWidth บังคับคำนวณเลย์เอาต์ — ท่านี้ถูกเรียกบ่อยตอนแตะรัว ๆ) */
  act(el, cls, ms = 650) {
    if (!el) return;
    el.classList.remove('swat-l', 'swat-r', 'cheer', 'oops', 'help');
    cancelAnimationFrame(el._r); clearTimeout(el._t);
    el._r = requestAnimationFrame(() => {
      el._r = requestAnimationFrame(() => {
        el.classList.add(cls);
        el._t = setTimeout(() => el.classList.remove(cls), ms);
      });
    });
  },
  /* ของที่ถือช่วยในแต่ละขั้น: ตะกร้าวัตถุดิบ / ทัพพี / แป้ง / ผลไม้แต่งหน้า / ถุงมือเตาอบ+นาฬิกาจับเวลา */
  tool(type) {
    const T = { drag: ['🧺', '🥚'], stir: ['🥄', '🥣'], swipe: ['🧈', '🌾'], tap: ['🍓', '🍒'], timing: ['🧤', '⏲️'] }[type] || ['', ''];
    this.els.forEach((el, i) => { el.dataset.tool = T[i] || ''; });
  },
  cheer() { this.els.forEach((el, i) => setTimeout(() => this.act(el, 'cheer'), i * 140)); this.say('cheer', null, true); },
  oops() { this.els.forEach(el => this.act(el, 'oops', 500)); this.say('oops'); },
  /* ช่วยทำขนม: กระโดดชูนิ้ว 👍 (+ พูดสั้น ๆ บ้าง) — ไม่มีของปลิวออกข้าง จอจะได้ไม่รก
     (ของที่โยนลงหม้อ/ชามจริง ๆ มีแค่ตอนเพื่อนลงมือช่วย → lend) */
  help() {
    const el = this.els[Math.random() * this.els.length | 0];
    if (!el) return;
    this.act(el, 'help', 600);
    if (Math.random() < .25) this.say('help', el);
  },
  /* ตัวที่อยู่ใกล้จุด x (พิกัด client) ที่สุด */
  near(x) {
    const d = el => { const r = el.getBoundingClientRect(); return Math.abs(r.left + r.width / 2 - x); };
    return this.els.reduce((a, b) => (d(b) < d(a) ? b : a));
  },
  /* ตัวที่อยู่ใกล้ของที่หล่นที่สุดกระโดดไปปัด */
  swat(x) {
    if (!this.els.length) return;
    const el = this.near(x);
    this.act(el, el === this.els[0] ? 'swat-r' : 'swat-l', 520);
    this.say('swat', el, true);
  },
  /* ของแปลกปลอมเริ่มหล่น: ตัวฝั่งนั้นตะโกนเตือน */
  warn(x) { if (this.els.length) this.say('warn', this.near(x)); },
  /* คำพูดสั้น ๆ เหนือหัว (คีย์ hs.* ใน i18n.js สุ่มประโยค) ; ยังพูดไม่จบไม่พูดทับ เว้นแต่ force */
  say(k, el, force) {
    if (!this.els.length || !Screens.is('game')) return;
    el = el || this.els[Math.random() * this.els.length | 0];
    const b = $(el === this.els[0] ? '#hsay-l' : '#hsay-r'), now = performance.now();
    if (!b || (!force && now < (b._u || 0))) return;
    b.textContent = tPick('hs.' + k);
    b.classList.add('on'); b._u = now + 1400;
    clearTimeout(b._t); b._t = setTimeout(() => b.classList.remove('on'), 1400);
  },
  /* เริ่มขั้นใหม่: ตัวหนึ่งบอกว่าทำอะไร (หลังเชฟพูดจบนิดนึง) */
  intro(type) {
    clearTimeout(this._i);
    this._i = setTimeout(() => { if (!G.busy) safeCall(() => this.say('st.' + type), 'Helpers.say'); }, 900);
  },
  /* ---------- ลงมือช่วยทำขนม ----------
     กลไกของขั้นนั้น (mechanics.js) ตั้ง G.assist = ฟังก์ชันช่วย 1 ครั้ง (.kind = ชนิดขั้น) — คืน false ถ้าช่วยไม่ได้แล้ว
     (เช่น ช่วยอีกครั้งจะทำจนจบขั้นแทนผู้เล่น) ; ช่วยได้ไม่เกิน 3 ครั้งต่อขั้น ห่างตามความยาก */
  nextAt: 0, n: 0,
  plan(first) {
    const gap = { easy: 5200, normal: 7600, hard: 11000 }[Settings.d.assist] || 7600;
    this.nextAt = performance.now() + (first ? 3400 : gap * (.8 + Math.random() * .4));
  },
  begin() { this.n = 0; this.plan(true); },
  /* เรียกทุก 250ms จาก Pests.update */
  update(paused) {
    if (paused || G.busy || !G.assist || !this.els.length) { this.nextAt += 250; return; }
    if (this.n >= 3 || performance.now() < this.nextAt) return;
    this.plan();
    if (G.assist.kind === 'drag' && (Settings.d.assist === 'hard' || !Settings.d.hints)) return;   // ยาก/ปิดไฮไลต์: ไม่ชี้ของให้
    this.lend(G.assist);
  },
  lend(fn) {
    const el = this.els[this.n++ % this.els.length];
    this.act(el, 'help', 600);
    this.say('do.' + fn.kind, el, true);
    const run = () => { if (G.assist === fn && !G.busy) safeCall(fn, 'Helpers.assist'); };
    if (fn.kind === 'drag' || !Env.motion) { run(); return; }
    // โยนของที่ถือเป็นวงโค้งลงหม้อ/ชาม แล้วค่อยนับว่าช่วย (เห็นชัดว่าเพื่อนลงมือทำ)
    const layer = $('#pests'), st = $('#stage');
    if (!layer || !st) { run(); return; }
    const lr = layer.getBoundingClientRect(), hr = el.getBoundingClientRect(), sr = st.getBoundingClientRect();
    const x0 = hr.left - lr.left + hr.width / 2, y0 = hr.top - lr.top + hr.height * .3;
    const x1 = sr.left - lr.left + sr.width / 2, y1 = sr.top - lr.top + sr.height * .45;
    const tz = document.createElement('i');
    tz.className = 'toss'; tz.textContent = el.dataset.tool || '✨';
    layer.appendChild(tz);
    const at = (x, y, r, s) => ({ transform: `translate(${x.toFixed(1)}px,${y.toFixed(1)}px) rotate(${r}deg) scale(${s})` });
    const a = tz.animate([at(x0, y0, 0, .8), at((x0 + x1) / 2, Math.min(y0, y1) - 70, 200, 1.1), at(x1, y1, 400, .6)], { duration: 520, easing: 'ease-in-out', fill: 'forwards' });
    let done = false;
    const land = () => {
      if (done) return;
      done = true; tz.remove(); run();
      if (Screens.is('game') && st.isConnected) puff(st, '✨', st.clientWidth * .48, st.clientHeight * .35, 0, { size: '1.4rem', life: 700 });
    };
    a.onfinish = land;
    setTimeout(land, 800);                               // กันค้าง ถ้าเฟรมไม่ถูกวาด
  },
  /* ขั้นเตาอบ: เข็มเข้าโซนเขียว → เพื่อนตะโกน "กดเลย!" */
  now() {
    const el = this.els[Math.random() * this.els.length | 0];
    if (!el) return;
    this.act(el, 'help', 600);
    this.say('zone', el, true);
  },

  /* ออกจากครัว: เงียบ */
  hush() {
    clearTimeout(this._i);
    this.nextAt = 0; this.n = 0;
    $$('#pests .toss').forEach(e => e.remove());
    ['#hsay-l', '#hsay-r'].forEach(s => { const b = $(s); if (b) { clearTimeout(b._t); b._u = 0; b.classList.remove('on'); } });
  }
};

/* ---------- แมลงก่อกวน ---------- */
const Pests = {
  list: [], tick: 0, nextAt: 0, st: null, firstTold: false, taught: false,

  /* ความถี่/ความเร็วตามด่าน (1–3) และระดับความยาก */
  cfg() {
    const lvl = gameLevel();
    const base = [{ gap: [6000, 9000], fly: 4300, max: 1 }, { gap: [4500, 6800], fly: 3600, max: 1 }, { gap: [3400, 5200], fly: 3000, max: 2 }][lvl];
    const d = { easy: [1.25, 1.15, 0], normal: [1, 1, 0], hard: [.8, .85, 1] }[Settings.d.assist] || [1, 1, 0];
    const slow = (this.st && this.st.t === 'timing' ? 1.6 : 1) * (Tutor.on ? 1.3 : 1);   // ตอนจับเวลา/ด่านฝึก มาห่างขึ้น
    return { gap: base.gap.map(g => g * d[0] * slow), fly: base.fly * d[1], max: Math.min(2, base.max + d[2]) };
  },
  plan(c, k = 1) { this.nextAt = performance.now() + (c.gap[0] + Math.random() * (c.gap[1] - c.gap[0])) * k; },

  /* ตอนเปิดเกม: ผูกการกวาดนิ้วปัด + การหมุนจอ ครั้งเดียว */
  init() { this.watchSwipe(); this.watchResize(); },

  /* เริ่มขั้นใหม่: นาฬิกาแมลงเดินต่อเนื่องข้ามขั้น (ไม่เริ่มนับใหม่ทุกขั้น ไม่งั้นทำเร็ว ๆ จะไม่เจอแมลงเลย) */
  step(st) {
    this.st = st;
    safeCall(() => { Helpers.tool(st.t); Helpers.intro(st.t); Helpers.begin(); }, 'Helpers.tool');   // เพื่อน ๆ หยิบอุปกรณ์ของขั้นนี้มาช่วย + บอกว่าทำอะไร
    // ตัวจับเวลา 250ms ตัวเดียวของครัว: ใช้ทั้งเพื่อนช่วยทำขนม และของแปลกปลอม
    if (!this.tick) { this.lastT = 0; this.tick = setInterval(() => safeCall(() => this.update(), 'Pests'), 250); }
    if (!this.nextAt) this.plan(this.cfg(), .6);         // ตัวแรกของเมนูมาเร็วหน่อย
  },

  /* ทุก 250ms: พัก/เล่นแอนิเมชันตามสถานะ, เพื่อนช่วยทำขนม และปล่อยของแปลกปลอมชิ้นใหม่เมื่อถึงเวลา */
  update() {
    const paused = !Screens.is('game') || document.hidden || !!$('.overlay.open') || !$('#lose').hidden || Tutor.lit();
    const now = performance.now(), dt = Math.min(500, now - (this.lastT || now));
    this.lastT = now;
    Helpers.update(paused);
    this.list.slice().forEach(p => {
      if (!p.anim || p.dead) return;
      const s = p.anim.playState;                        // play() กับแอนิเมชันที่จบแล้วจะเริ่มใหม่ → แตะเฉพาะที่กำลังบิน/พักอยู่
      if (p.frozen && !Tutor.on) { p.frozen = false; p.el.classList.remove('teach'); Coach.hide(); }   // ปิดด่านฝึกกลางคัน → หล่นต่อ
      const hold = paused || p.frozen;
      if (hold && s === 'running') { p.anim.pause(); if (p.mark) p.mark.pause(); }
      else if (!hold && s === 'paused') { p.anim.play(); if (p.mark) p.mark.play(); }
      if (hold) return;
      p.age += dt;
      if (p.teachAt && p.age >= p.teachAt) { safeCall(() => this.teach(p), 'Pests.teach'); return; }   // ด่านฝึก: หยุดรอให้ลองปัด
      if (p.swatAt && p.age >= p.swatAt) { safeCall(() => this.swat(p, true), 'Pests.helper'); return; }   // เพื่อนช่วยปัดตก
      // นาฬิกาสำรองของเกม: ถ้าเครื่อง/WebView หยุดวาดเฟรมจนแอนิเมชันไม่จบ ของก็ไม่ค้างกลางอากาศตลอดไป
      if ((p.left -= dt) <= 0) safeCall(() => this.land(p), 'Pests.land');
    });
    if (paused || G.busy || !this.st) { this.nextAt += 250; return; }
    const c = this.cfg();
    if (performance.now() >= this.nextAt && this.list.filter(p => !p.dead).length < c.max) { this.spawn(c); this.plan(c); }
  },

  spawn(c) {
    const layer = $('#pests'), stage = $('#stage');
    if (!layer || !stage || !stage.offsetParent) return;
    const lr = layer.getBoundingClientRect(), sr = stage.getBoundingClientRect();
    if (lr.width < 50 || sr.width < 50) return;
    // หล่นจากเพดานเหนือหม้อ/ชาม ส่ายซ้าย-ขวาเหมือนใบไม้ร่วง ไปตกกลางภาชนะ
    const x1 = sr.left - lr.left + sr.width * (.36 + Math.random() * .28), y1 = sr.top - lr.top + sr.height * .46;
    const x0 = clamp(x1 + (Math.random() - .5) * sr.width * .6, 24, lr.width - 24), y0 = -36;
    const emo = PEST_EMOJI[Math.random() * PEST_EMOJI.length | 0];
    const sway = Env.motion ? 22 + Math.random() * 20 : 0, spin = Env.motion ? (PEST_SPIN[emo] ? 50 : 14) : 0;
    const el = document.createElement('i');
    el.className = 'pest';
    el.textContent = emo;
    layer.appendChild(el);
    const N = 8, frames = [], path = [];
    for (let i = 0; i <= N; i++) {
      const k = i / N, s = Math.sin(k * Math.PI * 3) * (1 - k * .7);
      const x = x0 + (x1 - x0) * k + sway * s, y = y0 + (y1 - y0) * (k * .75 + k * k * .25);
      path.push(x, y);
      frames.push({ transform: `translate(${x.toFixed(1)}px,${y.toFixed(1)}px) rotate(${(spin * s).toFixed(1)}deg)` });
    }
    // วงเตือนสีแดงตรงจุดที่จะตก: ค่อย ๆ ใหญ่และชัดขึ้นจนถึงตอนตก (หยุด/เล่นพร้อมของที่หล่น)
    const mk = document.createElement('i');
    mk.className = 'pmark';
    layer.appendChild(mk);
    const mAt = s => ({ transform: `translate(${x1.toFixed(1)}px,${y1.toFixed(1)}px) scale(${s})` });
    // left = เวลาสำรอง (ms): ปกติตกตอนแอนิเมชันจบ ; ถ้าเครื่องหยุดวาดเฟรมจนเกินเวลานี้ค่อยนับว่าตก
    // swatAt = เพื่อนกระโดดปัดตกให้ตอนหล่นมาได้ระยะนี้ (0 = ไม่ช่วย) — โหมดง่าย/ด่านฝึกเท่านั้น
    // teachAt = ด่านฝึกชิ้นแรก: หยุดกลางอากาศ + มือ 👆 ชี้ จนกว่าผู้เล่นจะแตะปัด
    const teach = Tutor.on && !this.taught;
    const help = 0;                                      // ผู้เล่นต้องปัดเองทุกชิ้น (กลไก swatAt ยังอยู่ เผื่อเปิดใช้ภายหลัง)
    const p = { el, mk, path, dur: c.fly, dead: false, left: c.fly + 1200, age: 0, swatAt: Math.random() < help ? c.fly * .68 : 0, teachAt: teach ? c.fly * .4 : 0 };
    p.anim = el.animate(frames, { duration: c.fly, easing: 'linear', fill: 'forwards' });
    p.mark = mk.animate([{ ...mAt(.35), opacity: .2 }, { ...mAt(1), opacity: .95 }], { duration: c.fly, easing: 'ease-in', fill: 'forwards' });
    p.anim.onfinish = () => safeCall(() => this.land(p), 'Pests.land');
    el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); this.swat(p); });
    this.list.push(p);
    Sound.play('warn');
    Helpers.warn(lr.left + x1);                          // เพื่อนฝั่งที่ของหล่นตะโกนเตือน
    if (!this.firstTold) { this.firstTold = true; UI.flash(t('pest.first'), 2600); }
  },

  /* ตำแหน่งปัจจุบัน (px ในชั้นแมลง) คำนวณจากเวลาแอนิเมชัน — ไม่ต้องอ่านเลย์เอาต์ระหว่างนิ้วกวาด */
  at(p) {
    const ct = p.anim && p.anim.currentTime;
    if (p.dead || ct == null) return null;
    const N = p.path.length / 2 - 1, f = clamp(ct / p.dur, 0, 1) * N, i = Math.min(N - 1, f | 0), k = f - i;
    return [p.path[i * 2] + (p.path[i * 2 + 2] - p.path[i * 2]) * k, p.path[i * 2 + 1] + (p.path[i * 2 + 3] - p.path[i * 2 + 1]) * k];
  },

  /* ด่านฝึก ชิ้นแรก: หยุดกลางอากาศ วงกระพริบ + มือ 👆 + เชฟบอกให้แตะปัด (ไม่แพ้ ไม่มีเวลาจำกัด) */
  teach(p) {
    p.teachAt = 0; p.frozen = true; this.taught = true;
    p.anim.pause(); if (p.mark) p.mark.pause();
    p.el.classList.add('teach');
    const r = p.el.getBoundingClientRect();
    Coach.point(r.left + r.width / 2, r.top + r.height / 2);
    clearTimeout(UI.sayT); UI.say(t('pest.teach'));
  },

  /* แตะโดน (หรือเพื่อนช่วย): เพื่อนตัวที่ใกล้สุดกระโดดปัด ของกระเด็นหมุนติ้วตกพื้นไป (ไม่ได้รับไว้) */
  swat(p, byHelper) {
    if (p.dead || G.busy) return;
    p.dead = true;
    const r = p.el.getBoundingClientRect(), lr = $('#pests').getBoundingClientRect();
    const x = r.left - lr.left + r.width / 2, y = r.top - lr.top + r.height / 2;   // จุดกลาง (CSS จัดให้อยู่กลางพิกัด translate)
    p.anim.cancel();
    this.unmark(p);
    if (p.frozen) { p.frozen = false; Coach.hide(); UI.flash(t('pest.good'), 1600); }   // ด่านฝึก: ปัดได้แล้ว เก่งมาก
    Helpers.swat(r.left + r.width / 2);
    Sound.play('swat'); vibrate(15);
    if (byHelper) UI.flash(t('pest.caught'), 1300);
    puff($('#pests'), '💥', x, y, 0, { size: '1.6rem', life: 600 });
    p.el.classList.add('hit');                           // เอาวงประออก (แตะซ้ำไม่ได้แล้ว)
    // ปัดตก: กระเด็นออกด้านข้าง ลอยขึ้นนิดหน่อย แล้วหมุนติ้วร่วงลงพื้น (ห่างจากหม้อ/ชาม)
    const away = x < lr.width / 2 ? -1 : 1, dx = away * (70 + Math.random() * 60), floor = lr.height + 50;
    p.anim = p.el.animate([
      { transform: `translate(${x}px,${y}px) rotate(0deg)`, easing: 'ease-out' },
      { transform: `translate(${(x + dx * .45).toFixed(1)}px,${(y - 46).toFixed(1)}px) rotate(${away * 220}deg)`, easing: 'ease-in', offset: .3 },
      { transform: `translate(${(x + dx).toFixed(1)}px,${floor.toFixed(1)}px) rotate(${away * 640}deg)` }
    ], { duration: 780, fill: 'forwards' });
    p.anim.onfinish = () => this.remove(p);
    setTimeout(() => this.remove(p), 1000);              // กันค้าง ถ้าเฟรมไม่ถูกวาด (ลบซ้ำได้ ไม่มีผล)
  },

  /* ของแปลกปลอมตกลงไปในขนม = ขนมปนเปื้อน → แพ้ เริ่มเมนูใหม่ (ทุกโหมด รวมด่านฝึก) */
  land(p) {
    if (p.dead || p.frozen) return;
    p.dead = true;
    this.remove(p);
    if (!Screens.is('game') || G.busy) return;
    const st = $('#stage');
    puff(st, '🤢', st.clientWidth * .45, st.clientHeight * .35, 0, { size: '2rem', life: 900 });
    Chars.mood('oops'); Helpers.oops();
    G.fail('dirty');
  },

  unmark(p) {
    if (!p.mk) return;
    try { if (p.mark) p.mark.cancel(); } catch (e) { /* ignore */ }
    p.mk.remove(); p.mk = null; p.mark = null;
  },
  remove(p) {
    this.unmark(p);
    if (!p.el.isConnected && !this.list.includes(p)) return;
    if (p.anim) { p.anim.onfinish = null; try { p.anim.cancel(); } catch (e) { /* ignore */ } }
    p.el.remove();
    this.list = this.list.filter(q => q !== p);
  },

  /* ค่อย ๆ จางหายไปเฉย ๆ (ไม่นับว่าตก ไม่แพ้) */
  fadeOut(p) {
    p.dead = true;
    if (p.frozen) { p.frozen = false; Coach.hide(); }
    this.unmark(p);
    if (!p.el.isConnected) { this.remove(p); return; }
    try { p.anim.pause(); } catch (e) { /* ignore */ }
    const a = p.el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, fill: 'forwards' });
    a.onfinish = () => this.remove(p);
    setTimeout(() => this.remove(p), 500);               // กันค้าง ถ้าเฟรมไม่ถูกวาด
  },

  /* ปัด = แตะโดน หรือ "ลากนิ้วกวาดผ่าน" ของที่หล่นอยู่ก็ได้ (ระหว่างคน/ร่อน/ลากของ นิ้วกวาดโดนก็ปัดตก)
     ตรวจเฉพาะตอนกดนิ้วค้างและมีของหล่นอยู่ (ไม่เกิน 2 ชิ้น) จึงแทบไม่กินแรงเครื่อง */
  watchSwipe() {
    if (this._sw) return;
    this._sw = true;
    let id = null, lx = 0, ly = 0, ox = 0, oy = 0;
    $('#screen-game').addEventListener('pointerdown', e => {
      id = e.pointerId; lx = e.clientX; ly = e.clientY; ox = oy = 0;
      const L = this.list.length && $('#pests');            // อ่านตำแหน่งชั้นแมลงครั้งเดียวตอนแตะ (ระหว่างลากไม่อ่านเลย์เอาต์)
      if (L) { const r = L.getBoundingClientRect(); ox = r.left; oy = r.top; }
    }, true);
    addEventListener('pointermove', e => {
      if (e.pointerId !== id) return;
      const x = e.clientX, y = e.clientY;
      if (this.list.length && !G.busy) safeCall(() => {
        if (!ox && !oy) { const r = $('#pests').getBoundingClientRect(); ox = r.left; oy = r.top || .01; }
        this.list.slice().forEach(p => {
          const c = this.at(p);
          if (c && segDist(c[0] + ox, c[1] + oy, lx, ly, x, y) < 34) this.swat(p);
        });
      }, 'Pests.swipe');
      lx = x; ly = y;
    }, { passive: true });
    const up = e => { if (e.pointerId === id) id = null; };
    addEventListener('pointerup', up);
    addEventListener('pointercancel', up);
  },

  /* หมุนจอ/เปลี่ยนความกว้างจอระหว่างหล่น: ปลายทางเดิมไม่ตรงกับหม้อ/ชามแล้ว → ให้จางหายไป (ไม่แพ้)
     (ฉากย้าย/ย่อขนาดตามจอใหม่ด้วย จึงเทียบความกว้างและความสูงทั้งคู่) */
  watchResize() {
    if (this._rs) return;
    this._rs = true;
    this._w = innerWidth; this._h = innerHeight;
    addEventListener('resize', () => {
      if (Math.abs(innerWidth - this._w) <= 40 && Math.abs(innerHeight - this._h) <= 120) return;
      this._w = innerWidth; this._h = innerHeight;
      this.list.slice().forEach(p => { if (!p.dead) this.fadeOut(p); });
    });
  },

  /* จบขั้น/ออกจากครัว: ของที่ยังหล่นอยู่หายไป (soft = ค่อย ๆ จางตอนทำขั้นสำเร็จ) */
  clear(soft) {
    this.st = null;
    this.list.slice().forEach(p => { if (soft) this.fadeOut(p); else { p.dead = true; this.remove(p); } });
    if (!soft) { clearInterval(this.tick); this.tick = 0; this.nextAt = 0; }
  }
};

/* ---------- ชั้นวางแบบสายพานวน (ทุกขั้น ทั้ง 3 ด่าน) ----------
   ของบนชั้นเดินทีละช่องแล้วหยุดพัก พ้นขอบด้านหนึ่งแล้วโผล่อีกด้าน (เหมือนสายพานในร้านขนม)
   - เดินเป็นจังหวะ (ไม่ไหลตลอดเวลา): หยุดทีไรการ์ดเรียงพอดีกลางชั้น เห็นเต็มใบ → อ่านง่าย แตะง่าย ไม่ลายตา
   - ขั้นหยิบของ: วัตถุดิบ + ของหลอก บนสายพาน ; ขั้นอื่น: "ตู้โชว์ขนม" เลื่อนผ่าน แตะเล่นได้ (ชั้นไม่หายไป จอไม่กระตุก)
   - ลากชั้นซ้าย-ขวาเองได้ (นิ้ว/เมาส์ ; ล้อเมาส์ 1 จังหวะ = 1 ช่อง) ปล่อยแล้วเข้าช่องพอดีเอง — ลากขึ้นไปที่ฉาก = หยิบของ (mechanics.js)
   - ลูกเล่นแต่ละด่าน: ด่าน 1 เดินช้าทางเดียว / ด่าน 2 กลับทิศเป็นระยะ 🔄 / ด่าน 3 เดินถี่ขึ้นเป็นช่วง ๆ ⚡
     (ขั้นหยิบของไม่มีของกระโดดเอง ; ตู้โชว์ขนมกระโดดเบา ๆ เป็นระยะ ; ด่านฝึกไม่เดินเอง ; จังหวะตามความยาก)
   - แตะชั้น = หยุดรอให้หยิบสักพัก ; ไฮไลต์ตัวที่ถูก = สายพานพาตัวนั้นมากลางชั้น
   - หยุดเองตอนไฟส่องสอนเล่น / เปิดหน้าต่าง / สลับแอป ; โหมดลดการเคลื่อนไหว = ไม่เดินเอง (ลากเองได้)
   - ตำแหน่งแต่ละชิ้นใช้ CSS translate (การ์ดจอทำให้ ไม่ต้องคำนวณเลย์เอาต์) ; ตอนหยุดพักไม่วาดอะไรเลย
   - เบราว์เซอร์เก่าที่ไม่รู้จัก translate → ชั้นแบบเดิม (ของเรียงหลายแถว อยู่กับที่) เล่นได้ปกติ */
/* ขนมในตู้โชว์: [อีโมจิ, ชื่อไทย, ชื่ออังกฤษ, ราคา] */
const DECO = [['🥐', 'ครัวซองต์', 'Croissant', 35], ['🍩', 'โดนัท', 'Donut', 25], ['🥖', 'บาแก็ต', 'Baguette', 45], ['🧁', 'คัพเค้ก', 'Cupcake', 39],
  ['🍪', 'คุกกี้', 'Cookie', 20], ['🍮', 'พุดดิ้ง', 'Pudding', 29], ['🥧', 'พาย', 'Pie', 49], ['🍰', 'เค้ก', 'Cake', 59], ['🥯', 'เบเกิล', 'Bagel', 30]];

const CONV_JUMP_MS = 480;                                // ระยะเวลาที่ของบนสายพานลอยกลางอากาศตอนกระโดด
const Conveyor = {
  ok: HAS_TRANSLATE,
  raf: 0, gen: 0, el: null, off: 0, goal: 0, A: 0, v: 0, dir: 1, mode: 0, tAt: 0, rushTo: 0, stepAt: 0, deco: false,
  hold: 0, last: 0, mAt: 0, L: 0, gapX: 0, slot: 0, pl: 0, W: 0, base: [],
  drag: false, dragged: false, claimed: false, fling: 0, bAt: 0, blocked: false, lean: 0, ro: null, wAt: 0,
  jt: [], jh: 0, jUntil: 0, tn: 0, tut: false, told: false, tapAt: 0,

  /* เริ่มสายพาน (deco = ตู้โชว์ขนม) */
  start(el, deco) {
    this.stop();
    if (!this.ok || !el) return;
    this.el = el; this.deco = !!deco; this.hold = 0; this.drag = false; this.last = performance.now();
    this.dir = 1; this.tAt = 0; this.rushTo = 0; this.stepAt = 0; this.fling = 0; this.bAt = 0; this.lean = 0;
    this.mode = Tutor.on ? 0 : gameLevel(); this.tut = Tutor.on; this.tn = 0; this.jt = []; this.jUntil = 0;
    el.classList.add('conveyor');
    el.classList.toggle('showcase', this.deco);
    this.measure(this.last);
    this.off = this.goal = this.A;                       // เริ่มโดยชิ้นแรกอยู่ช่องซ้ายสุดที่เห็นเต็มใบ
    this.place();
    this._down = e => this.down(e);
    el.addEventListener('pointerdown', this._down, true);
    this._wheel = e => {
      const d = Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
      if (!d) return;
      e.preventDefault();
      const now = performance.now();
      this.hold = now + 1600;
      if (now - this.wAt < 160) return;                  // ล้อเมาส์ 1 จังหวะ = เลื่อน 1 ช่อง
      this.wAt = now; this.fling = 0;
      this.goal = this.snap(this.goal) - Math.sign(d) * this.gapX;
    };
    el.addEventListener('wheel', this._wheel, { passive: false });
    // วัดขนาดใหม่เฉพาะตอนชั้นเปลี่ยนขนาด (หมุนจอ/ฟอนต์โหลดเสร็จ) — ไม่วัดซ้ำทุกครึ่งวินาที
    this._resize = () => { this.mAt = 0; };
    addEventListener('resize', this._resize);
    if (window.ResizeObserver) { this.ro = new ResizeObserver(this._resize); this.ro.observe(el); }
    const gen = ++this.gen;
    const loop = now => {
      if (this.gen !== gen || this.el !== el) return;   // สายพานรอบเก่า (เปลี่ยนขั้น/ออกจากครัวไปแล้ว) → จบเงียบ ๆ
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(.05, (now - this.last) / 1000); this.last = now;
      if (!this.mAt || el.children.length !== this.base.length) { this.measure(now); this.goal = this.snap(this.goal); this.place(); }
      // สถานะที่ต้องหยุดสายพาน: เช็กแค่ 5 ครั้ง/วินาที (ไม่ค้นหาในหน้าเว็บทุกเฟรม)
      if (now - this.bAt > 200) {
        this.bAt = now; this.v = this.speed();
        this.blocked = Tutor.lit() || !!$('.overlay.open') || !$('#lose').hidden;
      }
      const air = this.jUntil && (now < this.jUntil || (this.jUntil = 0, true));   // มีของลอยอยู่ (กระโดด) → วาดทุกเฟรม
      if (this.drag || document.hidden) { if (air) this.place(); return; }
      if (this.fling) {                                  // ปัดแรง ๆ แล้วปล่อย = ไหลต่อ ค่อย ๆ ช้าลง แล้วเข้าช่องพอดี
        this.off += this.fling * dt;
        this.fling *= Math.pow(.04, dt);
        if (Math.abs(this.fling) < 60) { this.fling = 0; this.goal = this.snap(this.off); }
        this.setLean(-this.fling * .015);
        this.place(); return;
      }
      this.setLean(0);
      // เดินทีละช่องแล้วหยุดพัก (v = จังหวะ ms ต่อช่อง) ; ถูกหยุด/รอให้หยิบ → นับจังหวะใหม่หลังปล่อย (ไม่เดินทันที)
      if (this.v && now >= this.hold && !this.blocked) {
        this.trick(now);
        if (now >= this.stepAt) {
          if (this.stepAt) this.goal = this.snap(this.goal) + this.dir * this.gapX;
          this.stepAt = now + this.v * (now < this.rushTo ? .4 : 1);
        }
      } else this.stepAt = 0;
      // เลื่อนไปยังช่องเป้าหมายแบบนุ่ม ๆ (ออกตัวเร็ว แล้วชะลอเข้าช่อง) ; ถึงแล้วไม่วาดซ้ำ
      const d = this.goal - this.off;
      if (Math.abs(d) > .3) { this.off += d * Math.min(1, dt * 8); this.place(); }
      else if (d) { this.off = this.goal; this.place(); }
      else if (air) this.place();
    };
    this.raf = requestAnimationFrame(loop);
    // ครั้งแรกของเมนู: เพื่อนบอกว่าแตะที่ว่างบนสายพาน ของจะกระโดด
    if (!this.deco && !this.tut && !this.told) { this.told = true; clearTimeout(this._tip); this._tip = setTimeout(() => { if (this.el && !this.deco) Helpers.say('jumptip', null, true); }, 2600); }
  },
  /* ของบนสายพานเอนตามความเร็ว (องศา) — เขียนตัวแปร CSS ที่ชั้นครั้งเดียว ไม่ต้องเขียนทีละชิ้น */
  setLean(d) {
    d = clamp(Math.round(d * 2) / 2, -9, 9);
    if (d === this.lean || !this.el) return;
    this.lean = d;
    this.el.style.setProperty('--lean', d + 'deg');
  },

  /* ลูกเล่นของสายพาน (ด่านฝึกไม่มี)
     - ขั้นหยิบของ: ไม่มีของกระโดดเอง (การ์ดนิ่ง อ่าน/แตะง่าย) — ด่าน 2 กลับทิศ 🔄 / ด่าน 3 เดินถี่ขึ้นช่วงสั้น ๆ ⚡
     - ตู้โชว์ขนม (ไม่ต้องหยิบอะไร): ขนมกระโดดดึ๋งเบา ๆ เป็นระยะ (ด่านสูงกระโดดสูงขึ้นนิดหน่อย) */
  trick(now) {
    if (this.tut) return;
    if (!this.tAt) { this.tAt = now + 4000 + Math.random() * 2500; return; }
    if (now < this.tAt) return;
    if (this.deco) { this.jump([12, 16, 22][this.mode] || 12, 70, true); this.tAt = now + 8000 + Math.random() * 3000; return; }
    if (this.mode === 1) { this.dir = -this.dir; this.cue('belt.flip'); this.tAt = now + 6500 + Math.random() * 3000; }
    else if (this.mode === 2) {
      this.rushTo = now + 2400; this.stepAt = Math.min(this.stepAt || Infinity, now + 300); this.cue('belt.rush');
      this.tAt = now + 6500 + Math.random() * 2500;
    } else this.tAt = Infinity;                          // ด่าน 1: เดินช้าทางเดียวตลอด
  },
  /* ของบนสายพานกระโดดเป็นคลื่นจากซ้ายไปขวา (h = ความสูง px, gap = ห่างกันกี่ ms) — คำนวณใน place() ไม่มีลูปเพิ่ม */
  jump(h, gap, auto) {
    const el = this.el;
    if (!el || !this.L || !Env.motion) return;
    const now = performance.now(), n = el.children.length;
    const order = Array.from({ length: n }, (_, i) => i).sort((a, b) => this.pos(a) - this.pos(b));
    this.jt = []; order.forEach((i, k) => { this.jt[i] = now + k * gap; });
    this.jh = h; this.jUntil = now + n * gap + CONV_JUMP_MS + 30;
    if (auto) safeCall(() => WallShelf.wave(), 'WallShelf.wave');   // ชั้นบนผนังกระโดดตามด้วย
  },
  jumpY(i, now) {
    const s = this.jt[i];
    if (!s || !this.jUntil) return 0;
    const k = (now - s) / CONV_JUMP_MS;
    return k <= 0 || k >= 1 ? 0 : -this.jh * 4 * k * (1 - k);
  },
  /* ป้ายเล็ก ๆ เหนือชั้นบอกลูกเล่น (เฉพาะตอนหยิบของ ตอนเป็นตู้โชว์เงียบ ๆ) + เพื่อนตกใจนิด ๆ */
  cue(k) {
    if (this.deco) return;
    const c = $('#beltcue');
    if (!c) return;
    c.textContent = t(k);
    UI.flash(t(k), 1600);                                // บอกในบับเบิลของเชฟ (ไม่ลอยทับฉาก)
    Sound.play('whoosh');
    Helpers.say(k === 'belt.flip' ? 'flip' : 'rush', null, true);
  },

  /* ขนาดสายพาน: L = ความยาวหนึ่งรอบ (อย่างน้อยกว้างกว่าชั้น 1 ช่อง ของจะได้ไม่โผล่กลางชั้น), gapX = ระยะห่างแต่ละชิ้น
     A = ตำแหน่งที่การ์ดที่เห็นเต็มใบเรียงอยู่กลางชั้นพอดี (สายพานหยุดพักที่ A + จำนวนเต็มเท่าของ gapX เสมอ) */
  measure(now) {
    const el = this.el, k = el.children;
    this.mAt = now; this.v = this.speed();
    if (!k.length) { this.L = 0; return; }
    const cs = getComputedStyle(el), cw = k[0].offsetWidth;
    this.pl = parseFloat(cs.paddingLeft) || 0;
    this.W = el.clientWidth - this.pl - (parseFloat(cs.paddingRight) || 0);
    this.slot = cw + (parseFloat(cs.columnGap) || 6);
    this.L = Math.max(k.length * this.slot, this.W + this.slot);
    this.gapX = this.L / k.length;
    const vis = Math.max(1, Math.floor((this.W - cw) / this.gapX) + 1);
    this.A = (this.W - ((vis - 1) * this.gapX + cw)) / 2 + this.slot;
    this.base = Array.from(k, c => c.offsetLeft);
  },
  /* ตำแหน่งหยุดพักที่ใกล้ x ที่สุด (การ์ดเรียงพอดีกลางชั้น ไม่โดนขอบตัด) */
  snap(x) {
    const g = this.gapX;
    return g ? this.A + Math.round((x - this.A) / g) * g : x;
  },

  /* ตำแหน่งของชิ้นที่ i บนสายพาน (ขอบซ้าย, px จากขอบในของชั้น) */
  pos(i) {
    let x = (i * this.gapX + this.off) % this.L;
    if (x < 0) x += this.L;
    return x - this.slot;
  },
  place() {
    const el = this.el;
    if (!el || !this.L) return;
    const k = el.children, n = Math.min(k.length, this.base.length), now = performance.now();
    for (let i = 0; i < n; i++) k[i].style.translate = (this.pl + this.pos(i) - this.base[i]).toFixed(1) + 'px ' + this.jumpY(i, now).toFixed(1) + 'px';
  },

  /* แตะชั้น: หยุดรอ ; ลากแนวนอนเกิน 8px = เลื่อนชั้นตามนิ้ว (ลากขึ้น = ปล่อยให้ mechanics.js หยิบของ) ;
     แตะขนมในตู้โชว์ = ขนมเด้งดึ๋ง */
  down(e) {
    if (e.button > 0) return;
    this.hold = performance.now() + 1600; this.fling = 0;
    this.goal = this.off;                                // หยุดตรงนั้นเลย: การ์ดไม่ขยับหนีนิ้ว
    this.drag = false; this.dragged = false; this.claimed = false;
    const id = e.pointerId, sx = e.clientX, sy = e.clientY, o0 = this.off;
    const poke = this.deco && e.target.closest ? e.target.closest('.deco') : null;
    const onItem = !!(e.target.closest && e.target.closest('.ing'));
    let on = false, vx = 0, lx = sx, lt = performance.now();
    const end = ev => {
      if (ev && ev.pointerId !== id) return;
      removeEventListener('pointermove', mv); removeEventListener('pointerup', end); removeEventListener('pointercancel', end);
      this.goal = this.snap(this.off);                   // ปล่อยนิ้ว → เข้าช่องพอดี
      if (on) {
        this.drag = false; this.hold = performance.now() + 1200;
        if (Math.abs(vx) > 250 && performance.now() - lt < 90) this.fling = clamp(vx, -1600, 1600);   // ปัดแรงแล้วปล่อย = ไหลต่อ
      } else if (poke && ev && ev.type === 'pointerup') this.poke(poke);
      else if (!onItem && ev && ev.type === 'pointerup') this.tapJump();   // แตะที่ว่างบนสายพาน = ของกระโดด
    };
    const mv = ev => {
      if (ev.pointerId !== id) return;
      if (!this.el) { end(); return; }
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (!on) {
        if (this.claimed) { end(); return; }             // หยิบของไปแล้ว
        if (Math.hypot(dx, dy) <= 8) return;
        if (Math.abs(dy) >= Math.abs(dx) * .6) { end(); return; }
        on = this.drag = this.dragged = true;
      }
      const now = performance.now(), t = Math.max(1, now - lt);
      vx = vx * .6 + ((ev.clientX - lx) / t * 1000) * .4; lx = ev.clientX; lt = now;   // ความเร็วนิ้ว (เฉลี่ยนุ่ม ๆ)
      this.off = o0 + dx; this.place();
    };
    addEventListener('pointermove', mv, { passive: true });
    addEventListener('pointerup', end);
    addEventListener('pointercancel', end);
  },
  tapJump() {
    const now = performance.now();
    if (now - this.tapAt < 450) return;
    this.tapAt = now;
    this.jump(24, 45);
    Sound.play('pop'); vibrate(10);
    if (Math.random() < .35) Helpers.say('jump', null, true);
  },
  poke(it) {
    it.classList.remove('boing'); void it.offsetWidth; it.classList.add('boing');
    Sound.play('pop'); vibrate(8);
  },

  /* พาวัตถุดิบชิ้นนี้มาช่องกลางชั้น (ทางที่ใกล้กว่า) แล้วหยุดรอให้แตะ ; now = ย้ายทันทีไม่เลื่อน */
  show(item, now) {
    const el = this.el;
    if (!el || !item || !this.L) return;
    const i = Array.prototype.indexOf.call(el.children, item);
    if (i < 0) return;
    const want = (this.W - item.offsetWidth) / 2;
    let d = (want - this.pos(i)) % this.L;
    if (d > this.L / 2) d -= this.L; else if (d < -this.L / 2) d += this.L;
    this.fling = 0;
    this.goal = this.snap(this.off + d);
    this.hold = performance.now() + 3400;
    if (now || !Env.motion) { this.off = this.goal; this.place(); }
  },

  /* ตู้โชว์ขนม (ขั้นที่ไม่ได้หยิบของ): ถ้ามีอยู่แล้วก็วิ่งต่อ ไม่สร้างใหม่ */
  showcase() {
    const el = $('#shelf');
    if (!el || (this.deco && this.el === el && el.children.length)) return;
    const s = gameLevel() * 3;
    el.innerHTML = Array.from({ length: 6 }, (_, i) => {
      const k = (s + i) % DECO.length, d = DECO[k];
      return `<div class="ing deco" data-d="${k}" aria-hidden="true"><span class="e">${d[0]}</span><b></b><small>฿${d[3]}</small></div>`;
    }).join('');
    this.relabel();
    this.start(el, true);
  },
  /* ชื่อขนมในตู้โชว์ตามภาษา */
  relabel() {
    const en = Settings.d.lang === 'en';
    $$('#shelf .deco').forEach(it => { const d = DECO[+it.dataset.d]; if (d) $('b', it).textContent = en ? d[2] : d[1]; });
  },

  stop() {
    cancelAnimationFrame(this.raf); this.raf = 0; this.gen++;
    if (!this.el) return;
    this.el.removeEventListener('pointerdown', this._down, true);
    this.el.removeEventListener('wheel', this._wheel);
    removeEventListener('resize', this._resize);
    if (this.ro) { this.ro.disconnect(); this.ro = null; }
    this.el.classList.remove('conveyor', 'showcase');
    this.el.style.removeProperty('--lean');
    Array.from(this.el.children, c => c.style.removeProperty('translate'));
    clearTimeout(this._tip);
    this.el = null; this.L = 0; this.base = []; this.drag = false; this.deco = false; this.fling = 0; this.lean = 0; this.mAt = 0;
    this.jt = []; this.jUntil = 0; this.stepAt = 0;
  },

  /* จังหวะเดิน (ms ต่อ 1 ช่อง) ตามด่านและความยาก ; 0 = ไม่เดินเอง (ด่านฝึก / ลดการเคลื่อนไหว — ลากเองได้) */
  speed() {
    if (!Env.motion || Tutor.on) return 0;
    return [3000, 2500, 2100][gameLevel()] * ({ easy: 1.2, normal: 1, hard: .85 }[Settings.d.assist] || 1);
  }
};
