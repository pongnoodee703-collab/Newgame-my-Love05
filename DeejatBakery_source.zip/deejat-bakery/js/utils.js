'use strict';
/* =====================================================================
   utils.js — ฟังก์ชันช่วยทั่วไป
   ===================================================================== */
const VERSION = '16.1';                                    // แสดงท้ายหน้าตั้งค่า (เปลี่ยนทุกครั้งที่ออกรุ่นใหม่)
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;

/* แปลงสี hex → [r,g,b] (แคชไว้ เพราะถูกเรียกทุกเฟรมตอนอบ/เคี่ยว) */
const _hexCache = new Map();
const hex = h => {
  let v = _hexCache.get(h);
  if (!v) { const s = h.replace('#', ''); v = [0, 2, 4].map(i => parseInt(s.substr(i, 2), 16)); _hexCache.set(h, v); }
  return v;
};
/* ผสมสี a→b ตามสัดส่วน t (0–1) */
const mix = (a, b, t) => {
  const x = hex(a), y = hex(b), k = clamp(t, 0, 1);
  return '#' + x.map((v, i) => Math.round(lerp(v, y[i], k)).toString(16).padStart(2, '0')).join('');
};
const shuffle = a => {
  a = [...a];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [a[i], a[j]] = [a[j], a[i]]; }
  return a;
};
const starSVG = on => `<svg viewBox="0 0 24 24" class="star ${on ? 'on' : ''}" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg>`;

/* ข้อมูลอุปกรณ์ */
const mq = q => { try { return matchMedia(q).matches; } catch (e) { return false; } };
const Env = {
  coarse: mq('(pointer:coarse)'),          // จอสัมผัส (มือถือ/แท็บเล็ต)
  mouse: mq('(hover:hover) and (pointer:fine)'),
  reduce: mq('(prefers-reduced-motion:reduce)'),
  /* เครื่องสเปกต่ำ (CPU ≤4 คอร์ หรือ RAM ≤3 GB) → โหมดเบา: ปิดแอนิเมชันตกแต่งที่วนตลอดเวลา (ดู base.css) */
  lite: (() => { try { return (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 3; } catch (e) { return false; } })(),
  get small() { return Math.min(innerWidth, innerHeight) < 500; },
  get motion() { return !this.reduce && !document.body.classList.contains('calm'); }
};

/* localStorage แบบปลอดภัย (โหมดส่วนตัว / ถูกบล็อกก็ไม่พัง) */
const store = {
  get(k, f) { try { const v = localStorage.getItem(k); return v == null ? f : JSON.parse(v); } catch (e) { return f; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
};

/* สั่นเบา ๆ (Android รองรับ, iPhone จะข้ามไปเงียบ ๆ) */
const vibrate = p => {
  try {
    // เบราว์เซอร์ไม่ยอมให้สั่นก่อนผู้เล่นแตะจอครั้งแรก (Chrome จะขึ้น error ทุกครั้ง) → ข้ามไปเงียบ ๆ
    const ua = navigator.userActivation;
    if (ua && !ua.hasBeenActive) return;
    if (Settings.d.haptics && !Settings.d.mute && navigator.vibrate) navigator.vibrate(p);
  } catch (e) { /* ignore */ }
};

/* ประกายเล็ก ๆ ที่ลอยขึ้นแล้วหายไป */
function puff(parent, emoji, x, y, dx, opt = {}) {
  const p = document.createElement('span');
  p.className = 'puff';
  p.textContent = emoji;
  p.style.left = x + 'px';
  p.style.top = y + 'px';
  p.style.setProperty('--dx', dx + 'px');
  if (opt.size) p.style.fontSize = opt.size;
  if (opt.delay) p.style.animationDelay = opt.delay + 's';
  parent.appendChild(p);
  setTimeout(() => p.remove(), opt.life || 1100);
}

/* รองรับ CSS translate แยก (Android รุ่นเก่าใช้ transform แทน) */
const HAS_TRANSLATE = !!(window.CSS && CSS.supports && CSS.supports('translate', '1px 1px'));
const setOffset = (el, x, y) => {
  if (HAS_TRANSLATE) el.style.translate = `${x}px ${y}px`;
  else el.style.transform = `translate(${x}px,${y}px)`;
};
