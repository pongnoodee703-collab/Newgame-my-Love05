'use strict';
/* =====================================================================
   mechanics.js — วิธีเล่น 5 แบบ
   ทุกกลไกคืนค่า cleanup() และเรียก G.finish(จำนวนดาว) เมื่อทำเสร็จ
   ความง่าย/ยากทั้งหมดอ่านจาก Settings.assist() (ดู settings.js → ASSIST)
   ===================================================================== */
const stageEl = () => $('#stage');
const MECH = {};

/* วัตถุดิบบนชั้นตาม src ('s0' = วัตถุดิบตัวแรกของขั้นนี้, 'd3' = DECOYS[3]) — ได้ชื่อตามภาษาปัจจุบันเสมอ */
const ingOf = src => {
  if (!src) return null;
  const i = +src.slice(1);
  if (src[0] === 'd') return DECOYS[i];
  const st = G.r && G.r.steps[G.i];
  return st && st.items ? st.items[i] : null;
};
/* เขียนชื่อ/ปริมาณบนปุ่มวัตถุดิบ (เรียกซ้ำได้ตอนสลับภาษา) */
const labelIng = (el, fb) => {
  const it = ingOf(el.dataset.src) || fb;
  if (!it) return;
  $('b', el).textContent = it.n;
  $('small', el).textContent = it.amt || ' ';
  el.setAttribute('aria-label', it.n + (it.amt ? ' ' + it.amt : ''));
};

/* ---------------------------------------------------------------------
   1) DRAG — ใส่วัตถุดิบ: แตะ หรือ ลากไปวางที่หม้อ/ชาม
   - วางใกล้ ๆ ก็นับ (ขยายจุดรับ 48px รอบฉาก)
   - หยิบผิดจะขึ้นกากบาท ไม่ต้องกดซ้ำ
   - รอนาน ๆ จะไฮไลต์ตัวที่ถูกให้
   --------------------------------------------------------------------- */
MECH.drag = st => {
  const S = G.S, A = Settings.assist(), shelf = $('#shelf');
  let mist = 0, left = st.items.length, hintT = 0, ghost = null, dead = false;
  // src = ที่มาของวัตถุดิบ ('s' + ลำดับในขั้นนี้ / 'd' + ลำดับใน DECOYS) ใช้ดึงชื่อตามภาษาปัจจุบัน
  const decoys = shuffle(DECOYS).slice(0, A.decoys).map(d => ({ ...d, ok: false, src: 'd' + DECOYS.indexOf(d) }));
  const pool = shuffle([...st.items.map((x, i) => ({ ...x, ok: true, src: 's' + i })), ...decoys]);
  shelf.innerHTML = '';
  UI.instr(Env.coarse ? 'in.drag.touch' : 'in.drag.mouse');

  // จุดรับรอบฉาก: จอสัมผัสกว้างกว่า (นิ้วบังภาพ วางใกล้ ๆ ก็นับ)
  const M = Env.coarse ? 64 : 48;
  const near = (r, x, y) => x > r.left - M && x < r.right + M && y > r.top - M && y < r.bottom + M;
  const clearHint = () => { clearTimeout(hintT); $$('.ing.hint', shelf).forEach(e => e.classList.remove('hint')); };
  const armHint = () => {
    clearHint();
    const ms = Tutor.on ? 350 : A.hint;                  // โหมดสอนเล่น: ไฮไลต์ตัวที่ถูกเกือบทันที
    if (!ms || !Settings.d.hints) return;
    hintT = setTimeout(() => {
      const nx = $$('.ing', shelf).find(e => e.dataset.ok === '1' && !e.classList.contains('used'));
      if (nx) { nx.classList.add('hint'); Conveyor.show(nx); }   // ชั้นเลื่อนพาตัวที่ถูกมาให้เห็น
    }, ms);
  };
  const drop = (it, el, at) => {                         // at = จุดที่ปล่อยนิ้วตอนลากมาใส่ (ไม่มี = แตะที่การ์ด)
    if (dead || G.busy || el.classList.contains('used') || el.classList.contains('nope')) return;
    clearHint();
    if (!it.ok) {
      mist++; Sound.play('oops'); Chars.mood('oops'); vibrate([30, 40, 30]);
      el.classList.add('nope'); UI.shake(el);
      UI.flash(t('oops.ing', (ingOf(it.src) || it).n));
      G.miss();                                          // เสียหัวใจ 1 ดวง (หมด = แพ้)
      if (!G.busy) armHint();
      return;
    }
    el.classList.add('used'); left--;
    vibrate(12);
    if (Math.random() < .5) Helpers.help();              // เพื่อนชูนิ้วเชียร์บ้าง (ไม่ทุกครั้ง จอจะได้ไม่วุ่น)
    // โยนของจากการ์ดลงหม้อ/ชามเป็นวงโค้ง แล้วเท/ตอกไข่/โรย/ตกตุ๋ม ตามชนิด ระดับ-สีในภาชนะค่อย ๆ เปลี่ยน (js/cookfx.js)
    const base = CookFx.target(S);
    const col = it.c ? (G.firstDrop ? it.c : mix(base.liquid, it.c, .45)) : null;
    CookFx.toss(at || el, it, clamp(base.fill + (st.fillEach ?? .1), 0, 1), col);
    G.firstDrop = false;
    if (left === 0) G.finish(G.stars(mist)); else armHint();
  };

  G.firstDrop = S.fill === 0;
  pool.forEach(it => {
    const el = document.createElement('button');
    el.type = 'button'; el.className = 'ing'; el.dataset.ok = it.ok ? '1' : '0'; el.dataset.src = it.src;
    el.innerHTML = `<span class="e">${it.e}</span><b></b><small></small>`;
    labelIng(el, it);
    // คีย์บอร์ด (Enter/Space) ส่ง click ที่ detail = 0
    el.addEventListener('click', e => { if (e.detail === 0) drop(it, el); });
    el.addEventListener('pointerdown', e => {
      if (e.button > 0 || G.busy || el.classList.contains('used') || el.classList.contains('nope')) return;
      e.preventDefault();
      Sound.unlock();
      // ลากแนวนอน = เลื่อนสายพาน (Conveyor ใน pests.js จัดการ) ; ลากขึ้น/เฉียงขึ้นไปที่ฉาก = หยิบของ ; แตะเฉย ๆ = ใส่เลย
      const sx = e.clientX, sy = e.clientY, id = e.pointerId;
      let moved = 0, g = null, lx = sx, ly = sy, raf = 0, over = false, box = null;
      // ขยับตัวที่ลากแค่ครั้งเดียวต่อเฟรม และอ่านตำแหน่งฉากครั้งเดียวตอนเริ่มลาก (ไม่บังคับเบราว์เซอร์คำนวณเลย์เอาต์ทุกครั้งที่นิ้วขยับ)
      const paint = () => {
        raf = 0;
        if (!g) return;
        g.style.transform = `translate3d(${lx}px,${ly}px,0) translate(-50%,-60%) rotate(-6deg) scale(1.12)`;
        const n = near(box, lx, ly);
        if (n !== over) { over = n; stageEl().classList.toggle('over', n); }
      };
      const mv = ev => {
        if (ev.pointerId !== id) return;
        if (dead) { off(); return; }
        lx = ev.clientX; ly = ev.clientY;
        moved = Math.max(moved, Math.hypot(lx - sx, ly - sy));
        // ชั้นแบบสายพาน: ลากแนวนอน = ผู้เล่นเลื่อนชั้นอยู่ ไม่หยิบ ; ชั้นแบบเดิม (เบราว์เซอร์เก่า) หยิบได้ทุกทิศ
        const lift = !Conveyor.el || Math.abs(ly - sy) >= Math.abs(lx - sx) * .6;
        if (!g && moved > 8 && lift && !Conveyor.drag) {
          Conveyor.claimed = true;                     // บอกสายพานว่านิ้วนี้หยิบของแล้ว ไม่ต้องเลื่อนชั้น
          box = stageEl().getBoundingClientRect();
          g = el.cloneNode(true); g.classList.add('ghost');
          g.style.removeProperty('translate');         // ตำแหน่งบนสายพานไม่ต้องติดมากับตัวที่ลาก
          g.style.width = el.offsetWidth + 'px';
          document.body.appendChild(g); ghost = g;
          Sound.play('pop');
          paint();                                   // วางตำแหน่งทันที ไม่ให้กระพริบที่มุมจอ
        } else if (g && !raf) raf = requestAnimationFrame(paint);
      };
      const off = () => {
        cancelAnimationFrame(raf); raf = 0;
        removeEventListener('pointermove', mv);
        removeEventListener('pointerup', up);
        removeEventListener('pointercancel', up);
      };
      const up = ev => {
        if (ev.pointerId !== id) return;
        off();
        if (g) { g.remove(); if (ghost === g) ghost = null; }
        stageEl().classList.remove('over');
        if (ev.type === 'pointercancel' || (!g && moved > 8)) return;   // เลื่อนชั้นอยู่ ไม่ใช่หยิบ
        if (!g || near(box || stageEl().getBoundingClientRect(), ev.clientX, ev.clientY)) drop(it, el, g ? [ev.clientX, ev.clientY] : null);  // แตะเฉย ๆ ก็ใส่ได้
      };
      addEventListener('pointermove', mv, { passive: true });
      addEventListener('pointerup', up);
      addEventListener('pointercancel', up);
    });
    shelf.appendChild(el);
  });
  // เพื่อนช่วย: ชี้ของที่ถูกบนสายพาน (สายพานพามากลางชั้น + ไฮไลต์) — ไม่หยิบแทน
  G.assist = Object.assign(() => {
    const nx = $$('.ing', shelf).find(e => e.dataset.ok === '1' && !e.classList.contains('used'));
    if (dead || !nx) return false;
    clearHint(); nx.classList.add('hint'); Conveyor.show(nx);
    return true;
  }, { kind: 'drag' });
  Conveyor.start(shelf);                                 // ชั้นวิ่งวนแบบสายพาน (ลากเลื่อนเองได้)
  // ด่านฝึก: วางตัวที่ถูกไว้กลางชั้นก่อน มือ 👆 สาธิตจะชี้ถูกที่
  if (Tutor.on) Conveyor.show($('.ing[data-ok="1"]', shelf), true);
  armHint();

  return () => {
    dead = true; clearHint(); Conveyor.stop();
    shelf.innerHTML = '';
    stageEl().classList.remove('over');
    if (ghost) ghost.remove();
    $$('.ing.ghost').forEach(g => g.remove());
  };
};

/* ---------------------------------------------------------------------
   2) STIR — คน/ตี: ถูนิ้ววน ๆ (หรือถูไปมาก็ได้) บนฉาก หรือแตะรัว ๆ
   - นับจากระยะที่นิ้วเคลื่อนที่จริง จึงไม่ต้องวนเป็นวงกลมเป๊ะ
   - ขั้นที่ต้อง "คนเบา ๆ" จะเตือนถ้าเร็วเกิน (โหมดง่ายแทบไม่เตือน)
   --------------------------------------------------------------------- */
MECH.stir = st => {
  const S = G.S, A = Settings.assist(), c = st.stir;
  const need = c.rev * A.rev, limit = (c.limit || 2.4) * A.gentle, tapGain = need / A.tapN;
  const f0 = S.fill, fTo = c.fillTo ?? S.fill, c0 = S.liquid;
  let acc = 0, pressed = false, lx = 0, ly = 0, sx = 0, sy = 0, mist = 0, done = false, box = null;
  let wAcc = 0, wT = performance.now(), lastW = 0, warnT = 0, quarter = 0;
  S.spoonOn = true; S.spoon = 0;
  UI.meter('fill');
  UI.instr(c.gentle ? 'in.stir.gentle' : 'in.stir.fast');
  stageEl().classList.add('ptr');

  const progress = () => {
    if (done) return;
    const p = clamp(acc / need, 0, 1);
    UI.meterFill(p);
    S.fill = lerp(f0, fTo, p);
    if (c.to) S.liquid = mix(c0, c.to, p);
    requestDraw();
    if (p >= 1) { done = true; G.finish(G.stars(mist)); }
    else if (p * 4 >= quarter + 1) { quarter = Math.floor(p * 4); Helpers.help(); }   // ทุก 1/4 ทาง เพื่อนช่วยคนด้วย
  };
  // เพื่อนลงมือช่วยคน: ครั้งละ 12% (รวมไม่เกิน 36% และไม่คนจนจบแทนผู้เล่น)
  let lent = 0;
  G.assist = Object.assign(() => {
    const add = need * .12;
    if (done || lent + add > need * .37 || acc + add >= need * .92) return false;
    acc += add; lent += add; S.spoon += 1.4; Sound.play('whoosh'); progress();
    return true;
  }, { kind: 'stir' });
  G.mech = {
    down(e) {
      if (e.button > 0) return;
      pressed = true; lx = sx = e.clientX; ly = sy = e.clientY;
      box = stageEl().getBoundingClientRect();         // อ่านครั้งเดียวตอนแตะ ไม่ต้องอ่านทุกครั้งที่นิ้วขยับ
      try { stageEl().setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
    },
    move(e) {
      if (!pressed || G.busy || done) return;
      const d = Math.hypot(e.clientX - lx, e.clientY - ly);
      if (d < 1) return;
      const r = box || (box = stageEl().getBoundingClientRect());
      lx = e.clientX; ly = e.clientY;
      const rev = d / (Math.PI * r.width * .5);       // 1 รอบ ≈ วงกลมกว้างครึ่งฉาก
      acc += rev; wAcc += rev;
      S.spoon = Math.atan2(e.clientY - (r.top + r.height * .62), e.clientX - (r.left + r.width * .5));
      const now = performance.now();
      if (now - wT > 200) {
        const sp = wAcc / ((now - wT) / 1000); wAcc = 0; wT = now;
        if (c.gentle && sp > limit && now - warnT > 1200) {
          warnT = now; mist++; Sound.play('oops'); Chars.mood('oops');
          UI.flash(t('flash.slow'));
          G.miss();                                      // คนแรงเกิน = เสียหัวใจ 1 ดวง
        }
      }
      if (now - lastW > 260) { lastW = now; Sound.play('whoosh'); }
      progress();
    },
    up(e) {
      if (!pressed) return;
      pressed = false;
      if (e.type !== 'pointercancel' && Math.hypot(e.clientX - sx, e.clientY - sy) < 10) {
        acc += tapGain; S.spoon += 1.2; Sound.play('whoosh'); vibrate(8); progress();
      }
    }
  };
  return () => { done = true; S.spoonOn = false; stageEl().classList.remove('ptr'); G.mech = null; };
};

/* ---------------------------------------------------------------------
   3) SWIPE — ร่อนแป้ง/กรอง: ถูนิ้วซ้าย-ขวา หรือแตะที่กระชอน
   - ระยะที่ต้องถู ปรับตามขนาดจอ (จอเล็กถูสั้นกว่า)
   --------------------------------------------------------------------- */
MECH.swipe = st => {
  const S = G.S, A = Settings.assist(), n = Math.max(2, Math.round(st.swipe.n * A.swipe)), f0 = S.fill;
  let cnt = 0, pressed = false, lx = 0, sx = 0, sy = 0, dist = 0, dT = 0, done = false, step = 0;
  S.sieve = true; S.sieveX = 0; S.dust = false; S.dustColor = st.swipe.dust;
  UI.meter('fill');
  UI.instr('in.swipe');
  stageEl().classList.add('ptr');

  const stepLen = () => step || (step = Math.max(26, stageEl().clientWidth * .14));
  const bump = () => {
    if (done) return;
    cnt++; Sound.play('tap'); vibrate(8);
    S.fill = clamp(f0 + (st.swipe.fillTo ?? .1) * cnt / n, 0, 1);
    UI.meterFill(cnt / n);
    S.dust = true; clearTimeout(dT);
    dT = setTimeout(() => { S.dust = false; requestDraw(); }, 450);
    requestDraw();
    CookFx.dust(S);                                      // แป้งที่ร่อนตกลงชามฟุ้งขึ้นมานิด ๆ
    if (cnt >= n) { done = true; G.finish(3); }
    else if (cnt % 2 === 0) Helpers.help();             // เพื่อนช่วยร่อนแป้ง
  };
  // เพื่อนลงมือช่วยร่อน 1 ครั้ง (ครั้งสุดท้ายให้ผู้เล่นทำเอง)
  G.assist = Object.assign(() => {
    if (done || cnt + 1 >= n) return false;
    bump();
    return true;
  }, { kind: 'swipe' });
  G.mech = {
    down(e) {
      if (e.button > 0) return;
      pressed = true; sx = lx = e.clientX; sy = e.clientY; dist = 0; step = 0;   // วัดขนาดฉากใหม่ทุกครั้งที่แตะ (เผื่อหมุนจอ)
      try { stageEl().setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
    },
    move(e) {
      if (!pressed || G.busy || done) return;
      const dx = e.clientX - lx; lx = e.clientX;
      S.sieveX = clamp((e.clientX - sx) * .5, -50, 50);
      dist += Math.abs(dx);
      if (dist > stepLen()) { dist = 0; bump(); } else { S.dust = true; requestDraw(); }
    },
    up(e) {
      if (!pressed) return;
      pressed = false; S.sieveX = 0;
      if (e.type !== 'pointercancel' && Math.hypot(e.clientX - sx, e.clientY - sy) < 10) bump();
      else requestDraw();
    }
  };
  return () => { done = true; S.sieve = false; S.dust = false; clearTimeout(dT); stageEl().classList.remove('ptr'); G.mech = null; };
};

/* ---------------------------------------------------------------------
   4) TAP — เทลงถ้วย / ปิดฟอยล์ / หมุนปุ่มเตา / เปิดตู้เย็น
   - แตะตรงไหนบนฉากก็ได้ ระบบเลือกถ้วยถัดไปให้เอง
   --------------------------------------------------------------------- */
MECH.tap = st => {
  const S = G.S, tp = st.tap;                        // (ไม่ใช้ชื่อ t เพราะชนกับ t() แปลภาษา)
  let c = 0, done = false;
  S.tapOn = true; S.tapFlag = tp.flag || '';         // ให้ฉากกระพริบชิ้นที่ต้องแตะต่อไป (stage.js → tapCls)
  UI.meter('fill');
  UI.instr(tp.dial ? 'in.tap.dial' : tp.door ? 'in.tap.door' : 'in.tap.cups');
  // el = ชิ้นที่แตะ (null = ชิ้นถัดไป) — ผู้เล่นแตะ หรือเพื่อนช่วยทำ ใช้ทางเดียวกัน
  const apply = el => {
    if (tp.flag) {
      let i = el ? +el.dataset.i : -1;
      if (i < 0 || !S.cups[i] || S.cups[i][tp.flag]) i = S.cups.findIndex(x => !x[tp.flag]);
      if (i < 0) return false;
      S.cups[i][tp.flag] = 1;
      // เทคาราเมล/แป้งลงถ้วยนั้นเป็นสาย (สมจริง) ; ถาดคุกกี้ไม่ใช่ถ้วยเรียงแถว จึงไม่มีสายเท
      if ((tp.flag === 'caramel' || tp.flag === 'batter') && S.items !== 'cookie')
        CookFx.pourCup(i, S.cups.length, tp.flag === 'caramel' ? '#d98a2b' : bakeColor(S.items, 0));
    }
    if (tp.dial) { S.dial++; S.temp = Math.round(25 + (tp.temp - 25) * (c + 1) / tp.n) + '°C'; if (c + 1 >= tp.n) S.hot = true; }
    if (tp.door) S.door = (c + 1) % 2;
    c++;
    Sound.play(tp.dial ? 'click' : 'tap');
    if (tp.flag === 'caramel' || tp.flag === 'batter') Sound.play('pour');
    vibrate(10);
    UI.meterFill(c / tp.n);
    drawStage();
    if (c >= tp.n) { done = true; G.finish(3); }
    else Helpers.help();                                 // เพื่อนช่วยแต่งหน้า/ส่งถ้วยให้
    return true;
  };
  const h = e => {
    if (done || G.busy || e.button > 0) return;
    apply(e.target.closest ? e.target.closest('.tapT') : null);
  };
  // เพื่อนลงมือช่วยทำ 1 ชิ้น (ชิ้นสุดท้ายให้ผู้เล่นทำเอง)
  G.assist = Object.assign(() => (done || c + 1 >= tp.n ? false : apply(null)), { kind: 'tap' });
  stageEl().addEventListener('pointerdown', h);
  return () => { done = true; S.tapOn = false; stageEl().removeEventListener('pointerdown', h); };
};

/* ---------------------------------------------------------------------
   5) TIMING — กดให้ตรงตอนเข็มอยู่ในโซนสีเขียว
   - เข็มวิ่งเร็วช่วงแรก (ไม่ต้องรอนาน) แล้วช้าลงในโซนเขียว
   - ปุ่มเปลี่ยนเป็นสีเขียว + สั่นเบา ๆ เมื่อถึงเวลากด
   - แตะที่ภาพก็ได้ (แต่ต้องใกล้โซนแล้ว กันแตะพลาดตอนเปลี่ยนขั้น)
   --------------------------------------------------------------------- */
MECH.timing = st => {
  const S = G.S, A = Settings.assist(), tm = st.timing;   // (ไม่ใช้ชื่อ t เพราะชนกับ t() แปลภาษา)
  const mid = (tm.zone[0] + tm.zone[1]) / 2, half = Math.min(.28, (tm.zone[1] - tm.zone[0]) / 2 * A.zone);
  const z = [mid - half, mid + half];
  const act = $('#act'), meter = $('#meter'), burnAt = Tutor.on ? .06 : (A.burn ?? .03);
  let ph = 0, raf = 0, last = performance.now(), siz = 0, inZ = false, q = -1, done = false, warnT = 0;

  UI.meter('time', z);
  UI.instr('in.timing');
  act.textContent = tm.label; act.hidden = false; act.classList.remove('ready');
  S.heat = true; S.boil = false;
  // เสียงฉ่า ๆ พักไปด้วยตอนเปิดหน้าต่างตั้งค่า/สมุดสูตร (เข็มก็หยุดรอ)
  if (tm.sizzle || tm.bake) { Sound.play('sizzle'); siz = setInterval(() => { if (!$('.overlay.open') && $('#lose').hidden) Sound.play('sizzle'); }, 600); }

  const upd = force => {
    if (tm.liquid) S.liquid = ph < tm.mid ? mix(tm.colors[0], tm.colors[1], ph / tm.mid) : mix(tm.colors[1], tm.colors[2], (ph - tm.mid) / (1 - tm.mid));
    if (tm.bake) S.bake = ph;
    if (tm.warm) S.boil = ph > .72;
    UI.needle(ph);
    // อัปเดตสีในฉาก 100 ระดับตลอดทาง (stage.js แก้แค่สีที่เปลี่ยน จึงเนียนตาและไม่กิน CPU)
    const nq = Math.round(ph * 100);
    if (force || nq !== q) { q = nq; drawStage(); }
  };
  /* หยุดเข็ม: ในโซนเขียว = ผ่าน (กลางโซน 3 ดาว / ขอบโซน 2 ดาว)
     นอกโซน = ขนมเสีย → แพ้ เริ่มเมนูใหม่ (โหมดสอนเล่น: แค่ลองขั้นนี้ใหม่) */
  const stop = () => {
    if (done) return;
    done = true; cancelAnimationFrame(raf); clearInterval(siz);
    act.classList.remove('ready'); meter.classList.remove('ready');
    const d = Math.abs(ph - mid);
    if (d > half) {
      const kind = ph < z[0] ? 'raw' : 'burnt';
      if (kind === 'burnt' && tm.bake) S.bake = 1.25;    // สีไหม้เข้ม
      upd(true); S.heat = false; drawStage();
      G.fail(kind);
      return;
    }
    S.heat = false; if (tm.bake) S.baked = true;
    const n = d <= half * .55 ? 3 : 2, txt = t(n === 3 ? 'tm.3' : 'tm.2');
    G.base = txt; UI.say(txt); upd(true);
    G.finish(n);
  };
  const tooEarly = () => {
    const now = performance.now();
    if (now - warnT > 900) { warnT = now; UI.flash(t('flash.early'), 1400); Sound.play('click'); }
  };
  const loop = now => {
    if (done) return;
    const dt = Math.min(.1, Math.max(0, (now - last) / 1000)); last = now;   // กันเข็มกระโดดหลังสลับแอป
    if (!document.querySelector('.overlay.open')) {
      const inside = ph >= z[0] && ph <= z[1];
      const mult = inside ? A.slowZone : ph < z[0] - .12 ? A.approach : 1;
      ph = Math.min(1, ph + tm.speed * A.speed * (Tutor.on ? .8 : 1) * mult * dt);   // โหมดสอนเล่น: เข็มช้าลงนิดหน่อย
      const nz = ph >= z[0] && ph <= z[1];
      if (nz !== inZ) {
        inZ = nz;
        act.classList.toggle('ready', nz); meter.classList.toggle('ready', nz);
        if (nz) {
          Sound.play('click'); vibrate(25);
          Helpers.now();                                 // เพื่อนกระโดดตะโกน "กดเลย!"
          if (Tutor.on) Tutor.step(st, 'zone');           // ด่านสอนเล่น: ส่องไฟที่ปุ่ม "กดเลย!"
        }
      }
      upd(false);
      // เลยโซนเขียว = ไหม้ทันที (เผื่อนิ้วช้านิดเดียวตามความยาก) — ไม่ต้องรอเข็มวิ่งสุดแถบ
      if (ph >= 1 || ph > z[1] + burnAt) { stop(); return; }
    }
    raf = requestAnimationFrame(loop);
  };
  raf = requestAnimationFrame(loop);

  const press = () => {
    if (G.busy || done) return;
    if ((A.early || Tutor.on) && ph < z[0]) return tooEarly();   // โหมดง่าย/สอนเล่น: กดก่อนโซนแค่เตือน ไม่นับ
    stop();
  };
  // นับตั้งแต่นิ้วแตะปุ่ม (ไม่ต้องรอยกนิ้ว) → ตรงจังหวะกว่าเดิม ; คีย์บอร์ด Enter/Space ยังใช้ click ได้
  act.onpointerdown = e => { if (e.button > 0) return; Sound.unlock(); press(); };
  act.onclick = e => { if (e.detail === 0) press(); };
  const stageTap = e => {
    if (e.button > 0 || G.busy || done) return;
    if (ph < z[0]) return tooEarly();                    // แตะภาพก่อนโซน = เตือนเฉย ๆ (กันแตะโดนโดยไม่ตั้งใจแล้วแพ้)
    stop();
  };
  stageEl().addEventListener('pointerdown', stageTap);

  return () => {
    done = true; cancelAnimationFrame(raf); clearInterval(siz);
    act.hidden = true; act.onclick = null; act.onpointerdown = null; act.classList.remove('ready'); meter.classList.remove('ready');
    stageEl().removeEventListener('pointerdown', stageTap);
    S.heat = false;
  };
};
