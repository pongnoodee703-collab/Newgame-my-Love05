'use strict';
/* =====================================================================
   start-screen.js — ลูกเล่นหน้าเริ่มเกม (ร้านขนมปังโทนน้ำตาล)
   ฉากหลังเป็น CSS ล้วน (css/start.css) ไฟล์นี้สร้างฝุ่นแป้งระยิบระยับ + ขนมร่วง
   และผูกการแตะ: ชื่อร้าน = หัวใจลอย, เพื่อน ๆ กระโดด/พูด, ลากขนมเล่น, คุกกี้กรุบ
   ขนมร่วงสร้างครั้งเดียวแล้ววนด้วย CSS (ไม่สร้าง/ลบของใหม่ตลอดเวลา ประหยัดแบต ไม่กระตุก)
   ===================================================================== */
const SWEETS = ['🥐', '🍞', '🧁', '🥖', '🍩', '🥨', '🍪', '🥯', '🍰', '🥧', '🍮', '🎂'];
const HEARTS = ['💖', '💕', '💗', '❤️', '🤎', '💞', '💝'];

const StartScreen = {
  init() {
    const scr = $('#screen-start'), small = Env.small;

    /* ฝุ่นแป้งระยิบระยับในแสงไฟ */
    const cols = ['#fff6e3', '#ffe2a8', '#f6d3a0', '#fff'], sp = $('#sparkles'), frag = document.createDocumentFragment();
    for (let i = 0; i < (small ? 8 : 14); i++) {
      const e = document.createElement('i'), s = 4 + Math.random() * 6;
      e.className = 'spark';
      e.style.cssText = `left:${Math.random() * 100}%;top:${8 + Math.random() * 55}%;background:${cols[i % 4]};animation-delay:${Math.random() * 2.2}s;width:${s}px;height:${s}px`;
      frag.appendChild(e);
    }
    sp.appendChild(frag);

    /* ขนมร่วงลงมาช้า ๆ จากใต้กันสาด (ฉากหลังเฉย ๆ แตะไม่ได้ ไม่บังปุ่ม)
       กระจายตำแหน่งเป็นช่อง ๆ ให้ทั่วจอ + เวลาเริ่มติดลบ → เปิดมาก็ร่วงอยู่แล้ว ไม่โผล่พร้อมกัน */
    const rain = $('#sweets'), n = small ? 9 : 14, rf = document.createDocumentFragment();
    for (let i = 0; i < n; i++) {
      const e = document.createElement('i'), dur = 9 + Math.random() * 7;
      e.textContent = SWEETS[i % SWEETS.length];
      e.style.cssText = `left:${((i + Math.random() * .7) * 96 / n).toFixed(1)}%;font-size:${((small ? 22 : 26) + Math.random() * 16).toFixed(0)}px;` +
        `animation-duration:${dur.toFixed(1)}s;animation-delay:-${(Math.random() * dur).toFixed(1)}s;` +
        `--sw:${(Math.random() * 50 - 25).toFixed(0)}px;--rot:${(Math.random() * 360 - 180).toFixed(0)}deg`;
      rf.appendChild(e);
    }
    rain.appendChild(rf);

    /* เชฟ + ขนมลอย (ลากเล่นได้ ปล่อยแล้วเด้งกลับที่) */
    CHAR_KEYS.forEach(k => { const el = $('#pal-' + k); el.innerHTML = charHTML(k, 'cheer'); makeDraggable(el, { snap: true }); });
    ['custard', 'cupcake', 'cookie'].forEach((id, i) => { const el = $('#fl-' + (i + 1)); el.innerHTML = iconSVG(id); makeDraggable(el, { snap: true }); });

    /* เชฟกระโดด + พูด (คำพูดตามภาษาที่เลือก ดู i18n.js → pal.*) */
    const pals = $$('.pal');
    pals.forEach(el => el.addEventListener('pointerdown', () => { this.hop(el); this.say(el); Sound.play('tap'); vibrate(10); }));
    setInterval(() => {
      if (!Screens.is('start') || !Env.motion || document.hidden) return;
      const p = pals[Math.random() * pals.length | 0];
      if (!p.offsetParent) return;                       // ตัวที่ซ่อนอยู่บนจอเล็ก
      this.hop(p); if (Math.random() < .5) this.say(p);
    }, 3200);
    setTimeout(() => Screens.is('start') && this.say($('#pal-girl'), t('pal.girl')[0]), 900);

    /* พื้นหลังขยับตามเมาส์ (เฉพาะคอม) */
    const logo = $('#logo');
    if (Env.mouse) {
      let px = 0, py = 0, q = 0;
      scr.addEventListener('pointermove', e => {
        px = e.clientX / innerWidth - .5; py = e.clientY / innerHeight - .5;
        if (q) return;
        q = requestAnimationFrame(() => {
          q = 0;
          logo.style.transform = `translate(${px * -26}px,${py * -14}px)`;
          sp.style.transform = `translate(${px * 30}px,${py * 20}px)`;
        });
      });
    }

    /* แตะชื่อร้าน (ตรงไหนของป้ายก็ได้) = หัวใจลอยขึ้นจากจุดที่แตะ + ตัวอักษรที่แตะเด้ง */
    logo.addEventListener('pointerdown', e => {
      if (e.button > 0) return;
      Sound.unlock(); Sound.play('ding'); vibrate(10);
      const lt = e.target.closest('.lt, .logo-sub');
      if (lt) { lt.classList.remove('pop'); void lt.offsetWidth; lt.classList.add('pop'); }
      this.hearts(e.clientX, e.clientY);
    });

    /* คุกกี้ติดตัว t: แตะแล้วกรุบ + เศษคุกกี้กระเด็น (ไม่ส่งต่อให้ป้าย จะได้ไม่มีหัวใจซ้อน) */
    const ck = $('#logo-cookie');
    ck.addEventListener('pointerdown', e => {
      e.stopPropagation();
      Sound.unlock(); Sound.play('crunch'); vibrate(15);
      ck.classList.remove('crunch'); void ck.offsetWidth; ck.classList.add('crunch');
      const r = ck.getBoundingClientRect(), pr = scr.getBoundingClientRect();
      ['🍪', '✨', '🟤', '✨'].forEach((em, i) => puff(scr, em, r.left - pr.left + r.width * .3, r.top - pr.top, i * 28 - 42, { size: i % 2 ? '1.1rem' : '1.4rem', delay: i * .04 }));
    });
    ck.addEventListener('click', e => e.stopPropagation());
  },

  /* หัวใจ 7 ดวงพุ่งขึ้นเป็นรูปพัดจากจุดที่แตะ แล้วจางหาย (ใช้ puff เดิม ขยับแค่ transform/opacity) */
  hearts(x, y) {
    if (!Env.motion) return;
    const scr = $('#screen-start'), r = scr.getBoundingClientRect();
    for (let i = 0; i < 7; i++) {
      puff(scr, HEARTS[i], x - r.left - 14 + Math.random() * 20 - 10, y - r.top - 20, (i - 3) * 24 + Math.random() * 14 - 7,
        { size: (1.3 + Math.random() * .9).toFixed(2) + 'rem', delay: i * .045, life: 1350 });
    }
  },

  hop(el) { el.classList.remove('jump'); void el.offsetWidth; el.classList.add('jump'); clearTimeout(el._hopT); el._hopT = setTimeout(() => el.classList.remove('jump'), 700); },
  /* พูด 1 ประโยค (สุ่มจาก pal.* ของตัวนั้น) — บางที (~1 ใน 4) ก็บ่นคิดถึงพ่อหนุ่มกราฟฟิก ; ข้อความยาวค้างนานขึ้นให้อ่านทัน */
  say(el, text) {
    const o = el.querySelector('.speech');
    if (o) o.remove();
    const line = text || (Math.random() < .25 ? t('pal.grumble') : tPick('pal.' + el.id.slice(4)));
    const long = line.length > 18;
    const s = document.createElement('div');
    s.className = 'speech' + (long ? ' long' : ''); s.textContent = line;
    el.appendChild(s); setTimeout(() => s.remove(), long ? 2950 : 1950);
  }
};
