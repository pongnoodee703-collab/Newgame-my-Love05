'use strict';
/* =====================================================================
   stage.js — วาดฉากทำอาหาร (หม้อ / ชาม / ถ้วย / เตาอบ / ตู้เย็น)
   + StageFit: ปรับขนาดฉากให้พอดีพื้นที่ว่างในทุกขนาดจอ
   + requestDraw: รวมการวาดหลายครั้งใน 1 เฟรม (ลื่นขึ้นมากบนมือถือ)
   ===================================================================== */
function miniItems(S){
  const k=S.items,col=bakeColor(k,S.bake);let s='';
  if(k==='ramekin')[110,160,210].forEach(x=>s+=`<path d="M${x-16} 160 L${x+16} 160 L${x+12} 186 L${x-12} 186Z" fill="#fffaf2" stroke="#d9b48a" stroke-width="2"/><rect x="${x-12}" y="164" width="24" height="10" fill="${col}"/><rect x="${x-11}" y="176" width="22" height="9" fill="#d98a2b"/>`);
  else if(k==='cupcake')[100,140,180,220].forEach(x=>{const h=10+14*clamp(S.bake*1.5,0,1);s+=`<path d="M${x-14} 168 L${x+14} 168 L${x+10} 186 L${x-10} 186Z" fill="#c98d55"/><path d="M${x-14} 168 Q${x} ${168-h*2} ${x+14} 168Z" fill="${col}"/>`});
  else [[110,150],[160,150],[210,150],[110,176],[160,176],[210,176]].forEach(([x,y])=>s+=cookieDraw(x,y,12,col,false,false));
  return s;
}
function potSVG(S){
  const lvl=S.fill*84,liq=S.liquid;let fl='',bub='',st='';
  if(S.heat){fl=[104,138,172,206].map((x,i)=>`<path class="flame" style="animation-delay:${i*.1}s" d="M${x+10} 212 C${x+1} 218 ${x+2} 228 ${x+10} 228 C${x+18} 228 ${x+19} 218 ${x+10} 212Z" fill="${i%2?'#ffd36e':'#ff9a8b'}"/>`).join('');
    st=[130,160,190].map((x,i)=>`<path class="steam" style="animation-delay:${i*.5}s" d="M${x} 100 q-8 -12 0 -22 q8 -10 0 -20" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/>`).join('');}
  if((S.heat||S.boil)&&S.fill>0)bub=[100,130,160,190,215].map((x,i)=>`<circle class="bub" style="animation-delay:${i*.23}s" cx="${x}" cy="${200-lvl*.4}" r="${4+i%3*2}" fill="#fff" opacity=".7"/>`).join('');
  return `<defs><clipPath id="pc"><path d="M70 118 H250 V188 Q250 208 230 208 H90 Q70 208 70 188Z"/></clipPath></defs>
  <rect x="40" y="226" width="240" height="28" rx="14" fill="#6e5a4c" stroke="#4e3e33" stroke-width="3"/><circle cx="80" cy="240" r="6" fill="#d9b48a"/><circle cx="160" cy="240" r="6" fill="#d9b48a"/><circle cx="240" cy="240" r="6" fill="#d9b48a"/>
  ${fl}
  <rect x="34" y="132" width="32" height="12" rx="6" fill="#8a5a35"/><rect x="254" y="132" width="32" height="12" rx="6" fill="#8a5a35"/>
  <path d="M64 112 H256 V190 Q256 214 232 214 H88 Q64 214 64 190Z" fill="#e3a274" stroke="#b5683c" stroke-width="3"/>
  <path d="M70 118 H250 V188 Q250 208 230 208 H90 Q70 208 70 188Z" fill="#f7dcc6"/>
  <g clip-path="url(#pc)"><rect x="60" y="${208-lvl}" width="200" height="${lvl+10}" fill="${liq}"/><ellipse cx="160" cy="${208-lvl}" rx="92" ry="6" fill="#fff" opacity=".28"/>${swirl(S,208-lvl)}${bub}</g>
  <rect x="58" y="106" width="204" height="14" rx="7" fill="#cc8656"/><rect x="80" y="140" width="9" height="46" rx="4" fill="#fff" opacity=".4"/>
  ${st}`;
}
/* ตอนคน: ลายวนบนผิวแป้ง/ของเหลวหมุนตามช้อน (แก้แค่ตัวเลข dashoffset — วาดซ้ำแทบไม่เสียแรง) */
function swirl(S,y){
  if(!S.spoonOn||S.fill<=0)return '';
  const o=((S.spoon||0)*22)%44;
  return `<ellipse cx="160" cy="${y+9}" rx="64" ry="7" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2.5" stroke-dasharray="26 18" stroke-dashoffset="${o.toFixed(1)}"/><ellipse cx="160" cy="${y+12}" rx="36" ry="4" fill="none" stroke="#fff" stroke-opacity=".4" stroke-width="2" stroke-dasharray="14 12" stroke-dashoffset="${(-o).toFixed(1)}"/>`;
}
function bowlSVG(S){
  const lvl=S.fill*88,y=206-lvl,liq=S.liquid;let sp='',sv='';
  if(S.spoonOn){const a=S.spoon,tx=160+46*Math.cos(a),ty=170+12*Math.sin(a);
    sp=`<line x1="${tx}" y1="${ty}" x2="${tx+36}" y2="${ty-96}" stroke="#f4b58a" stroke-width="10" stroke-linecap="round"/><ellipse cx="${tx}" cy="${ty}" rx="13" ry="8" fill="#f4b58a" stroke="#d98f60" stroke-width="2"/>`;}
  if(S.sieve){const x=S.sieveX||0;
    sv=`<g transform="translate(${x} 0)"><path d="M100 66 H220 Q220 106 160 112 Q100 106 100 66Z" fill="#f4f1ea" stroke="#b9ad98" stroke-width="3"/><path d="M112 78 H208 M118 92 H202 M130 66 V106 M160 66 V112 M190 66 V106" stroke="#d8cdb8" stroke-width="2"/><rect x="216" y="60" width="64" height="10" rx="5" transform="rotate(-10 216 65)" fill="#a8703f"/>
    ${S.dust?[125,145,165,185].map((p,i)=>`<circle class="dust" style="animation-delay:${i*.13}s" cx="${p}" cy="112" r="4" fill="${S.dustColor||'#fffaf0'}"/>`).join(''):''}</g>`;}
  return `<defs><clipPath id="bc"><path d="M72 124 H248 Q248 204 160 206 Q72 204 72 124Z"/></clipPath></defs>
  <ellipse cx="160" cy="236" rx="100" ry="12" fill="#d9b48a"/>
  <path d="M60 120 H260 Q260 218 160 220 Q60 218 60 120Z" fill="#f7ead6" stroke="#d8bf9c" stroke-width="3"/>
  <path d="M68 172 Q160 190 252 172" stroke="#c98a50" stroke-width="7" opacity=".55" fill="none" stroke-linecap="round"/>
  <ellipse cx="160" cy="121" rx="100" ry="13" fill="#e9d4b4"/><ellipse cx="160" cy="123" rx="92" ry="9" fill="#fffaf2"/>
  <g clip-path="url(#bc)"><rect x="60" y="${y}" width="200" height="${lvl+16}" fill="${liq}"/><ellipse cx="160" cy="${y}" rx="90" ry="8" fill="#fff" opacity=".3"/>${swirl(S,y)}</g>
  ${sp}${sv}`;
}
/* ชิ้นที่ต้องแตะต่อไป (กระพริบให้เห็นชัด ชิ้นเดียว) — ตั้งค่าโดย MECH.tap ผ่าน S.tapOn / S.tapFlag */
const tapCls=(S,i)=>`tapT${S.tapOn&&i===(S.tapFlag?S.cups.findIndex(c=>!c[S.tapFlag]):0)?' next':''}`;
function cupsSVG(S){
  const k=S.items,n=S.cups.length;let s='';
  if(k==='cookie'){
    s+=`<rect x="26" y="70" width="268" height="170" rx="22" fill="#c8cbd1" stroke="#a3a7af" stroke-width="4"/><rect x="40" y="84" width="240" height="142" rx="14" fill="#fbf0dc" opacity=".95"/>`;
    S.cups.forEach((c,i)=>{const x=82+(i%3)*78,y=124+((i/3)|0)*72;
      s+=`<g class="${tapCls(S,i)}" data-i="${i}"><g>${c.pipe?cookieDraw(x,y,28,bakeColor('cookie',S.bake),S.baked,c.cool):`<circle cx="${x}" cy="${y}" r="28" fill="#fff" fill-opacity=".01" stroke="#c9ad8a" stroke-width="3" stroke-dasharray="6 6"/>`}</g></g>`;});
    return s;
  }
  const xs=n===3?[60,160,260]:[50,125,200,275],w=n===3?84:66;
  if(S.water)s+=`<rect x="14" y="156" width="292" height="40" rx="12" fill="#bfe3ff" opacity=".85"/><path d="M20 160 q12 -8 24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0" stroke="#fff" stroke-width="3" fill="none" opacity=".7"/>`;
  s+=`<rect x="14" y="188" width="292" height="16" rx="8" fill="#c8cbd1" stroke="#a3a7af" stroke-width="3"/>`;
  S.cups.forEach((c,i)=>{const x=xs[i];s+=`<g class="${tapCls(S,i)}" data-i="${i}"><g><rect x="${x-w/2-4}" y="96" width="${w+8}" height="100" fill="#fff" fill-opacity=".01"/>`;
    if(k==='ramekin'){
      s+=`<defs><clipPath id="rc${i}"><path d="M${x-w/2+4} 124 L${x+w/2-4} 124 L${x+w*.39-3} 188 L${x-w*.39+3} 188Z"/></clipPath></defs>
      <path d="M${x-w/2} 120 L${x+w/2} 120 L${x+w*.39} 190 L${x-w*.39} 190Z" fill="#fffaf2" stroke="#d9b48a" stroke-width="3" stroke-linejoin="round"/>
      <g clip-path="url(#rc${i})">${c.caramel?`<rect x="${x-w/2}" y="170" width="${w}" height="22" fill="#d98a2b"/>`:''}${c.batter?`<rect x="${x-w/2}" y="134" width="${w}" height="38" fill="${bakeColor('ramekin',S.bake)}"/>`:''}</g>
      <path d="M${x-w/2+2} 124 H${x+w/2-2}" stroke="#e8c9a0" stroke-width="6" stroke-linecap="round"/><ellipse cx="${x-w*.15}" cy="152" rx="3.6" ry="4.6" fill="#4a2f45"/><circle cx="${x-w*.15+1.4}" cy="150.2" r="1.4" fill="#fff"/><ellipse cx="${x+w*.15}" cy="152" rx="3.6" ry="4.6" fill="#4a2f45"/><circle cx="${x+w*.15+1.4}" cy="150.2" r="1.4" fill="#fff"/><circle cx="${x-w*.27}" cy="160" r="5" fill="#f4a37f" opacity=".7"/><circle cx="${x+w*.27}" cy="160" r="5" fill="#f4a37f" opacity=".7"/><path d="M${x-5} 159 Q${x} 165 ${x+5} 159" stroke="#4a2f45" stroke-width="2.4" fill="none" stroke-linecap="round"/>
      ${c.foil?`<path d="M${x-w/2-5} 122 Q${x} 98 ${x+w/2+5} 122Z" fill="#e3e8f2" stroke="#b5bfd6" stroke-width="3" stroke-linejoin="round"/><path d="M${x-12} 112 Q${x} 104 ${x+8} 108" stroke="#fff" stroke-width="3" fill="none"/>`:''}`;
    }else{
      const h=12+22*clamp(S.bake*1.5,0,1),top=130-h;
      s+=c.liner?`<path d="M${x-w/2} 130 L${x+w/2} 130 L${x+w*.38} 190 L${x-w*.38} 190Z" fill="#c98d55" stroke="#93602f" stroke-width="3" stroke-linejoin="round"/><path d="M${x-w*.2} 134 L${x-w*.15} 188 M${x} 134 V188 M${x+w*.2} 134 L${x+w*.15} 188" stroke="#e7bd8a" stroke-width="3" opacity=".9"/>`
        :`<path d="M${x-w/2} 130 L${x+w/2} 130 L${x+w*.38} 190 L${x-w*.38} 190Z" fill="none" stroke="#c9ad8a" stroke-width="3" stroke-dasharray="6 6"/>`;
      if(c.liner&&c.batter)s+=`<path d="M${x-w/2+2} 130 Q${x} ${top-8} ${x+w/2-2} 130Z" fill="${bakeColor('cupcake',S.bake)}" stroke="rgba(90,44,16,.2)" stroke-width="2"/>`;
      if(c.liner)s+=`<ellipse cx="${x-w*.14}" cy="160" rx="3.3" ry="4.3" fill="#4a2f45"/><circle cx="${x-w*.14+1.2}" cy="158.4" r="1.3" fill="#fff"/><ellipse cx="${x+w*.14}" cy="160" rx="3.3" ry="4.3" fill="#4a2f45"/><circle cx="${x+w*.14+1.2}" cy="158.4" r="1.3" fill="#fff"/><circle cx="${x-w*.25}" cy="168" r="4.5" fill="#f6a07c" opacity=".75"/><circle cx="${x+w*.25}" cy="168" r="4.5" fill="#f6a07c" opacity=".75"/><path d="M${x-4.5} 167 Q${x} 172.5 ${x+4.5} 167" stroke="#4a2f45" stroke-width="2.2" fill="none" stroke-linecap="round"/>`;
      if(c.frost)s+=`<ellipse cx="${x}" cy="${top-2}" rx="${w*.4}" ry="8" fill="#fff" stroke="#f3cfe0" stroke-width="2"/><ellipse cx="${x}" cy="${top-11}" rx="${w*.3}" ry="8" fill="#ffd1e4" stroke="#f3a8c9" stroke-width="2"/><ellipse cx="${x}" cy="${top-19}" rx="${w*.18}" ry="6" fill="#fff" stroke="#f3cfe0" stroke-width="2"/><circle cx="${x}" cy="${top-28}" r="6" fill="#ff5f87"/><circle cx="${x-2}" cy="${top-30}" r="1.8" fill="#fff" opacity=".7"/><rect x="${x-w*.26}" y="${top-5}" width="6" height="2.6" rx="1.3" fill="#8fd7ff" transform="rotate(-25 ${x-w*.26} ${top-5})"/><rect x="${x+w*.16}" y="${top-6}" width="6" height="2.6" rx="1.3" fill="#ffd84d" transform="rotate(25 ${x+w*.16} ${top-6})"/><rect x="${x-5}" y="${top-14}" width="6" height="2.6" rx="1.3" fill="#b9f0dc"/><rect x="${x+w*.1}" y="${top-14}" width="6" height="2.6" rx="1.3" fill="#c9b8ff" transform="rotate(30 ${x+w*.1} ${top-14})"/>`;
    }
    s+=`</g></g>`;});
  return s;
}
function ovenSVG(S){
  const glow=S.hot||S.heat;
  return `<defs><radialGradient id="glow" cx="50%" cy="70%" r="70%"><stop offset="0" stop-color="#ffd27a"/><stop offset="1" stop-color="#ff9a6b"/></radialGradient></defs>
  <rect x="50" y="34" width="220" height="208" rx="32" fill="#efe1cc" stroke="#b98a5c" stroke-width="4"/>
  <rect x="50" y="34" width="220" height="50" rx="26" fill="#d9b48a"/>
  <rect x="80" y="48" width="108" height="24" rx="10" fill="#3e2a1e"/><text x="134" y="66" text-anchor="middle" font-family="Fredoka,sans-serif" font-weight="700" font-size="17" fill="${glow?'#ffd36e':'#b9a58c'}">${S.temp||'25°C'}</text>
  <circle cx="206" cy="60" r="4" fill="#fff"/>
  <g class="${tapCls(S,0)}" data-i="0"><g transform="rotate(${(S.dial||0)*70} 240 60)"><circle cx="240" cy="60" r="15" fill="#fff" stroke="#b98a5c" stroke-width="3"/><rect x="238" y="47" width="4" height="13" rx="2" fill="#d4572f"/></g></g>
  <rect x="72" y="98" width="176" height="118" rx="20" fill="#4a3426" stroke="#fff" stroke-width="5"/>
  <rect x="80" y="106" width="160" height="102" rx="14" fill="${glow?'url(#glow)':'#5e4636'}"/>
  <rect x="86" y="188" width="148" height="6" rx="3" fill="#c8cbd1"/>${miniItems(S)}
  <rect x="100" y="222" width="120" height="10" rx="5" fill="#fff"/>
  ${S.heat?`<text x="92" y="122" font-size="14">✨</text><text x="212" y="130" font-size="12">✨</text>`:''}`;
}
function fridgeSVG(S){
  const open=S.door===1;
  return `<rect x="90" y="18" width="140" height="226" rx="26" fill="${open?'#fff':'#f3ead9'}" stroke="#c9b292" stroke-width="4"/>
  ${open?`<rect x="100" y="30" width="120" height="200" rx="16" fill="#eaf8ff"/><rect x="104" y="112" width="112" height="6" rx="3" fill="#bfe3ff"/><rect x="104" y="196" width="112" height="6" rx="3" fill="#bfe3ff"/><g transform="translate(-16 -18) scale(1.1)">${miniItems({...S,bake:S.bake})}</g><text x="190" y="64" font-size="26">❄️</text>
  <g class="${tapCls(S,0)}" data-i="0"><rect x="48" y="26" width="46" height="210" rx="18" fill="#efe2cc" stroke="#c9b292" stroke-width="4" transform="skewY(4)"/><rect x="58" y="110" width="8" height="40" rx="4" fill="#a8916f"/></g>`
  :`<g class="${tapCls(S,0)}" data-i="0"><g><rect x="90" y="18" width="140" height="226" rx="26" fill="#efe2cc" stroke="#c9b292" stroke-width="4"/><path d="M90 100 H230" stroke="#c9b292" stroke-width="4"/><rect x="108" y="64" width="9" height="30" rx="4" fill="#a8916f"/><rect x="108" y="124" width="9" height="46" rx="4" fill="#a8916f"/><circle cx="196" cy="48" r="5" fill="#a8916f"/><circle cx="212" cy="48" r="5" fill="#a8916f"/><text x="160" y="190" text-anchor="middle" font-size="30">❄️</text></g></g>`}`;
}

const SCENES = { pot: potSVG, bowl: bowlSVG, cups: cupsSVG, oven: ovenSVG, fridge: fridgeSVG };
let _lastSVG = '', _drawQueued = 0, _tpl = null;

/* แก้เฉพาะส่วนที่ต่างกันระหว่างภาพเดิม (a) กับภาพใหม่ (b)
   - ตอนคน/ร่อน/อบ ส่วนใหญ่เปลี่ยนแค่ตัวเลขไม่กี่ค่า จึงไม่ต้องสร้างฉากใหม่ทั้งก้อนทุกเฟรม
   - ชิ้นที่ไม่เปลี่ยนจะอยู่ที่เดิม → แอนิเมชันไฟ/ไอน้ำ/ฟองเดือดไม่เริ่มใหม่ (ไม่กระตุก) */
function morphKids(a, b) {
  const kids = Array.from(b.childNodes);
  for (let i = 0; i < kids.length; i++) {
    const x = a.childNodes[i], y = kids[i];
    if (!x) a.appendChild(y);
    else if (x.nodeType !== y.nodeType || x.nodeName !== y.nodeName) a.replaceChild(y, x);
    else if (y.nodeType === 1) morphNode(x, y);
    else if (x.nodeValue !== y.nodeValue) x.nodeValue = y.nodeValue;
  }
  while (a.childNodes.length > kids.length) a.removeChild(a.lastChild);
}
function morphNode(a, b) {
  const aa = a.attributes, ba = b.attributes;
  for (let i = aa.length - 1; i >= 0; i--) if (!b.hasAttribute(aa[i].name)) a.removeAttribute(aa[i].name);
  for (let i = 0; i < ba.length; i++) { const n = ba[i].name, v = ba[i].value; if (a.getAttribute(n) !== v) a.setAttribute(n, v); }
  morphKids(a, b);
}

/* วาดทันที (ข้ามถ้าภาพไม่เปลี่ยน) */
function drawStage() {
  if (_drawQueued) { cancelAnimationFrame(_drawQueued); _drawQueued = 0; }
  const S = G.S, f = SCENES[S.scene];
  if (!f) return;
  const inner = f(S);
  if (inner === _lastSVG) return;
  const host = $('#stageSvg'), cur = host.firstElementChild;
  const full = () => { host.innerHTML = `<svg viewBox="0 0 320 260" role="img" aria-label="${t('stage.aria')}" data-scene="${S.scene}">${inner}</svg>`; };
  _lastSVG = inner;
  if (!cur || cur.getAttribute('data-scene') !== S.scene) { full(); return; }   // เปลี่ยนฉาก (หม้อ → ชาม → เตาอบ ...) สร้างใหม่ทั้งหมด
  try {
    // ฉากเดิม: แปลงภาพใหม่ใน <template> (ไม่แสดงผล ไม่ชน id) แล้วแก้เฉพาะจุดที่ต่าง
    if (!_tpl) _tpl = document.createElement('template');
    _tpl.innerHTML = `<svg>${inner}</svg>`;
    morphKids(cur, _tpl.content.firstChild);
    _tpl.innerHTML = '';
  } catch (e) { Safe.report('drawStage', e); full(); }       // เบราว์เซอร์แปลก ๆ → วาดแบบเดิมทั้งก้อน
}
/* ขอวาดในเฟรมถัดไป (เรียกถี่แค่ไหนก็วาดแค่ครั้งเดียวต่อเฟรม) */
function requestDraw() {
  if (_drawQueued) return;
  _drawQueued = requestAnimationFrame(() => { _drawQueued = 0; drawStage(); });
}

/* คำนวณขนาดฉากให้ใหญ่ที่สุดเท่าที่พื้นที่ว่างอนุญาต (รักษาสัดส่วน 320:260)
   และไม่ทับเพื่อน 2 ตัวมุมล่าง / แถวบนสุดของครัว (หัวใจ ป้ายร้าน) / ชั้นวางขนมบนผนัง */
const StageFit = {
  MAX: 560,
  KEEP: .7,                                           // ยกชั้นขนมขึ้นแถวบนได้ ถ้าฉากยังใหญ่อย่างน้อย 70% ของขนาดเต็ม (ไม่งั้นเล็กเกินเล่นสะดวก)
  init() {
    const wrap = $('#stagewrap');
    const fit = () => this.fit();
    if ('ResizeObserver' in window) new ResizeObserver(fit).observe(wrap);
    addEventListener('resize', fit);
    addEventListener('orientationchange', () => setTimeout(fit, 300));
  },
  fit() {
    const wrap = $('#stagewrap'), st = $('#stage');
    if (!wrap || !wrap.offsetParent) return;          // หน้าจอเกมยังซ่อนอยู่
    KitchenLayout.reset();                             // ของตกแต่งกลับที่ตั้งต้นทุกครั้ง → ผลเหมือนเดิมเสมอ ไม่ขยับไปมาระหว่างขั้น
    const cs = getComputedStyle(wrap), pt = parseFloat(cs.paddingTop);
    const w = wrap.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    // แผงล่างสูงไม่เท่ากันแต่ละขั้น (ปุ่มเตาอบ/มิเตอร์โผล่เฉพาะบางขั้น) → คิดขนาดฉากจากตอนแผงสูงสุด
    // ฉาก + ของตกแต่งจึงอยู่ที่เดิมทุกขั้น ไม่ยืด-หด/โผล่-หาย ระหว่างเปลี่ยนขั้น ; ส่วนที่เหลือเว้นไว้ด้านล่าง
    // (ใช้ความสูงแบบทศนิยม: ครัว + แผงล่างสูงรวมคงที่ → h เท่ากันทุกขั้น ฉากไม่ยืด-หด 1px ระหว่างเปลี่ยนขั้น)
    const extra = this.panelSpare();
    const h = Math.floor(wrap.getBoundingClientRect().height - pt - parseFloat(cs.paddingBottom) - extra + .02);
    if (w <= 0 || h <= 0) return;
    const hp = $('#helper-l'), hh = (hp && hp.offsetHeight) || clamp(innerHeight * .09, 50, 92), hw = hh * .75 + 10;
    const need = this.topRow(wrap, pt);
    let L = this.layout(w, h, hh, hw, need, 0), shelf = '';
    this.apply(st, L, extra);
    // ชั้นวางขนมบนผนัง (ปัดเลื่อน/หยิบ/แตะเล่นได้ทุกด่าน):
    //   1) วางข้างภาพทำอาหารได้ (จอกว้าง) → ฉากเต็มขนาด
    //   2) ไม่ได้ (มือถือแนวตั้ง ฉากกว้างเต็มจอ) → ยกชั้นขึ้นแถวบนสุดใต้กันสาด แล้วเลื่อน/ย่อฉากลงมาอยู่ใต้ชั้นพอดี (ไม่ทับกัน)
    //   3) จอเตี้ย ฉากจะเล็กเกินไป → ชั้นขึ้นไปแทนที่กันสาด (ซ่อนกันสาด) ประหยัดที่ได้อีก ~30px
    //   4) ยังไม่พอ → KitchenLayout วางบนเคาน์เตอร์ระหว่างเพื่อน 2 ตัว (สุดท้ายจริง ๆ ถึงซ่อน)
    //   (ใต้กันสาด ใช้ได้ถ้าฉากยังใหญ่ ≥ 82% ; แทนที่กันสาด ใช้ได้ถ้าฉาก ≥ KEEP)
    if (KitchenLayout.shelfBeside()) shelf = 'beside';
    else for (const [hi, keep] of [[false, .82], [true, this.KEEP]]) {
      const sb = KitchenLayout.shelfTop(hi);
      if (!sb) break;
      const L2 = this.layout(w, h, hh, hw, need, sb - wrap.offsetTop - pt);
      if (L2.W >= L.W * keep) { L = L2; shelf = hi ? 'top-hi' : 'top'; this.apply(st, L, extra); break; }
      KitchenLayout.shelfReset();
    }
    this.last = { w: Math.round(w), h, extra: Math.round(extra), W: L.W, H: L.H, mb: L.mb, mt: L.mt, need: Math.round(need), shelf };   // ไว้ดีบัก/ทดสอบ
    safeCall(() => KitchenLayout.fit(shelf), 'KitchenLayout');
  },
  apply(st, L, extra) {
    st.style.width = L.W + 'px';
    st.style.height = L.H + 'px';
    st.style.marginBottom = Math.round(L.mb + extra) + 'px';
    st.style.marginTop = L.mt + 'px';
  },
  /* เพื่อน 2 ตัวยืนมุมล่างซ้าย-ขวา: ฉากต้องไม่ทับเพื่อน — เลือกแบบที่ได้ฉากใหญ่กว่า
     แบบ 1 ฉากอยู่เหนือเพื่อน (กว้างเต็ม) ; แบบ 2 ฉากอยู่ระหว่างเพื่อนสองข้าง (สูงเต็ม)
     แบบ 1 ได้เปรียบ (ใต้ฉากระหว่างเพื่อนมีที่บนเคาน์เตอร์ ไว้วางชั้นขนมบนจอเล็ก) → ยอมให้ฉากเล็กกว่าแบบ 2 ได้ถึง 12% */
  layout(w, h, hh, hw, need, sb) {
    const A = this.solve(w, Math.round(hh + 4), h, need, sb), B = this.solve(w - 2 * hw, 0, h, need, sb);
    return A.W >= B.W * .88 ? A : B;
  },
  /* ฉากใหญ่สุดของแบบหนึ่ง: wMax = กว้างสุด, mb = ที่ว่างใต้ฉาก (เพื่อนยืน), need = ขอบล่างแถวหัวใจ/ป้ายร้าน
     sb = ขอบล่างชั้นขนมแถวบน (0 = ไม่มี): "ภาพทำอาหาร" ต้องอยู่ใต้ชั้น — ส่วนบนสุด ART_TOP หน่วยของฉากว่างเสมอ จึงซ้อนใต้ชั้นได้
     หัวใจ/ป้าย: มีที่เหลือแนวตั้ง → เลื่อนฉากลงให้พ้น ; ไม่พอ → ย่อฉากได้ไม่เกิน 10% ; ยังไม่พอ → KitchenLayout ทำแบบกะทัดรัด/ซ่อนของตกแต่งที่ชน */
  solve(wMax, mb, h, need, sb) {
    const R = 320 / 260, a = ART_TOP / 260;
    let H = Math.min(wMax / R, this.MAX / R, h - mb);
    if (sb > 0) H = Math.min(H, (h - mb - sb) / (1 - a));
    let W = Math.round(clamp(H * R, 80, this.MAX));
    H = Math.round(W / R);
    const lo = () => Math.max(0, sb - a * H);
    let mt = Math.max(lo(), Math.min(h - mb - H, need));
    if (need > mt) {
      const W3 = Math.round(Math.min(W, (h - mb - need) * R));
      if (W3 >= W * .9) { W = W3; H = Math.round(W / R); mt = Math.max(lo(), need); }
    }
    return { W, H, mb, mt: Math.ceil(mt) };
  },
  /* แผงล่างของเมนูนี้สูงสุดได้เท่าไหร่ (เฉพาะจอที่แผงอยู่ใต้ครัว ; แนวนอนแผงอยู่ข้าง ๆ ไม่เกี่ยว)
     วัดจาก "สำเนาที่มองไม่เห็น" ของแผง ใส่คำพูด/เคล็ดลับ/คำสั่งที่ยาวที่สุดของเมนูนี้ + ปุ่มเตาอบ + มิเตอร์
     (ไม่แตะแผงจริง → ไม่กระพริบ ไม่รบกวนโปรแกรมอ่านหน้าจอ) → ฉากขนาด/ตำแหน่งเดิมทุกขั้นของเมนู */
  panelSpare() {
    const P = $('.panel'), K = $('#kitchen'), r = G.r;
    if (!P || !K || !r || P.offsetTop < K.offsetTop + K.offsetHeight - 2) return 0;
    const key = [r.id, I18N.lang, P.offsetWidth, innerHeight, document.body.classList.contains('nocap')].join('|');
    if (this._pk === key && this._pv) return Math.max(0, this._pv - P.getBoundingClientRect().height);
    const longest = a => a.reduce((x, y) => (String(y || '').length > String(x).length ? y : x), '');
    const c = P.cloneNode(true);
    c.setAttribute('aria-hidden', 'true');
    c.style.cssText = `position:absolute;left:0;top:0;width:${P.offsetWidth}px;visibility:hidden;pointer-events:none`;
    const say = c.querySelector('#say'), tip = c.querySelector('#tip'), ins = c.querySelector('#instr'), act = c.querySelector('#act'), m = c.querySelector('#meter');
    if (say) say.textContent = longest([...r.steps.map(s => s.say), t('pest.first'), t('pest.teach')]);
    if (tip) tip.textContent = '💡 ' + longest(r.steps.map(s => s.tip));
    if (ins) ins.textContent = longest(['in.drag.touch', 'in.drag.mouse', 'in.stir.gentle', 'in.stir.fast', 'in.swipe', 'in.tap.dial', 'in.tap.door', 'in.tap.cups', 'in.timing'].map(k => t(k)));
    if (act) { act.hidden = false; act.textContent = longest(r.steps.filter(s => s.timing).map(s => s.timing.label)) || '🔥'; }
    if (m) m.className = 'meter time';
    P.parentNode.appendChild(c);                      // อยู่หลังแผงจริง → $('#say') ยังได้ตัวจริงเสมอ
    const h = c.getBoundingClientRect().height;
    c.remove();
    this._pk = key; this._pv = h;
    return Math.max(0, h - P.getBoundingClientRect().height);
  },
  /* ขอบล่างของแถวบนสุด (หัวใจ/ป้ายด่านฝึก/ป้ายร้าน) นับจากขอบในด้านบนของพื้นที่ทำอาหาร (ชั้นขนมคิดแยกใน fit) */
  topRow(wrap, pad) {
    let b = 0;
    ['#lives', '.learn-chip', '#sign'].forEach(s => {
      const e = $(s);
      if (e && e.offsetParent) b = Math.max(b, e.offsetTop + e.offsetHeight);
    });
    return b ? b + 6 - wrap.offsetTop - pad : 0;
  }
};

/* ---------- จัดของตกแต่งบนผนังครัวไม่ให้ทับกัน ----------
   ART_ENV = ขอบเขตที่ภาพทำอาหารใช้จริง (หน่วย viewBox 320×260) รวมทุกขั้นของทั้ง 3 เมนู
   (หม้อ+ไอน้ำ / ถาดถ้วย / ชาม+กระชอน / เตาอบ / ตู้เย็น) → ใช้ค่าคงที่ ของตกแต่งจึงไม่ขยับไปมาระหว่างขั้น
   ลำดับความสำคัญ: หัวใจ (ห้ามซ่อน แค่ย่อ) → ชั้นวางขนม (เล่นได้: ข้างภาพ / แถวบนสุด / ลดช่องที่เห็น / บนเคาน์เตอร์) → ป้ายร้าน → หน้าต่าง → กระดานชอล์ก
   ของตกแต่งที่ไม่มีที่ = ซ่อน (.kl-off) ; ทำงานเฉพาะตอนจัดขนาดฉาก (เปลี่ยนขั้น/หมุนจอ) จึงไม่กินแรงเครื่อง */
const ART_ENV = [[50, 18, 270, 70], [34, 49, 286, 254], [11, 70, 312, 244]];
const ART_TOP = 18;                                    // ขอบบนสุดของ ART_ENV: เหนือเส้นนี้ในฉากว่างเสมอ (ชั้นขนมซ้อนได้)
const KitchenLayout = {
  els() { return { ws: $('.wshelf'), chalk: $('.chalk'), win: $('.window'), sg: $('#sign'), lv: $('#lives'), lc: $('.learn-chip') }; },
  reset() {
    const { ws, chalk, win, sg, lv, lc } = this.els();
    [ws, chalk, win, sg, ...$$('#kitchen .lamp')].forEach(e => { if (e) { e.classList.remove('kl-off', 'on-counter', 'ws-top'); ['top', 'left', 'right', '--wn', 'width'].forEach(k => e.style.removeProperty(k)); } });
    [lv, lc].forEach(e => e && e.classList.remove('tight'));
    const K = $('#kitchen');
    if (K) K.classList.remove('ws-hi');
  },
  shelfReset() {
    const ws = $('.wshelf'), K = $('#kitchen');
    if (K) K.classList.remove('ws-hi');
    if (!ws) return;
    ws.classList.remove('on-counter', 'ws-top');
    ['top', 'left', 'right', '--wn'].forEach(k => ws.style.removeProperty(k));
  },
  /* ตำแหน่งปัจจุบัน: ขอบเขตภาพทำอาหาร (env) + ตัววัดกล่อง/ตรวจชน (พิกัด px ในครัว) */
  geo() {
    const K = $('#kitchen'), st = $('#stage');
    if (!K || !K.offsetParent || !st || !st.offsetWidth) return null;
    const kr = K.getBoundingClientRect(), sr = st.getBoundingClientRect(), s = sr.width / 320, ox = sr.left - kr.left, oy = sr.top - kr.top;
    const env = ART_ENV.map(([x, y, r, b]) => ({ l: ox + x * s, t: oy + y * s, r: ox + r * s, b: oy + b * s }));
    const box = (el, p = {}) => (el && el.offsetParent === K ? { l: el.offsetLeft - (p.x || 0), t: el.offsetTop, r: el.offsetLeft + el.offsetWidth + (p.x || 0), b: el.offsetTop + el.offsetHeight + (p.b || 0) } : null);
    const hit = (a, b, m = 5) => !!(a && b && a.l < b.r + m && a.r > b.l - m && a.t < b.b + m && a.b > b.t - m);
    const clash = (a, others) => env.some(e => hit(a, e, 3)) || others.some(o => hit(a, o));
    return { K, kr, sr, env, box, hit, clash };
  },
  wn(ws) { return Math.round(parseFloat(getComputedStyle(ws).getPropertyValue('--wn'))) || 5; },
  /* ชั้นวางขนม ณ ที่ประจำบนผนัง (CSS) อยู่ข้างภาพทำอาหารได้ไหม โดยไม่ย้ายฉาก
     ลองที่ตั้งต้น → ขยับลงใต้หัวใจ → เห็นน้อยช่องลง (เหลืออย่างน้อย 3 ช่อง ที่เหลือปัดเลื่อนดู) ; ได้ = true (ค้างตำแหน่งที่ได้ไว้) */
  shelfBeside() {
    const g = this.geo(), ws = $('.wshelf');
    if (!g || !ws || ws.offsetParent !== g.K) return false;
    const lives = g.box($('#lives')) || g.box($('.learn-chip')), pcase = g.box($('.pcase'));
    const n0 = this.wn(ws), y0 = ws.offsetTop;
    const y1 = lives && lives.l < ws.offsetLeft + ws.offsetWidth ? Math.max(y0, lives.b + 6) : y0;
    for (let n = n0; n >= 3; n--) {
      ws.style.setProperty('--wn', n);
      for (const y of y1 > y0 ? [y0, y1] : [y0]) {
        ws.style.top = y + 'px';
        if (!g.clash(g.box(ws, { b: 6 }), [lives, pcase])) return true;
      }
    }
    this.shelfReset();
    return false;
  },
  /* ยกชั้นวางขนมขึ้นแถวบนสุดของผนัง (ใต้กันสาด ชิดขวา ; hi = แทนที่กันสาด สำหรับจอเตี้ย)
     → คืนขอบล่างที่ภาพทำอาหารต้องอยู่ใต้ (px จากบนครัว, 0 = ไม่มีชั้น) (+ เงาใต้ชั้น 5 + ระยะกันชน → KitchenLayout.fit ตรวจซ้ำแล้วไม่ชนแน่นอน) */
  shelfTop(hi) {
    const ws = $('.wshelf'), K = $('#kitchen');
    if (!ws || !K || ws.offsetParent !== K) return 0;
    ws.classList.add('ws-top');
    K.classList.toggle('ws-hi', !!hi);
    return ws.offsetTop + ws.offsetHeight + 16;
  },
  /* สุดท้าย (จอเล็กมาก): วางบนเคาน์เตอร์ระหว่างเพื่อน 2 ตัว ใต้ภาพทำอาหาร (เฉพาะแบบที่ฉากอยู่เหนือเพื่อน) */
  shelfCounter(g, ws, lives, pcase) {
    const { K, kr, sr, box, clash } = g;
    if (!StageFit.last || !(StageFit.last.mb > 0)) return null;
    const hb = ['#helper-l', '#helper-r'].map(q => { const e = $(q); if (!e || !e.offsetParent) return null; const r = e.getBoundingClientRect(); return { l: r.left - kr.left, t: r.top - kr.top, r: r.right - kr.left, b: r.bottom - kr.top }; });
    if (!hb[0] || !hb[1]) return null;
    const belt = box($('#shelf')), top = Math.max(hb[0].t, (sr.bottom - kr.top) + 6);
    ws.classList.add('on-counter');
    for (let n = Math.max(this.wn(ws), 4); n >= 3; n--) {
      ws.style.setProperty('--wn', n);
      const wW = ws.offsetWidth, wH = ws.offsetHeight + 5;
      ws.style.left = Math.round((K.clientWidth - wW) / 2) + 'px'; ws.style.right = 'auto';
      ws.style.top = Math.round(top + Math.max(0, (hb[0].b - top - wH) / 2)) + 'px';
      const b = box(ws, { b: 5 });
      if (!clash(b, [lives, pcase, belt, hb[0], hb[1]])) return b;
    }
    this.shelfReset();
    return null;
  },
  /* mode = ที่ StageFit จัดฉากให้ชั้นไว้แล้ว ('beside' ข้างภาพ / 'top', 'top-hi' แถวบนสุด / '' ไม่มีที่บนผนัง) */
  fit(mode) {
    const g = this.geo();
    if (!g) return;
    const { K, env, box, hit, clash } = g, { ws, chalk, win, sg, lv, lc } = this.els();
    const off = el => el.classList.add('kl-off');
    // 0) หัวใจ/ป้ายด่านฝึก: ชนภาพทำอาหาร → แบบกะทัดรัด
    [lv, lc].forEach(e => { const b = box(e); if (b && env.some(x => hit(b, x, 2))) e.classList.add('tight'); });
    const lives = box(lv) || box(lc), pcase = box($('.pcase'));
    // 1) ชั้นวางขนม: ที่ StageFit เตรียมไว้ (กันพลาด: ยังชนอะไร → เห็นน้อยช่องลง) → บนเคาน์เตอร์ระหว่างเพื่อน → ซ่อน
    let sb = null;
    if (ws && ws.offsetParent === K) {
      if (mode) {
        for (let n = this.wn(ws); n >= 3 && !sb; n--) {
          ws.style.setProperty('--wn', n);
          const b = box(ws, { b: 6 });
          if (!clash(b, [lives, pcase])) sb = b;
        }
        if (!sb) this.shelfReset();
      }
      if (!sb) sb = this.shelfCounter(g, ws, lives, pcase);
      if (!sb) off(ws);
    }
    if (ws) safeCall(() => { WallShelf.L = 0; WallShelf.layout(); }, 'WallShelf.layout');
    // 1b) โคมไฟเพดานที่ชนชั้นขนม → ซ่อน
    if (sb) $$('#kitchen .lamp').forEach(l => { if (hit(box(l), sb)) off(l); });
    // 2) ป้ายร้าน (แกว่งได้ เผื่อขอบ)
    let sign = box(sg, { x: 10, b: 6 });
    if (sign && clash(sign, [lives, sb])) { off(sg); sign = null; }
    // 3) หน้าต่าง (+ผ้าม่านถ้ามี + ขอบหน้าต่าง): ชน → ย่อเล็กลง → ยังชนก็ซ่อน
    const cur = win && win.querySelector('i'), px = cur && getComputedStyle(cur).display !== 'none' ? 18 : 6;
    let wb = box(win, { x: px, b: 16 });
    if (wb && clash(wb, [lives, sign, sb, pcase])) {
      win.style.width = '44px'; wb = box(win, { x: px, b: 14 });
      if (clash(wb, [lives, sign, sb, pcase])) { off(win); win.style.removeProperty('width'); wb = null; }
    }
    // 4) กระดานชอล์ก: ที่ตั้งต้น → ซ้ายใต้หัวใจ (แคบลงให้พอดีที่ว่างข้างภาพทำอาหาร) → ซ่อน
    // 5) ตู้ขนมปังด้านหลัง: ชิ้นที่อยู่หลังฉากทำอาหาร (โผล่ใต้หม้อ/ชามดูรก ลายตา) → ซ่อน เหลือเฉพาะสองข้างฉาก
    const sk = { l: g.sr.left - g.kr.left, t: g.sr.top - g.kr.top, r: g.sr.right - g.kr.left, b: g.sr.bottom - g.kr.top };
    $$('.pcase i').forEach(i => {
      const r = i.getBoundingClientRect();
      i.classList.toggle('kl-hide', hit({ l: r.left - g.kr.left, t: r.top - g.kr.top, r: r.right - g.kr.left, b: r.bottom - g.kr.top }, sk, 2));
    });
    let cb = box(chalk);
    if (cb && clash(cb, [lives, sign, wb, sb, pcase])) {
      const x = lives ? lives.l : 10, y = (lives ? lives.b : 40) + 10;
      const gapW = Math.min(...env.filter(e => e.b > y && e.t < y + 120).map(e => e.l), K.clientWidth) - x - 12;
      if (gapW >= 66) {                                  // มือถือกระดานอยู่ชิดขวา → ย้ายมาชิดซ้าย
        Object.assign(chalk.style, { left: x + 'px', right: 'auto', top: y + 'px', width: Math.min(150, gapW) + 'px' });
        cb = box(chalk);
      }
      if (gapW < 66 || clash(cb, [lives, sign, wb, sb, pcase])) { off(chalk); ['top', 'left', 'right', 'width'].forEach(k => chalk.style.removeProperty(k)); }
    }
  }
};