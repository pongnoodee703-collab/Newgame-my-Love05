'use strict';
/* =====================================================================
   settings.js — การตั้งค่า + คะแนนดาวที่ดีที่สุด
   ===================================================================== */

/* ระดับความง่าย — ปรับตัวเลขที่นี่ที่เดียว ทุกกลไกในเกมอ่านค่าจากตารางนี้
   zone      : ความกว้างโซนสีเขียว (คูณ)           speed    : ความเร็วเข็ม (คูณ)
   approach  : เข็มวิ่งเร็วขึ้นก่อนถึงโซน (ไม่ต้องรอนาน) slowZone : เข็มช้าลงเมื่ออยู่ในโซน
   early     : กดก่อนถึงโซนมากเกินไปจะยังไม่นับ (กันกดพลาด)
   rev       : จำนวนรอบที่ต้องคน (คูณ)               tapN     : แตะกี่ครั้งเท่ากับคนครบ
   gentle    : เพดานความเร็วตอน "คนเบา ๆ" (คูณ)      swipe    : จำนวนครั้งร่อน/กรอง (คูณ)
   decoys    : วัตถุดิบหลอกบนชั้น                    forgive  : พลาดกี่ครั้งถึงเสีย 1 ดาว
   hint      : มิลลิวินาทีก่อนไฮไลต์วัตถุดิบที่ถูก (0 = ปิด)  next : พักก่อนขั้นต่อไป (ms)
   lives     : หัวใจต่อเมนู (ใส่ของผิด/คนแรงเกิน = เสีย 1 ดวง หมด = แพ้ ต้องเริ่มใหม่)
   burn      : เข็มเลยโซนเขียวไปเท่านี้ (สัดส่วนของแถบ) = ขนมไหม้ แพ้ทันที (ไม่ต้องรอเข็มวิ่งสุดแถบ)
   จับเวลา: กดหลังโซนเขียว/เข็มเลยโซน = ขนมไหม้ → แพ้ทันที ; กดก่อนโซน = ไม่สุก → แพ้
            (โหมด early: กดก่อนโซนแค่เตือน ไม่นับ — จึงแพ้ได้แค่ตอนไหม้) */
const ASSIST = {
  easy:   { zone: 1.6,  speed: 1,    approach: 1.9, slowZone: .5,  early: true,  rev: .5,  tapN: 8,  gentle: 2.2, swipe: .6,  decoys: 1, forgive: 2, hint: 2500, next: 1100, lives: 3, burn: .05 },
  normal: { zone: 1.15, speed: 1,    approach: 1.5, slowZone: .8,  early: false, rev: .8,  tapN: 12, gentle: 1.4, swipe: .85, decoys: 2, forgive: 1, hint: 5000, next: 1300, lives: 3, burn: .03 },
  hard:   { zone: .75,  speed: 1.25, approach: 1.2, slowZone: 1,   early: false, rev: 1.15, tapN: 20, gentle: .9, swipe: 1.1, decoys: 3, forgive: 1, hint: 0,    next: 1400, lives: 2, burn: .015 }
};

/* ความท้าทายของแต่ละด่าน (ด่าน 1 → 3 ยากขึ้นเรื่อย ๆ) — คูณ/บวกกับระดับความยากข้างบน
   Settings.assist() รวมให้เองตามเมนูที่กำลังเล่น ทุกกลไกจึงยากขึ้นตามด่านโดยอัตโนมัติ
   (ส่วนที่ต่างกันตามด่านอยู่แล้ว: สูตร/ความเร็วเข็มใน recipes.js, ของแปลกปลอมใน Pests.cfg, ลูกเล่นสายพานใน Conveyor)
   ตัวคูณ: zone speed rev tapN gentle swipe hint burn (hint 0 = ปิด ยังคงปิด) ; ตัวบวก: decoys */
const LEVEL_MOD = [
  { zone: 1.1,  speed: .95,  rev: .9,   tapN: .85,  gentle: 1.15, swipe: .9,   hint: .8,  burn: 1.25, decoys: 0 },   // ด่าน 1: ฝึกพื้นฐาน
  { zone: 1,    speed: 1.05, rev: 1,    tapN: 1,    gentle: 1,    swipe: 1,    hint: 1.2, burn: 1,    decoys: 1 },   // ด่าน 2: ของหลอกเพิ่ม
  { zone: .88,  speed: 1.12, rev: 1.12, tapN: 1.15, gentle: .88,  swipe: 1.15, hint: 1.5, burn: .8,   decoys: 1 }    // ด่าน 3: เร็ว แคบ เข้ม
];
const LEVEL_MUL = ['zone', 'speed', 'rev', 'tapN', 'gentle', 'swipe', 'hint', 'burn'];

const Settings = {
  KEY: 'nj_settings_v2',
  /* (ไม่มีตัวเลือกปิดของแปลกปลอม/สอนเล่นแล้ว: ของแปลกปลอมหล่นมาทุกด่าน และด่านแรกสอนเล่นเสมอ — ค่าเก่าที่เคยบันทึกไว้ไม่ถูกอ่าน) */
  d: { music: .5, sfx: .8, mute: false, haptics: true, captions: true, hints: true, calm: false, assist: 'easy', char: 'girl', lang: 'th' },
  load() {
    const s = store.get(this.KEY, null);
    if (s && typeof s === 'object') Object.keys(this.d).forEach(k => { if (k in s) this.d[k] = s[k]; });  // อ่านเฉพาะค่าที่รู้จัก
    const d = this.d;
    const num = (v, f) => (Number.isFinite(+v) ? clamp(+v, 0, 1) : f);
    d.music = num(d.music, .5);
    d.sfx = num(d.sfx, .8);
    if (!ASSIST[d.assist]) d.assist = 'easy';
    if (d.char === 'bunny') d.char = 'girl';             // ผู้เล่นเดิมที่เลือกบันนี่ → ได้เชฟแว่นตาแทน
    if (!CHARS[d.char]) d.char = 'girl';
    if (!LANGS.includes(d.lang)) d.lang = 'th';          // ภาษาเริ่มต้น = ไทย (เปลี่ยนได้ในหน้าตั้งค่า)
    ['mute', 'haptics', 'captions', 'hints', 'calm'].forEach(k => (d[k] = !!d[k]));
  },
  save() { store.set(this.KEY, this.d); },
  set(k, v) { this.d[k] = v; this.save(); this.apply(); },
  apply() {
    Sound.setVolumes();
    const b = document.body.classList;
    b.toggle('calm', this.d.calm);
    b.toggle('nohint', !this.d.hints);
    b.toggle('nocap', !this.d.captions);
    Assets.sync();
    Chars.refresh();
    safeCall(() => I18N.apply(), 'I18N.apply');
  },
  /* ค่าความยากที่ใช้จริง = ระดับความยาก (ง่าย/ปกติ/ยาก) × ความท้าทายของด่านที่กำลังเล่น (แคชไว้ คำนวณใหม่เมื่อเปลี่ยน) */
  assist() {
    const lv = this.level(), key = this.d.assist + lv;
    if (this._ak !== key) {
      const a = { ...(ASSIST[this.d.assist] || ASSIST.easy) }, m = LEVEL_MOD[lv];
      LEVEL_MUL.forEach(k => { a[k] *= m[k]; });
      a.decoys = Math.min(6, a.decoys + m.decoys);
      a.hint = Math.round(a.hint);
      this._ak = key; this._a = a;
    }
    return this._a;
  },
  /* ด่านที่กำลังเล่น 0–2 (ลำดับเมนูใน recipes.js) ; ยังไม่เลือกเมนู = ด่าน 1 */
  level() {
    let r = null;
    try { r = G.r; } catch (e) { /* ยังโหลดตัวเกมไม่เสร็จ */ }
    return r ? clamp(Object.keys(RECIPES).indexOf(r.id), 0, LEVEL_MOD.length - 1) : 0;
  }
};

const Progress = {
  best: {},
  /* อ่านเฉพาะเมนูที่มีจริง และดาวเป็นจำนวนเต็ม 1–3 (ข้อมูลในเครื่องเสีย/ถูกแก้ ก็ไม่ทำให้เกมเพี้ยน) */
  load() {
    const b = store.get('nj_best', {}), best = {};
    if (b && typeof b === 'object' && !Array.isArray(b)) {
      Object.keys(RECIPES).forEach(id => {
        const v = Math.round(+b[id]);
        if (v >= 1 && v <= 3) best[id] = v;
      });
    }
    this.best = best;
  },
  save() { store.set('nj_best', this.best); }
};
