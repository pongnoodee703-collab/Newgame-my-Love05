'use strict';
/* =====================================================================
   characters.js — ตัวละคร 3 ตัว + ท่าทาง + ระบบลากเล่น
   - girl : เชฟแว่นตา (รูป GIF ขยับได้ จาก assets/chef.gif) ← แทนที่บันนี่เดิม
   - cat  : มีโอ   (วาดด้วย SVG เหมือนเดิม)
   - bear : หมีหม่ำ (วาดด้วย SVG เหมือนเดิม)
   ทุกตัวอยู่ใน "กล่อง" สัดส่วน 3:4 เท่ากัน จึงสลับตัวละครได้ทุกที่โดยไม่ต้องแก้ CSS
   ===================================================================== */
const CHARS = {
  girl: { n: 'เชฟแว่นตา', gif: true },
  cat:  { n: 'มีโอ',    fur: '#fff2cc', inn: '#ffc9a8', ear: 'cat' },
  bear: { n: 'หมีหม่ำ',  fur: '#ffddc2', inn: '#f3b48d', ear: 'bear' }
};
const CHAR_KEYS = Object.keys(CHARS);
const FX = { cheer: '✨', oops: '💦' };

/* ---------- ตัวละคร SVG (แคชไว้ เพราะถูกวาดซ้ำบ่อย) ---------- */
const _charCache = new Map();
function charSVG(k, mood = 'happy') {
  const key = k + mood;
  if (_charCache.has(key)) return _charCache.get(key);
  const c = CHARS[k], st = 'stroke="#e6a9c0" stroke-width="2"';
  const ears = c.ear === 'cat'
    ? `<path d="M24 58 L28 16 L58 44Z" fill="${c.fur}" ${st} stroke-linejoin="round"/><path d="M96 58 L92 16 L62 44Z" fill="${c.fur}" ${st} stroke-linejoin="round"/><path d="M30 46 L32 27 L46 40Z" fill="${c.inn}"/><path d="M90 46 L88 27 L74 40Z" fill="${c.inn}"/>`
    : `<circle cx="30" cy="48" r="15" fill="${c.fur}" ${st}/><circle cx="30" cy="48" r="7.5" fill="${c.inn}"/><circle cx="90" cy="48" r="15" fill="${c.fur}" ${st}/><circle cx="90" cy="48" r="7.5" fill="${c.inn}"/>`;
  const eyes = mood === 'cheer'
    ? `<path d="M40 83 Q46 74 52 83" stroke="#4a2f45" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M68 83 Q74 74 80 83" stroke="#4a2f45" stroke-width="3" fill="none" stroke-linecap="round"/>`
    : `<g class="eyes"><ellipse cx="46" cy="81" rx="4.8" ry="6" fill="#4a2f45"/><circle cx="47.8" cy="78.6" r="1.8" fill="#fff"/><ellipse cx="74" cy="81" rx="4.8" ry="6" fill="#4a2f45"/><circle cx="75.8" cy="78.6" r="1.8" fill="#fff"/></g>`;
  const mouth = mood === 'cheer' ? `<path d="M52 91 Q60 106 68 91Z" fill="#d6577a"/>`
    : mood === 'oops' ? `<ellipse cx="60" cy="96" rx="4" ry="5" fill="#d6577a"/>`
    : `<path d="M53 92 Q60 99 67 92" stroke="#4a2f45" fill="none" stroke-width="2.6" stroke-linecap="round"/>`;
  const svg = `<svg viewBox="0 0 120 160" aria-hidden="true">
  ${ears}
  <ellipse cx="60" cy="132" rx="32" ry="27" fill="${c.fur}" ${st}/>
  <path d="M38 120 Q60 128 82 120 L87 154 H33Z" fill="#fff" stroke="#f4c5d9" stroke-width="2"/>
  <path d="M60 148 C46 138 52 129 60 135 C68 129 74 138 60 148Z" fill="#ffb3d1"/>
  <circle cx="29" cy="130" r="9" fill="${c.fur}" ${st}/>
  <g class="arm-r"><circle cx="91" cy="126" r="9" fill="${c.fur}" ${st}/></g>
  <circle cx="60" cy="78" r="38" fill="${c.fur}" ${st}/>
  <g fill="#fff" stroke="#f0d3e0" stroke-width="2"><rect x="41" y="40" width="38" height="14" rx="4"/><circle cx="46" cy="34" r="10"/><circle cx="60" cy="27" r="12"/><circle cx="74" cy="34" r="10"/></g>
  <rect x="42" y="42" width="36" height="8" fill="#fff"/>
  ${eyes}
  <circle cx="35" cy="91" r="6.5" fill="#ff9fbf" opacity=".6"/><circle cx="85" cy="91" r="6.5" fill="#ff9fbf" opacity=".6"/>
  <ellipse cx="60" cy="87" rx="3.4" ry="2.4" fill="#e98aa8"/>
  ${mouth}
  </svg>`;
  _charCache.set(key, svg);
  return svg;
}

/* ---------- HTML ของตัวละครใดก็ได้ (GIF หรือ SVG) ---------- */
function charHTML(k, mood = 'happy') {
  if (!CHARS[k]) k = CHAR_KEYS[0];
  if (CHARS[k].gif) {
    const m = FX[mood] ? mood : 'idle';
    return `<span class="chef ${m}" data-fx="${FX[mood] || ''}">${Assets.chefHTML()}</span>`;
  }
  return charSVG(k, mood);
}

/* ท่าทางของเชฟ GIF: 'cheer' กระโดดดีใจ ✨ | 'oops' ส่ายตัว 💦 */
function gifAct(chef, mood, ms) {
  if (!chef) return;
  chef.classList.remove('cheer', 'oops');
  clearTimeout(chef._t);
  if (!FX[mood]) { chef.classList.add('idle'); return; }
  chef.dataset.fx = FX[mood];
  chef.classList.remove('idle');
  void chef.offsetWidth;                // เริ่มแอนิเมชันใหม่ทุกครั้ง
  chef.classList.add(mood);
  chef._t = setTimeout(() => { chef.classList.remove('cheer', 'oops'); chef.classList.add('idle'); }, ms);
}

/* ---------- เชฟในห้องครัว (ปุ่ม #char) ---------- */
const Chars = {
  timer: null, key: '', mood_: '',
  render(mood) {
    const el = $('#char'), k = Settings.d.char;
    if (!el) return;
    const m = CHARS[k].gif ? 'happy' : mood;      // GIF ไม่ต้องวาดใหม่ ใช้คลาสแทน
    if (this.key === k && this.mood_ === m && el.firstElementChild) return;
    this.key = k; this.mood_ = m;
    el.innerHTML = charHTML(k, m);
  },
  refresh() { clearTimeout(this.timer); this.render('happy'); },
  mood(m, ms = 1300) {
    const k = Settings.d.char;
    clearTimeout(this.timer);
    if (CHARS[k].gif) { this.render('happy'); gifAct($('#char .chef'), m, ms); return; }
    this.render(m);
    this.timer = setTimeout(() => this.render('happy'), ms);
  }
};

/* ทำให้องค์ประกอบลากได้ด้วยนิ้ว/เมาส์ (snap = ปล่อยแล้วเด้งกลับที่เดิม) */
function makeDraggable(el, { snap = false, onGrab } = {}) {
  let sx = 0, sy = 0, ox = 0, oy = 0, tx = 0, ty = 0, id = null;
  el.classList.add('draggable');
  el.addEventListener('pointerdown', e => {
    if (e.button > 0) return;
    id = e.pointerId; sx = e.clientX; sy = e.clientY;
    try { el.setPointerCapture(id); } catch (_) { /* ignore */ }
    el.classList.add('grab'); el.style.transition = 'none';
    Sound.unlock(); Sound.play('pop'); onGrab && onGrab();
    e.preventDefault();
  });
  el.addEventListener('pointermove', e => {
    if (e.pointerId !== id) return;
    tx = ox + e.clientX - sx; ty = oy + e.clientY - sy;
    setOffset(el, tx, ty);
  });
  const end = e => {
    if (e.pointerId !== id) return;
    id = null; el.classList.remove('grab');
    if (snap) {
      tx = ty = 0;
      el.style.transition = 'translate .45s cubic-bezier(.3,1.7,.5,1),transform .45s cubic-bezier(.3,1.7,.5,1)';
      setOffset(el, 0, 0);
    }
    ox = tx; oy = ty;
  };
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('lostpointercapture', end);
}
