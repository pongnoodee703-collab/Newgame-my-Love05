'use strict';
/* =====================================================================
   safe.js — ระบบกันเกมพัง
   - safeCall(fn, 'ชื่อ')  เรียกฟังก์ชันแบบมีตาข่าย: ถ้า error จะจดไว้แล้วเล่นต่อได้
   - จับ error / Promise ที่หลุดทั้งหมด ไม่ให้เด้งเป็นจอขาว
   - ถ้าขั้นตอนในครัวพัง ตัวเกม (engine.js) จะข้ามไปขั้นถัดไปให้เอง
   ดูรายการ error ล่าสุดจากคอนโซล: DeejatBakery.Safe.log
   ===================================================================== */
const Safe = {
  log: [],
  report(where, err) {
    const msg = (err && (err.message || err.reason)) || String(err);
    if (this.log.length >= 30) this.log.shift();          // เก็บแค่ 30 รายการล่าสุด กันหน่วยความจำบวม
    this.log.push({ where, msg, t: Date.now() });
    try { console.warn('[DeejatBakery] ' + where + ':', msg); } catch (e) { /* ignore */ }
  }
};

function safeCall(fn, where, fallback) {
  try { return fn(); } catch (e) { Safe.report(where || 'safeCall', e); return fallback; }
}

window.addEventListener('error', e => Safe.report('window', e.error || e.message));
window.addEventListener('unhandledrejection', e => { Safe.report('promise', e.reason); e.preventDefault(); });
