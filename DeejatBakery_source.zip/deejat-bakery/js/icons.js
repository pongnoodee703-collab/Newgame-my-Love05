'use strict';
/* =====================================================================
   icons.js — ภาพขนม 3 เมนู (SVG) สไตล์ร้านเบเกอรี่ (ยังหน้าตาน่ารักเหมือนเดิม)
   - คาราเมลคัสตาร์ด: บนกระดาษรองลูกไม้ (doily) + จานครีม + ซอสคาราเมล + วิปครีม + เชอร์รี
   - คัพเค้กวานิลลา : ถ้วยกระดาษคราฟต์สีน้ำตาล + บัตเตอร์ครีมวานิลลาราดคาราเมล + เชอร์รี
   - คุกกี้ตัวร้าย  : เขาช็อกโกแลต + ช็อกชิปเข้ม วางบนกระดาษไขแบบร้านขนม
   ใช้ที่การ์ดเมนู ขนมลอยหน้าแรก หน้าสรุปผล หน้าแพ้ และหน้าสอนเล่น
   cookieDraw() ใช้วาดคุกกี้ในครัวด้วย (face = อบเสร็จแล้วมีหน้า)
   ===================================================================== */
function cookieDraw(x, y, r, col, face, cool) {
  let s = `<circle cx="${x}" cy="${y}" r="${r}" fill="${col}" stroke="rgba(90,44,16,.3)" stroke-width="2"/>`;
  // ช็อกชิปเข้ม
  s += [[-.42, -.12], [.38, .22], [.12, -.48], [-.22, .48], [.55, -.2], [-.6, .25]].map(([a, b], i) =>
    `<ellipse cx="${(x + a * r).toFixed(1)}" cy="${(y + b * r).toFixed(1)}" rx="${(r * (i % 2 ? .09 : .11)).toFixed(1)}" ry="${(r * .08).toFixed(1)}" fill="#5a2e14" opacity=".85"/>`).join('');
  if (face) {
    const w = Math.max(1.5, r * .1);
    // เขาตัวร้ายสีช็อกโกแลต
    s += `<path d="M${x - r * .7} ${y - r * .75} l${-r * .12} ${-r * .5} l${r * .45} ${r * .28}z M${x + r * .7} ${y - r * .75} l${r * .12} ${-r * .5} l${-r * .45} ${r * .28}z" fill="#6b3a1f" stroke="#43220f" stroke-width="1.2" stroke-linejoin="round"/>`;
    s += `<circle cx="${x - r * .33}" cy="${y - r * .05}" r="${r * .14}" fill="#3b2010"/><circle cx="${x + r * .33}" cy="${y - r * .05}" r="${r * .14}" fill="#3b2010"/>`;
    s += `<circle cx="${x - r * .29}" cy="${y - r * .1}" r="${r * .05}" fill="#fff"/><circle cx="${x + r * .37}" cy="${y - r * .1}" r="${r * .05}" fill="#fff"/>`;
    s += `<path d="M${x - r * .55} ${y - r * .33} L${x - r * .15} ${y - r * .22} M${x + r * .55} ${y - r * .33} L${x + r * .15} ${y - r * .22}" stroke="#3b2010" stroke-width="${w}" stroke-linecap="round"/>`;
    s += `<path d="M${x - r * .3} ${y + r * .38} Q${x} ${y + r * .2} ${x + r * .3} ${y + r * .38}" stroke="#3b2010" stroke-width="${w}" fill="none" stroke-linecap="round"/>`;
    s += `<circle cx="${x - r * .58}" cy="${y + r * .2}" r="${r * .12}" fill="#f4a37f" opacity=".75"/><circle cx="${x + r * .58}" cy="${y + r * .2}" r="${r * .12}" fill="#f4a37f" opacity=".75"/>`;
  }
  if (cool) s += `<text x="${x + r * .7}" y="${y - r * .9}" font-size="${r * .8}">✨</text>`;
  return s;
}

/* กระดาษรองลูกไม้ (doily): วงรีขาว + ขอบหยักวงเล็ก ๆ รอบ ๆ + ลายจุดไข่ปลาด้านใน */
function doilySVG(cx, cy, rx, ry, n = 22) {
  let s = `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="#fff"/>`;
  for (let i = 0; i < n; i++) {
    const a = i / n * Math.PI * 2;
    s += `<circle cx="${(cx + Math.cos(a) * rx).toFixed(1)}" cy="${(cy + Math.sin(a) * ry).toFixed(1)}" r="${(rx * .085).toFixed(1)}" fill="#fff"/>`;
  }
  return s + `<ellipse cx="${cx}" cy="${cy}" rx="${(rx * .84).toFixed(1)}" ry="${(ry * .8).toFixed(1)}" fill="none" stroke="#ecd6b8" stroke-width="1.6" stroke-dasharray="2.4 2.4"/>`;
}

const _iconCache = {};
function iconSVG(id) {
  if (_iconCache[id]) return _iconCache[id];
  let s;
  if (id === 'custard') s = `<svg viewBox="0 0 120 120" aria-hidden="true">${doilySVG(60, 104, 54, 11)}
  <ellipse cx="60" cy="102" rx="45" ry="7.5" fill="#fffaf2" stroke="#ead6bc" stroke-width="1.5"/><ellipse cx="60" cy="101" rx="38" ry="5.6" fill="#c0701c"/><ellipse cx="46" cy="99.6" rx="10" ry="1.5" fill="#fff" opacity=".35"/>
  <g class="wob"><path d="M24 54 Q22 98 36 100 H84 Q98 98 96 54Z" fill="#f8d77e" stroke="#e0a948" stroke-width="3" stroke-linejoin="round"/><path d="M32 62 Q31 80 36 92" stroke="#fff" stroke-width="4" opacity=".55" fill="none" stroke-linecap="round"/>
  <path d="M20 52 Q22 30 60 28 Q98 30 100 52 Q100 66 92 64 Q89 78 82 64 Q76 72 70 62 Q62 70 55 62 Q48 76 42 62 Q34 70 30 64 Q20 66 20 52Z" fill="#b8661c" stroke="#8a4510" stroke-width="3" stroke-linejoin="round"/><ellipse cx="42" cy="42" rx="12" ry="5" fill="#fff" opacity=".42" transform="rotate(-15 42 42)"/>
  <path d="M47 31 Q45 23 53 23 Q53 15 60 16 Q67 15 67 23 Q75 23 73 31Z" fill="#fffaf2" stroke="#e8d3b6" stroke-width="2" stroke-linejoin="round"/><path d="M53 24 Q60 20 66 24" stroke="#ecdcc6" stroke-width="1.6" fill="none"/>
  <circle cx="60" cy="13" r="7" fill="#d23a48"/><circle cx="57.6" cy="10.6" r="2.2" fill="#fff" opacity=".7"/><path d="M60 7 Q62 1 69 1" stroke="#5e8a3a" stroke-width="2.6" fill="none" stroke-linecap="round"/>
  <ellipse cx="46" cy="80" rx="4.5" ry="5.5" fill="#3b2010"/><circle cx="47.8" cy="78" r="1.8" fill="#fff"/><ellipse cx="74" cy="80" rx="4.5" ry="5.5" fill="#3b2010"/><circle cx="75.8" cy="78" r="1.8" fill="#fff"/>
  <circle cx="36" cy="88" r="6" fill="#f4a37f" opacity=".7"/><circle cx="84" cy="88" r="6" fill="#f4a37f" opacity=".7"/><path d="M54 87 Q60 95 66 87" stroke="#3b2010" stroke-width="2.6" fill="none" stroke-linecap="round"/></g>
  <text x="6" y="34" font-size="13">✨</text></svg>`;
  else if (id === 'cupcake') s = `<svg viewBox="0 0 120 120" aria-hidden="true"><ellipse cx="60" cy="111" rx="42" ry="6" fill="rgba(107,68,40,.18)"/>
  <g class="wob"><path d="M28 68 L92 68 L84 108 Q60 114 36 108Z" fill="#c98d55" stroke="#93602f" stroke-width="3" stroke-linejoin="round"/>
  <path d="M36 70 L40 108 M48 70 L50 110 M60 70 V111 M72 70 L70 110 M84 70 L80 108" stroke="#e7bd8a" stroke-width="3" opacity=".85"/>
  <path d="M24 68 Q22 52 40 50 Q60 42 80 50 Q98 52 96 68Z" fill="#e9b46c" stroke="#c48743" stroke-width="3" stroke-linejoin="round"/>
  <path d="M22 56 Q18 42 36 42 Q36 30 54 32 Q60 20 76 30 Q94 28 92 44 Q106 48 96 58 Q60 68 22 56Z" fill="#fff5e4" stroke="#e8cfa8" stroke-width="3" stroke-linejoin="round"/>
  <path d="M27 54 q5 6 10 0 q5 7 10 0 q5 7 10 0 q5 7 10 0 q5 7 10 0 q5 6 10 0 q4 5 7 0" stroke="#cf8a3c" stroke-width="3.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M34 46 Q46 38 58 40" stroke="#fff" stroke-width="4" opacity=".8" fill="none" stroke-linecap="round"/>
  <circle cx="60" cy="20" r="8" fill="#d23a48"/><circle cx="57" cy="17" r="2.5" fill="#fff" opacity=".7"/><path d="M60 13 Q62 6 70 6" stroke="#5e8a3a" stroke-width="3" fill="none" stroke-linecap="round"/>
  <g><rect x="40" y="38" width="8" height="3" rx="1.5" fill="#8fd7ff" transform="rotate(-30 44 40)"/><rect x="70" y="40" width="8" height="3" rx="1.5" fill="#ffd84d" transform="rotate(25 74 42)"/><rect x="54" y="44" width="8" height="3" rx="1.5" fill="#ff9fbf" transform="rotate(-10 58 46)"/><rect x="80" y="46" width="8" height="3" rx="1.5" fill="#b9f0dc" transform="rotate(-35 84 48)"/></g>
  <ellipse cx="49" cy="88" rx="4.2" ry="5.2" fill="#3b2010"/><circle cx="50.6" cy="86" r="1.7" fill="#fff"/><ellipse cx="71" cy="88" rx="4.2" ry="5.2" fill="#3b2010"/><circle cx="72.6" cy="86" r="1.7" fill="#fff"/>
  <circle cx="40" cy="95" r="5" fill="#f6b08a" opacity=".8"/><circle cx="80" cy="95" r="5" fill="#f6b08a" opacity=".8"/><path d="M55 94 Q60 101 65 94" stroke="#3b2010" stroke-width="2.6" fill="none" stroke-linecap="round"/></g>
  <text x="98" y="30" font-size="12">✨</text></svg>`;
  else s = `<svg viewBox="0 0 120 120" aria-hidden="true"><g transform="rotate(-8 60 68)"><rect x="16" y="26" width="88" height="86" rx="3" fill="#fbf0dc" stroke="#e6cfa9" stroke-width="2"/><path d="M22 40 H98 M22 98 H98" stroke="#ecdcc0" stroke-width="1.5" stroke-dasharray="4 3"/></g>${cookieDraw(60, 68, 40, '#d9a066', true, false)}</svg>`;
  return (_iconCache[id] = s);
}
