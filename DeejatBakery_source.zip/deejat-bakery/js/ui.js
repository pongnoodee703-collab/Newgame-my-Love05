'use strict';
/* =====================================================================
   ui.js — บับเบิลคำพูด / คำสั่ง / มิเตอร์ / ดาวเด้ง
   ===================================================================== */
const UI = {
  sayT: null,
  say(t) { $('#say').textContent = t; },
  flash(t, ms = 1800) {
    this.say(t);
    clearTimeout(this.sayT);
    this.sayT = setTimeout(() => this.say(G.base), ms);
  },
  /* คำสั่งใต้ฉาก: รับเป็นคีย์ภาษา (i18n.js) จำไว้เพื่อแปลใหม่ตอนสลับภาษากลางขั้น */
  instr(k) { this._ik = k || ''; $('#instr').textContent = k ? t(k) : ''; },
  meter(mode, zone) {
    const m = $('#meter');
    m.className = 'meter ' + (mode || 'off');
    $('#mfill').style.width = '0';
    this.needle(0);
    if (zone) {
      $('#mzone').style.left = zone[0] * 100 + '%';
      $('#mzone').style.width = (zone[1] - zone[0]) * 100 + '%';
      // ป้ายความสุก: ดิบ (ซ้าย) / พอดี (กลางโซนเขียว) / ไหม้ (หลังโซน พื้นแดง)
      m.style.setProperty('--z1', (zone[1] * 100).toFixed(1) + '%');
      $('#mlok').style.left = ((zone[0] + zone[1]) * 50).toFixed(1) + '%';
    }
  },
  meterFill(p) { $('#mfill').style.width = clamp(p, 0, 1) * 100 + '%'; },
  /* เรียกทุกเฟรมตอนจับเวลา: เก็บ element ไว้ และเลื่อนด้วย transform (ไม่ต้องคำนวณเลย์เอาต์ใหม่) */
  needle(p) {
    const n = this._needle || (this._needle = $('#mneedle'));
    n.style.transform = `translateX(${(clamp(p, 0, 1) * 100).toFixed(2)}%)`;
  },
  pstars(n, txt) {
    const d = document.createElement('div');
    d.className = 'pstars';
    d.innerHTML = `<div>${[1, 2, 3].map(i => starSVG(i <= n)).join('')}</div><p>${txt}</p>`;
    $('#stage').appendChild(d);
    setTimeout(() => d.remove(), 1300);
  },
  plop(e) {
    const p = document.createElement('span');
    p.className = 'plop'; p.textContent = e;
    $('#stage').appendChild(p);
    setTimeout(() => p.remove(), 750);
  },
  shake(el) { el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); },
  /* หัวใจมุมซ้ายบนของครัว (lost = เพิ่งเสียไป 1 ดวง → ดวงนั้นเด้งหาย) */
  lives(n, lost) {
    const el = $('#lives');
    if (!el) return;
    const max = Math.max(n, Settings.assist().lives || 3);
    el.innerHTML = Array.from({ length: max }, (_, i) => `<i class="${i < n ? 'on' : ''}${lost && i === n ? ' gone' : ''}">${i < n ? '❤️' : '🤍'}</i>`).join('');
    el.setAttribute('aria-label', t('lives.aria', n));
  },
  /* ควันลอยจากฉากตอนขนมไหม้ */
  smoke() {
    const st = $('#stage');
    if (!st || !Env.motion) return;
    ['💨', '☁️', '💨', '☁️'].forEach((e, i) => puff(st, e, st.clientWidth * (.28 + i * .13), st.clientHeight * .32, (i - 1.5) * 18, { size: '2.1rem', delay: i * .12, life: 1600 }));
  },
  /* ป้ายตอนเข้าครัว: "ด่าน 3 · ยาก" + ความท้าทายของด่าน — ลอยลงมาแล้วหายเอง (CSS opacity/transform) */
  levelBanner() {
    const b = $('#lvlbanner');
    if (!b) return;
    const lv = Settings.level();
    b.innerHTML = `<b>${t('lvl.n', lv + 1)} · ${t('lv.' + Settings.d.assist)}</b><span>${(t('chal') || [])[lv] || ''}</span>`;
    b.classList.remove('on');
    cancelAnimationFrame(this._lb); clearTimeout(this._lbT);
    // นับเวลาซ่อนหลังป้ายขึ้นจริง (เดิมนับก่อน → ถ้าเฟรมถูกหน่วงตอนสลับแอป ป้ายจะค้างทับหม้อ/ชามตลอด)
    this._lb = requestAnimationFrame(() => {
      this._lb = requestAnimationFrame(() => {
        b.classList.add('on');
        this._lbT = setTimeout(() => b.classList.remove('on'), 3100);
      });
    });
  },
  /* ออกจากครัว: ป้ายด่านไม่ค้างไปโผล่ตอนเข้าครัวครั้งหน้า */
  hideBanner() {
    cancelAnimationFrame(this._lb); clearTimeout(this._lbT);
    const b = $('#lvlbanner');
    if (b) b.classList.remove('on');
  },
  dots() {
    $('#dots').innerHTML = G.r.steps.map((_, i) => `<i class="${i < G.i ? 'done' : i === G.i ? 'now' : ''}"></i>`).join('');
  }
};
