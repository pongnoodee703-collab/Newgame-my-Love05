'use strict';
/* =====================================================================
   recipes-en.js — ข้อความภาษาอังกฤษของเมนู (คู่กับ recipes.js)
   - โครงเหมือน RECIPES ทุกอย่าง: ขั้นที่ i ตรงกับขั้นที่ i ของเมนูเดียวกัน
   - เก็บเฉพาะข้อความ (ชื่อ/คำพูด/เคล็ดลับ/วัตถุดิบ/ปุ่มจับเวลา/สมุดสูตร)
     ตัวเลข สี ชนิดการเล่น อยู่ใน recipes.js ที่เดียว
   - แก้/เพิ่มเมนูใหม่: เพิ่มข้อความตรงนี้ด้วย (ถ้าลืม เกมจะใช้ภาษาไทยแทน ไม่พัง)
   ===================================================================== */
const DECOYS_EN = ['Chili', 'Onion', 'Lime', 'Broccoli', 'Garlic', 'Carrot', 'Tomato'];

const RECIPES_EN = {
  custard: {
    name: 'Caramel Custard', sub: 'Silky smooth & baked',
    book: [
      { h: 'Caramel', l: ['Sugar 140 g', 'Water 90 g', 'Boiling water 1 tbsp'] },
      { h: 'Custard', l: ['Eggs ×4', 'Milk 400 g', 'Evaporated milk 200 g', 'Sugar 75 g', 'Vanilla extract 1 tsp'] },
      { h: 'Bake', l: ['Set the cups in a hot water bath, halfway up', 'Bake at 160–200°C for about 25–30 min', 'Let cool, then chill before serving'] }
    ],
    steps: [
      { title: 'Make caramel', say: "Let's start with sweet, fragrant caramel! Add 140 g of sugar and 90 g of water to the pot~ 🍬", tip: 'Sugar 140 g + water 90 g', items: [{ n: 'Sugar', amt: '140 g' }, { n: 'Water', amt: '90 g' }] },
      { title: 'Cook the caramel', say: 'Low heat and no stirring! Wait until it turns a lovely golden brown, then hit "Heat off" in time! 🔥', tip: 'Low heat, no stirring, until golden brown', label: '🔥 Heat off!' },
      { title: 'Add hot water', say: 'Heat is off! Carefully add 1 tbsp of boiling water — watch out for splashes 💦', tip: 'Careful, it splatters! Then stir to combine', items: [{ n: 'Boiling water', amt: '1 tbsp' }] },
      { title: 'Pour into cups', say: 'Pour caramel into the bottom of each cup, one by one, then let it set for about 5 minutes 🍯', tip: 'A thin layer in each cup, set for 5 min' },
      { title: 'Warm the milk', say: 'Now for the soft custard! Pour 400 g of milk and 200 g of evaporated milk into the pot 🥛', tip: 'Milk 400 g + evaporated milk 200 g', items: [{ n: 'Milk', amt: '400 g' }, { n: 'Evaporated milk', amt: '200 g' }] },
      { title: 'Warm it gently', say: 'Low heat until just warm — no need to boil. Then take it off quickly!', tip: 'Low heat, just warm, not boiling', label: '🥛 Take it off!' },
      { title: 'Prepare the eggs', say: 'Crack 4 eggs, then add 75 g of sugar and 1 tsp of vanilla to the bowl 🥚', tip: '4 eggs + 75 g sugar + 1 tsp vanilla', items: [{ n: 'Eggs', amt: '4 eggs' }, { n: 'Sugar', amt: '75 g' }, { n: 'Vanilla extract', amt: '1 tsp' }] },
      { title: 'Whisk gently', say: "Whisk gently so you don't make too many bubbles — nice and slow~ 🌀", tip: 'Whisk gently, avoid air bubbles' },
      { title: 'Add the warm milk', say: "Slowly pour in the warm milk while stirring fast, so the eggs don't scramble!", tip: 'Pour a little at a time, stir fast' },
      { title: 'Strain it smooth', say: 'Strain through a sieve 1–2 times for a velvety texture~ Swipe left and right! ✨', tip: 'Strain 1–2 times' },
      { title: 'Pour the custard', say: 'Pour the custard into each caramel-lined cup, one at a time 🍮', tip: 'Pour over the set caramel' },
      { title: 'Cover with foil', say: "Cover each cup with foil so the top doesn't dry out or burn. Tap the cups! ✨", tip: 'Foil over each cup' },
      { title: 'Water bath', say: 'Put the cups in a baking tray and pour hot water halfway up the cups (water bath) 🛁', tip: 'Hot water about halfway up the cups', items: [{ n: 'Hot water', amt: 'halfway up' }] },
      { title: 'Preheat the oven', say: 'Turn the oven dial to 180°C — just right! 🔥', tip: 'Bake at about 160–200°C' },
      { title: 'Bake the custard', say: 'Bake 25–30 minutes until set. When it looks golden, take it out! A toothpick should come out clean 🍮', tip: '25–30 min, until a toothpick comes out clean', label: '🍮 Take it out!' },
      { title: 'Chill', say: 'Let it cool, then chill before serving. Tap the fridge to open and close the door ❄️', tip: 'Cool, then chill before serving' }
    ]
  },
  cupcake: {
    name: 'Vanilla Cupcakes', sub: 'Fluffy & prettily frosted',
    book: [
      { h: 'Ingredients', l: ['Cake flour 75 g', 'Baking powder 1/2 tsp', 'Eggs (large) ×3', 'Sugar 75 g', 'Fine salt 1/4 tsp', 'Water 38 g', 'Vanilla extract 1 tsp', 'Melted butter or vegetable oil 30 g'] },
      { h: 'Bake', l: ['Preheat the oven to 175°C', 'Bake for about 20–25 min', 'Fill each cup about 3/4 full', 'Cool on a rack, frost with buttercream or whipped cream'] }
    ],
    steps: [
      { title: 'Line the pan', say: 'First, put paper liners into the cupcake pan. Tap the cups! 🧁', tip: 'Paper liners into the cupcake pan' },
      { title: 'Preheat the oven', say: 'Turn the oven dial to 175°C and let it heat up!', tip: 'Preheat to 175°C' },
      { title: 'Measure the flour', say: 'Add 75 g of cake flour and 1/2 tsp of baking powder to the sieve 🌾', tip: 'Cake flour 75 g + baking powder 1/2 tsp', items: [{ n: 'Cake flour', amt: '75 g' }, { n: 'Baking powder', amt: '1/2 tsp' }] },
      { title: 'Sift the flour', say: "Sift the flour and baking powder together so it's light and airy~ Swipe left and right! ☁️", tip: 'Sift cake flour and baking powder together' },
      { title: 'Egg mixture', say: 'Crack 3 eggs into a new bowl, then add sugar, salt, water and vanilla~ 🥚', tip: '3 eggs · 75 g sugar · 1/4 tsp salt · 38 g water · 1 tsp vanilla', items: [{ n: 'Eggs', amt: '3 eggs' }, { n: 'Sugar', amt: '75 g' }, { n: 'Fine salt', amt: '1/4 tsp' }, { n: 'Water', amt: '38 g' }, { n: 'Vanilla extract', amt: '1 tsp' }] },
      { title: 'Whip until fluffy', say: 'Whip on high speed until pale and fluffy! Stir fast! 🌀', tip: 'High speed until thick, pale and fluffy' },
      { title: 'Flour & butter', say: 'Gently add the sifted flour, then the 30 g of melted butter 🧈', tip: 'Melted butter or vegetable oil 30 g', items: [{ n: 'Sifted flour', amt: '' }, { n: 'Melted butter', amt: '30 g' }] },
      { title: 'Fold gently', say: "Fold gently with a spatula until no flour streaks remain and it's smooth~", tip: 'Fold gently until no flour is visible' },
      { title: 'Fill the cups', say: 'Spoon the batter into the liners, about 3/4 full. Tap each one! 🥄', tip: 'Fill about 3/4 full' },
      { title: 'Bake the cupcakes', say: "Into the oven at 175°C for about 20–25 minutes. When they're risen and golden, take them out! 🧁", tip: '175°C for about 20–25 min', label: '🧁 Take them out!' },
      { title: 'Decorate', say: 'Cool on a rack, then top with pastel whipped cream 🍓', tip: 'Frost with buttercream or whipped cream' }
    ]
  },
  cookie: {
    name: 'Naughty Cookies', sub: 'Grumpy face, sweet heart 😈',
    book: [
      { h: 'Ingredients (about 40 cookies)', l: ['Salted butter 150 g (softened)', 'Icing sugar 80 g', 'Egg (large) ×1', 'All-purpose flour 150 g', 'Cornstarch 30 g', 'Milk powder 10 g (optional)', 'Vanilla extract 1 tsp'] },
      { h: 'Bake', l: ['Preheat to 160°C (top & bottom heat)', 'Bake about 15 min, until the edges turn golden', 'Cool on a rack, store in an airtight container'] }
    ],
    steps: [
      { title: 'Butter & sugar', say: 'Start with 150 g of softened salted butter and 80 g of icing sugar in the bowl~ 🧈', tip: 'Butter softened at room temp + icing sugar', items: [{ n: 'Salted butter', amt: '150 g' }, { n: 'Icing sugar', amt: '80 g' }] },
      { title: 'Cream the butter', say: 'Beat the butter and sugar until soft and fluffy! Stir fast — naughty cookies love fluffy butter 😈', tip: 'Beat butter 3–4 min, add icing sugar, beat 2 more min' },
      { title: 'Add the egg', say: 'Add 1 egg and 1 tsp of vanilla, then mix well 🥚', tip: '1 egg + 1 tsp vanilla', items: [{ n: 'Egg', amt: '1 egg' }, { n: 'Vanilla extract', amt: '1 tsp' }] },
      { title: 'Measure the flour', say: 'Add 150 g of flour, 30 g of cornstarch and 10 g of milk powder to the sieve 🌾', tip: 'All-purpose flour + cornstarch + milk powder', items: [{ n: 'All-purpose flour', amt: '150 g' }, { n: 'Cornstarch', amt: '30 g' }, { n: 'Milk powder', amt: '10 g' }] },
      { title: 'Sift the flour', say: 'Sift the flour into the butter mixture in 2–3 batches. Swipe left and right~ ☁️', tip: 'Sift in 2–3 batches' },
      { title: 'Fold gently', say: "Fold gently with a spatula just until combined. Don't overmix, or the cookies get tough! 😱", tip: "Don't overmix — cookies turn tough" },
      { title: 'Pipe the cookies', say: 'Pipe the dough onto a lined tray, one at a time. Little naughty cookies are being born~ 😈', tip: 'Pipe with a star tip, or roll balls and press with a fork' },
      { title: 'Preheat the oven', say: 'Turn the oven dial to 160°C (top & bottom heat)!', tip: 'Preheat to 160°C, top & bottom heat' },
      { title: 'Bake the cookies', say: "Bake about 15 minutes. When the edges turn golden, take them out fast! The window is short — don't burn them 🔥", tip: '160°C for about 15 min, until the edges are golden', label: '🍪 Take them out!' },
      { title: 'Cool down', say: 'Cool completely on a rack, then tap to pack them in an airtight jar so they stay crunchy~ ✨', tip: 'Store airtight to keep them crispy' }
    ]
  }
};
