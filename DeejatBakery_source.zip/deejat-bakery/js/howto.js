'use strict';
/* =====================================================================
   howto.js — แนะนำเกม + สอนเล่น (แบบสั้น เข้าใจง่าย)
   - HowTo : หน้าต่างแนะนำวิธีเล่น 3 หน้า ขึ้นเองทุกครั้งที่เข้าเกม (กด "เริ่มเกม" ครั้งแรกของการเปิดเกมแต่ละครั้ง)
               1) ยินดีต้อนรับ  2) ทำตามเชฟ (แตะ/ลาก/ถู)  3) กดตอนเข็มเขียว + หัวใจ
             เปลี่ยนหน้า: ปุ่มถัดไป / แตะจุด / ปัดซ้าย-ขวา / ปุ่มลูกศร ; ข้าม/ปิด = ไปหน้าเลือกเมนูต่อ
   - Tutor : สอนเล่นในด่านแรก (เมนู 1 คาราเมลคัสตาร์ด) เสมอจนกว่าจะผ่านด่านแรกได้ (ไม่มีตัวเลือกปิดในตั้งค่า)
             ด่าน 2 และ 3 ไม่สอน
   - Coach : มือ 👆 สาธิต (Tutor เรียกใช้ทุกขั้นในด่านแรก)
   ข้อความทั้งหมดอยู่ใน i18n.js (คีย์ ht.* และ tu.*)
   ===================================================================== */
const HowTo = {
  N: 3, i: 0, then: null, shown: false,

  /* ภาพสาธิตของแต่ละหน้า (CSS ล้วน ดู css/howto.css) */
  demo(i) {
    if (i === 0) return `<div class="ht-demo d-hi"><span class="cbox hi-chef">${charHTML(Settings.d.char, 'cheer')}</span><div class="hi-icons">${['custard', 'cupcake', 'cookie'].map(id => iconSVG(id)).join('')}</div></div>`;
    if (i === 1) return '<div class="ht-demo d-drag"><span class="dd-bowl">🥣</span><span class="dd-ing i1">🥚</span><span class="dd-ing i2">🍬</span><span class="dd-ing i3 nope">🌶️</span><span class="dd-fly">🥚</span><span class="hand">👆</span></div>';
    return `<div class="ht-demo d-time"><div class="dm-bar"><i class="dm-zone"></i><i class="dm-nd"></i></div><b class="dm-btn">${t('ht.press')}</b><span class="hand">👆</span><span class="dm-hearts">❤️❤️❤️</span></div>`;
  },

  /* วาดหน้าปัจจุบัน (เรียกซ้ำตอนเปลี่ยนหน้า/สลับภาษา) */
  render() {
    const i = this.i, last = i === this.N - 1;
    $('#ht-slides').innerHTML = `<section class="ht-slide">${this.demo(i)}<h3>${t('ht.' + i + '.t')}</h3><p>${t('ht.' + i + '.d')}</p></section>`;
    $('#ht-dots').innerHTML = Array.from({ length: this.N }, (_, k) =>
      `<button type="button" class="${k === i ? 'on' : ''}" data-i="${k}" aria-label="${k + 1} / ${this.N}"${k === i ? ' aria-current="step"' : ''}></button>`).join('');
    $('#ht-skip').textContent = t('ht.skip');
    $('#ht-skip').style.visibility = last ? 'hidden' : '';
    $('#ht-next').textContent = t(last ? 'ht.go' : 'ht.next');
  },
  go(i) {
    i = clamp(i, 0, this.N - 1);
    if (i === this.i) return;
    this.i = i; this.render(); Sound.play('pop');
  },

  /* then = ทำต่อหลังกด "ข้าม" / "เริ่มเลย" / ปิดหน้าต่าง (เช่น ไปหน้าเลือกเมนู) */
  open(then) {
    this.then = then || null; this.i = 0;
    this.shown = true;                                   // เปิดเกมครั้งนี้เห็นแล้ว (เปิดเกมใหม่ก็แนะนำใหม่)
    this.render();
    openModal('howto');
  },
  finish() { closeModals(); this.done(); },
  /* ทำต่อ (ครั้งเดียว) — closeModals เรียกด้วยเมื่อหน้าต่างนี้ถูกปิดด้วยวิธีอื่น */
  done() {
    const fn = this.then;
    this.then = null;
    if (fn) fn();
  },

  init() {
    $('#ht-next').onclick = () => { Sound.play('click'); this.i >= this.N - 1 ? this.finish() : this.go(this.i + 1); };
    $('#ht-skip').onclick = () => { Sound.play('click'); this.finish(); };
    $('#ht-dots').addEventListener('click', e => { const b = e.target.closest('button'); if (b) this.go(+b.dataset.i); });
    /* ปัดซ้าย-ขวาบนภาพเพื่อเปลี่ยนหน้า */
    const box = $('#ht-slides');
    let sx = null, sy = 0;
    box.addEventListener('pointerdown', e => { sx = e.clientX; sy = e.clientY; });
    box.addEventListener('pointerup', e => {
      if (sx == null) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      sx = null;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.2) this.go(this.i + (dx < 0 ? 1 : -1));
    });
    box.addEventListener('pointercancel', () => (sx = null));
    document.addEventListener('keydown', e => {
      if (!$('#howto.open')) return;
      if (e.key === 'ArrowRight') this.go(this.i + 1);
      else if (e.key === 'ArrowLeft') this.go(this.i - 1);
    });
  }
};

/* ---------- มือ 👆 สาธิตบนฉากจริงในครัว (ใช้ในด่านสอนเล่นเท่านั้น) ---------- */
const Coach = {
  el: null, timer: 0,

  init() {
    // ผู้เล่นแตะตรงไหนในครัวก็ได้ → มือ/ไฟส่องหายทันที (ไม่บังการเล่น)
    $('#screen-game').addEventListener('pointerdown', () => { this.hide(); Tutor.release(); }, true);
  },
  /* โชว์มือสาธิตท่าของขั้นนี้ ('' = ซ่อน) */
  force(type) {
    if (!type || !Env.motion) { this.hide(); return; }
    this._place(type);
  },

  _place(type) {
    this.hide();
    if (!Screens.is('game')) return;
    const host = $('#screen-game'), hr = host.getBoundingClientRect(), st = $('#stage').getBoundingClientRect();
    const mid = (r, fy = .5) => [r.left + r.width / 2, r.top + r.height * fy];
    let a = mid(st, .6), b = a;
    if (type === 'drag') {
      const ing = $('#shelf .ing[data-ok="1"]:not(.used)');
      if (!ing) return;
      a = mid(ing.getBoundingClientRect()); b = mid(st, .55);
    } else if (type === 'swipe') a = mid(st, .38);
    else if (type === 'tap') { const n = $('#stageSvg .tapT.next'); a = n ? mid(n.getBoundingClientRect(), .62) : mid(st, .6); }
    else if (type === 'timing') { const act = $('#act'); if (act.hidden) return; const r = act.getBoundingClientRect(); a = [r.left + r.width * .72, r.top + r.height * .55]; }
    const h = document.createElement('div');
    h.className = 'coach c-' + type; h.textContent = '👆'; h.setAttribute('aria-hidden', 'true');
    h.style.left = (a[0] - hr.left).toFixed(0) + 'px';
    h.style.top = (a[1] - hr.top).toFixed(0) + 'px';
    h.style.setProperty('--dx', (b[0] - a[0]).toFixed(0) + 'px');
    h.style.setProperty('--dy', (b[1] - a[1]).toFixed(0) + 'px');
    h.style.setProperty('--r', Math.round(st.width * .16) + 'px');
    host.appendChild(h);
    this.el = h;
    this.timer = setTimeout(() => this.hide(), 4200);
  },

  /* มือ 👆 แตะ ณ จุดหนึ่งบนจอ (พิกัด client) — ด่านฝึก: สอนปัดของแปลกปลอมชิ้นแรก */
  point(x, y) {
    this.hide();
    if (!Screens.is('game')) return;
    const host = $('#screen-game'), hr = host.getBoundingClientRect();
    const h = document.createElement('div');
    h.className = 'coach c-tap'; h.textContent = '👆'; h.setAttribute('aria-hidden', 'true');
    h.style.left = (x - hr.left).toFixed(0) + 'px';
    h.style.top = (y - hr.top + 16).toFixed(0) + 'px';
    host.appendChild(h);
    this.el = h;
    this.timer = setTimeout(() => this.hide(), 6000);
  },

  hide() {
    clearTimeout(this.timer);
    if (this.el) { this.el.remove(); this.el = null; }
  }
};

/* ---------- สอนเล่นในด่านแรก (เมนู 1 ตอนเล่นครั้งแรก) ----------
   ทุกขั้น: หรี่ไฟ ส่องจุดที่ต้องเล่น + ป้ายสั้น ๆ บอกว่าทำอะไร + มือ 👆 สาธิต
   แตะครั้งแรกในขั้นนั้น → ไฟส่องหายไป เล่นต่อเองได้เลย
   ระหว่างฝึก: ไม่เสียหัวใจ/ดาว, ไฮไลต์วัตถุดิบที่ถูกทันที, เข็มจับเวลาช้าลงนิดหน่อย
   แต่ขนมไหม้ หรือของแปลกปลอมตกใส่ขนม = แพ้ เริ่มใหม่เหมือนเล่นจริง (ของแปลกปลอมชิ้นแรกหยุดรอให้ลองปัดก่อน)
   ด่าน 2 และ 3 ไม่สอน ; สอนทุกครั้งจนกว่าจะผ่านด่านแรกได้ (ไม่มีตัวเลือกปิด) */
const Tutor = {
  on: false, spot: null, tip: null, st: null, phase: '',

  begin(id) {
    const first = Object.keys(RECIPES)[0];               // ด่านแรก = เมนูแรกในรายการ
    this.on = id === first && !Progress.best[id];
    document.body.classList.toggle('learn', this.on);
  },
  stop() {
    this.release();
    this.on = false;
    document.body.classList.remove('learn');
  },

  /* ป้ายสั้น ๆ ของขั้นนี้ (ตามภาษาที่เลือก) */
  text(st, phase) {
    switch (st.t) {
      case 'drag': return t('tu.drag', st.items.map(x => x.n).join(', '));
      case 'stir': return t(st.stir.gentle ? 'tu.stir.gentle' : 'tu.stir');
      case 'swipe': return t('tu.swipe');
      case 'tap': return st.tap.dial ? t('tu.tap.dial') : st.tap.door ? t('tu.tap.door') : t('tu.tap');
      case 'timing': return phase === 'zone' ? t('tu.press') : t('tu.wait');
    }
    return '';
  },

  step(st, phase = '') {
    if (!this.on || !Screens.is('game')) return;
    this.st = st; this.phase = phase;
    requestAnimationFrame(() => safeCall(() => this._show(st, phase), 'Tutor'));   // รอฉากจัดขนาดเสร็จก่อน
  },

  _show(st, phase) {
    if (!this.on || !Screens.is('game') || !G.r || G.r.steps[G.i] !== st || (G.busy && phase !== 'zone')) return;
    const target = st.t === 'drag' ? $('#shelf') : st.t === 'timing' ? $(phase === 'zone' ? '#act' : '#meter') : $('#stage');
    if (!target || !target.offsetParent) return;
    const host = $('#screen-game'), hr = host.getBoundingClientRect(), r = target.getBoundingClientRect(), pad = 8;
    if (!this.spot) {
      this.spot = document.createElement('div'); this.spot.className = 'spot'; this.spot.setAttribute('aria-hidden', 'true');
      this.tip = document.createElement('div'); this.tip.className = 'spot-tip'; this.tip.setAttribute('role', 'status');
      host.append(this.spot, this.tip);
    }
    const s = this.spot, tp = this.tip;
    s.style.left = (r.left - hr.left - pad).toFixed(0) + 'px';
    s.style.top = (r.top - hr.top - pad).toFixed(0) + 'px';
    s.style.width = (r.width + pad * 2).toFixed(0) + 'px';
    s.style.height = (r.height + pad * 2).toFixed(0) + 'px';
    tp.textContent = this.text(st, phase);
    // ป้ายอยู่ใต้จุดที่ส่อง (ถ้าจุดอยู่ครึ่งบน) หรือเหนือจุด (ถ้าอยู่ครึ่งล่าง) และไม่ล้นจอ
    const W = host.clientWidth, H = host.clientHeight, tw = tp.offsetWidth, th = tp.offsetHeight;
    const below = r.top - hr.top + r.height / 2 < H * .45;
    const y = below ? r.bottom - hr.top + pad + 14 : r.top - hr.top - pad - 14 - th;
    tp.style.left = clamp(r.left - hr.left + r.width / 2 - tw / 2, 8, Math.max(8, W - tw - 8)).toFixed(0) + 'px';
    tp.style.top = clamp(y, 8, Math.max(8, H - th - 8)).toFixed(0) + 'px';
    s.classList.add('on'); tp.classList.add('on');
    Coach.force(st.t === 'timing' ? (phase === 'zone' ? 'timing' : '') : st.t);
  },

  release() {
    if (this.spot) { this.spot.classList.remove('on'); this.tip.classList.remove('on'); }
  },
  /* กำลังส่องไฟสอนอยู่ไหม (แมลง/ชั้นเลื่อน รอจนผู้เล่นแตะก่อน) */
  lit() { return !!(this.on && this.spot && this.spot.classList.contains('on')); },

  init() {
    // หมุนจอ/เปลี่ยนขนาดจอระหว่างส่องไฟ → ย้ายไฟตามไปด้วย
    addEventListener('resize', () => {
      if (this.on && this.spot && this.spot.classList.contains('on')) setTimeout(() => safeCall(() => this._show(this.st, this.phase), 'Tutor'), 250);
    });
  }
};
