'use strict';
/* =====================================================================
   cookfx.js — ทำขนมให้สมจริงขึ้น: เอฟเฟกต์ตอนใส่วัตถุดิบ/เท/ร่อน
   - ของเหลว (น้ำ นม นมข้น วานิลลา น้ำร้อน เนยละลาย) : ภาชนะเอียงเท → สายน้ำไหลลง → ผิวกระเพื่อม
   - ไข่ : เคาะ → เปลือกแตกสองซีก → ไข่แดงหยดลง → กระเพื่อม
   - ผง (แป้ง น้ำตาล เกลือ ผงฟู น้ำตาลไอซิ่ง แป้งข้าวโพด นมผง) : โรยเป็นเม็ดเล็ก ๆ → ฝุ่นแป้งฟุ้ง
   - ของแข็ง (เนย ฯลฯ) : ตกตุ๋ม → น้ำกระเด็น → กระเพื่อม
   - ระดับในหม้อ/ชามค่อย ๆ สูงขึ้น และสีค่อย ๆ ผสมกัน (ไม่เปลี่ยนทันทีแบบเดิม)
   - เทลงถ้วย (คาราเมล/แป้งคัพเค้ก) มีสายเทลงถ้วยนั้น ; ร่อนแป้งมีฝุ่นฟุ้งที่ผิว
   ประสิทธิภาพ: เป็น HTML ลอยเหนือฉาก ขยับด้วย Web Animations (transform/opacity เท่านั้น) และลบตัวเองเมื่อจบ ;
   ระดับ/สีที่ค่อย ๆ เปลี่ยน วาดฉากผ่าน drawStage ที่แก้เฉพาะตัวเลขที่ต่าง ; ลดการเคลื่อนไหว = ไม่มีภาพ ใส่ผลทันที
   ===================================================================== */
const CF_LIQ = ['💧', '♨️', '🍼', '🌼', '🍯', '🧃', '🍶', '🥛'];
const CF_POW = ['🌾', '🍬', '🧂', '✨', '☁️', '🌽', '🍚'];
const CF_SND = { liquid: 'pour', egg: 'crack', powder: 'sprinkle', solid: 'splash' };

const CookFx = {
  raf: 0, tw: null, pend: null, pn: 0,

  /* ชนิดวัตถุดิบ (ดูจากอีโมจิ + ชื่อทั้งไทย/อังกฤษ เช่น "นมผง" เป็นผง, "เนยละลาย" เป็นของเหลว) */
  kind(it) {
    const e = it.e, n = (it.n || '') + ' ' + ((typeof ingOf === 'function' && ingOf(it.src)) || {}).n;
    if (e === '🥚') return 'egg';
    if (/ผง|powder/i.test(n)) return 'powder';
    if (/ละลาย|melted/i.test(n) || CF_LIQ.includes(e)) return 'liquid';
    if (CF_POW.includes(e)) return 'powder';
    return 'solid';
  },
  /* ระดับผิวของในภาชนะ (พิกัด viewBox 320×260 ตรงกับ stage.js) */
  surf(S, fill) {
    if (S.scene === 'pot') return 208 - fill * 84;
    if (S.scene === 'bowl') return 206 - fill * 88;
    return 150;
  },
  /* ค่าปลายทาง (ของที่ยังลอยอยู่/กำลังค่อย ๆ เปลี่ยน ใช้ค่าที่จะไปถึง → ใส่ของรัว ๆ ก็นับระดับถูก) */
  target(S) {
    const p = this.pend, w = this.tw;
    if (p && p.S === S) return { fill: p.f, liquid: p.c };
    return w && w.S === S ? { fill: w.f1, liquid: w.c1 } : { fill: S.fill, liquid: S.liquid };
  },

  /* โยนวัตถุดิบ: ของลอยจากการ์ดบนสายพานเป็นวงโค้งนุ่ม ๆ ไปเหนือหม้อ/ชาม แล้วค่อยเท/ตอก/โรย/ตกตุ๋ม (add)
     เห็นชัดว่าของที่แตะไปลงที่ไหน ; ชิ้นเดียวต่อครั้ง ไม่มีของอื่นปลิวพร้อมกัน → ไม่ลายตา */
  /* from = การ์ดที่แตะ (Element) หรือจุดที่ปล่อยนิ้วตอนลากมาใส่ [clientX, clientY] */
  toss(from, it, fillTo, colorTo) {
    const S = G.S, st = $('#stage'), src = from && from.nodeType === 1 ? (from.querySelector('.e') || from) : null;
    this.pend = { S, f: fillTo, c: colorTo || this.target(S).liquid };
    if (!Env.motion || !st || !(Array.isArray(from) || (src && src.isConnected))) { this.pend = null; this.add(it, fillTo, colorTo); return; }
    this.pn++;
    const sr = st.getBoundingClientRect(), { W, H } = this.geo();
    const fr = src ? src.getBoundingClientRect() : { left: from[0], top: from[1], width: 0, height: 0 };
    const x0 = fr.left + fr.width / 2 - sr.left, y0 = fr.top + fr.height / 2 - sr.top;
    // ลงตรงจุด (และขนาด) ที่ท่าเท/ตอก/โรย/ตกตุ๋มเริ่มพอดี → ต่อกันเนียน ไม่กระตุก
    const P = { liquid: [.63, -.16, .02, .12], egg: [.5, .02, 0, .14], powder: [.5, .015, 0, .11], solid: [.5, -.06, 0, .12] }[this.kind(it)];
    const x1 = W * P[0], y1 = H * P[1] + W * P[2], fs = W * P[3], top = Math.min(y0, y1) - H * .16;
    // แตะรัว ๆ: ของลอยไปทีละชิ้นห่างกันนิดนึง (ไม่พุ่ง/กระเด็นพร้อมกันทีเดียวจนลายตา)
    const now = performance.now(), delay = Math.max(0, (this.qAt || 0) - now);
    this.qAt = now + delay + 200;
    const d = this.el('cf-emo cf-toss', it.e, `font-size:${fs.toFixed(0)}px;margin:${(-fs / 2).toFixed(0)}px 0 0 ${(-fs / 2).toFixed(0)}px`);
    const a = this.run(d, [
      { transform: this.at(x0, y0, 'scale(.75)'), opacity: .9 },
      { transform: this.at(x0 + (x1 - x0) * .55, top, 'scale(1.08) rotate(-10deg)'), opacity: 1, offset: .55 },
      { transform: this.at(x1, y1, 'scale(1)'), opacity: 1 }
    ], { duration: 420, delay, easing: 'cubic-bezier(.35,.1,.45,1)' });
    let done = false;
    const land = () => {
      if (done) return;
      done = true; d.remove();
      if (--this.pn <= 0) { this.pn = 0; if (this.pend && this.pend.S === S) this.pend = null; }
      if (G.S === S && Screens.is('game')) this.add(it, fillTo, colorTo, true);
    };
    a.onfinish = land;
    setTimeout(land, delay + 700);                       // กันค้าง ถ้าเฟรมไม่ถูกวาด
  },

  /* ใส่วัตถุดิบ: เอฟเฟกต์ตามชนิด + เสียง + ค่อย ๆ เปลี่ยนระดับ/สีในภาชนะ (landed = ของเพิ่งลอยมาถึง ไม่ต้องค่อย ๆ โผล่) */
  add(it, fillTo, colorTo, landed) {
    const S = G.S, k = this.kind(it), go = Env.motion && !!$('#stage');
    Sound.play(CF_SND[k]);
    this._landed = !!landed;
    if (go) safeCall(() => this[k](it, colorTo || S.liquid, this.surf(S, fillTo)), 'CookFx');
    this._landed = false;
    this.tween(fillTo, colorTo, go ? 520 : 0, go ? { liquid: 140, egg: 300, powder: 200, solid: 260 }[k] : 0);
  },

  /* ---------- ระดับ/สีค่อย ๆ เปลี่ยน ---------- */
  tween(f1, c1, ms, delay) {
    const S = G.S;
    cancelAnimationFrame(this.raf); this.raf = 0;
    c1 = c1 || S.liquid;
    if (!ms) { this.tw = null; S.fill = f1; S.liquid = c1; requestDraw(); return; }
    const w = this.tw = { S, f0: S.fill, f1, c0: S.liquid, c1, t0: performance.now() + delay, ms, lf: S.fill, lc: S.liquid };
    const step = now => {
      this.raf = 0;
      if (this.tw !== w) return;
      // มีส่วนอื่นเปลี่ยนค่าเอง (จบขั้น/เริ่มเมนูใหม่) → หยุด ไม่เขียนทับ
      if (G.S !== S || S.fill !== w.lf || S.liquid !== w.lc) { this.tw = null; return; }
      const k = clamp((now - w.t0) / ms, 0, 1), e = k * (2 - k);
      S.fill = lerp(w.f0, w.f1, e); S.liquid = k >= 1 ? w.c1 : mix(w.c0, w.c1, e);
      w.lf = S.fill; w.lc = S.liquid;
      drawStage();
      if (k < 1) this.raf = requestAnimationFrame(step); else this.tw = null;
    };
    this.raf = requestAnimationFrame(step);
  },

  /* ---------- ชั้นเอฟเฟกต์เหนือฉาก ---------- */
  layer() {
    const st = $('#stage');
    let l = st.querySelector('.cookfx');
    if (!l) { l = document.createElement('div'); l.className = 'cookfx'; l.setAttribute('aria-hidden', 'true'); st.appendChild(l); }
    return l;
  },
  geo() { const st = $('#stage'); return { W: st.clientWidth || 300, H: st.clientHeight || 244 }; },
  el(cls, text, css) {
    const d = document.createElement('i');
    d.className = 'cf ' + cls;
    if (text) d.textContent = text;
    if (css) d.style.cssText = css;
    this.layer().appendChild(d);
    return d;
  },
  /* เล่นแอนิเมชันแล้วลบตัวเอง (กันค้าง: ลบตามเวลาด้วย ถ้าเครื่องหยุดวาดเฟรม) */
  run(d, frames, o) {
    const a = d.animate(frames, { fill: 'both', ...o }), end = () => d.remove();
    a.onfinish = end;
    setTimeout(end, (o.duration || 500) + (o.delay || 0) + 400);
    return a;
  },
  at(x, y, extra) { return `translate(${x.toFixed(1)}px,${y.toFixed(1)}px)${extra ? ' ' + extra : ''}`; },
  ripple(x, y, delay = 0) {
    const { W } = this.geo(), w = W * .38;
    [0, 150].forEach(d2 => {
      const r = this.el('cf-ring', '', `width:${w.toFixed(0)}px;height:${(w * .22).toFixed(0)}px;margin:${(-w * .11).toFixed(0)}px 0 0 ${(-w / 2).toFixed(0)}px`);
      this.run(r, [{ transform: this.at(x, y, 'scale(.2)'), opacity: .95 }, { transform: this.at(x, y, 'scale(1.15)'), opacity: 0 }],
        { duration: 680, delay: delay + d2, easing: 'ease-out' });
    });
  },

  /* ของเหลว: ภาชนะเอียงเท + สายน้ำ + กระเพื่อม */
  liquid(it, color, sY, x0) {
    const { W, H } = this.geo(), cx = x0 != null ? x0 : W * .5 + (Math.random() - .5) * W * .05;
    const top = -H * .16, y1 = sY / 260 * H, h = Math.max(20, y1 - top - 8), w = Math.max(6, W * .03);
    if (it) {
      const v = this.el('cf-emo', it.e, `font-size:${(W * .12).toFixed(0)}px`);
      this.run(v, [
        { transform: this.at(cx + W * .07, top - W * .04, 'rotate(0deg)'), opacity: this._landed ? 1 : 0 },
        { transform: this.at(cx + W * .07, top - W * .04, 'rotate(-115deg)'), opacity: 1, offset: .25 },
        { transform: this.at(cx + W * .07, top - W * .04, 'rotate(-115deg)'), opacity: 1, offset: .75 },
        { transform: this.at(cx + W * .1, top - W * .07, 'rotate(-10deg)'), opacity: 0 }
      ], { duration: 820, easing: 'ease-in-out' });
    }
    const s = this.el('cf-stream', '', `width:${w.toFixed(1)}px;height:${h.toFixed(0)}px;margin-left:${(-w / 2).toFixed(1)}px;background:${color}`);
    this.run(s, [
      { transform: this.at(cx, top + 8, 'scaleY(0)'), opacity: 1 },
      { transform: this.at(cx, top + 8, 'scaleY(1)'), opacity: 1, offset: .32 },
      { transform: this.at(cx, top + 8, 'scaleY(1)'), opacity: 1, offset: .7 },
      { transform: this.at(cx, top + 8 + h, 'scaleY(.02)'), opacity: .7 }
    ], { duration: 700, delay: 120, easing: 'linear' });
    this.ripple(cx, y1, 300);
  },

  /* ไข่: เคาะ → แตกสองซีก → ไข่แดงหยด */
  egg(it, color, sY) {
    const { W, H } = this.geo(), cx = W * .5, y0 = H * .02, y1 = sY / 260 * H, fs = W * .14;
    [['inset(0 50% 0 0)', -1], ['inset(0 0 0 50%)', 1]].forEach(([clip, s]) => {
      const half = this.el('cf-emo', '🥚', `font-size:${fs.toFixed(0)}px;margin:${(-fs / 2).toFixed(0)}px 0 0 ${(-fs / 2).toFixed(0)}px;clip-path:${clip};-webkit-clip-path:${clip}`);
      this.run(half, [
        { transform: this.at(cx, y0, 'rotate(0deg)') },
        { transform: this.at(cx, y0 + 4, 'rotate(-10deg)'), offset: .18 },
        { transform: this.at(cx, y0, 'rotate(8deg)'), offset: .3 },
        { transform: this.at(cx, y0, 'rotate(0deg)'), opacity: 1, offset: .38 },
        { transform: this.at(cx + s * W * .09, y0 - 6, `rotate(${s * 40}deg)`), opacity: 0 }
      ], { duration: 760, easing: 'ease-out' });
    });
    const d = W * .075;
    const yolk = this.el('cf-yolk', '', `width:${d.toFixed(0)}px;height:${d.toFixed(0)}px;margin:${(-d / 2).toFixed(0)}px 0 0 ${(-d / 2).toFixed(0)}px`);
    this.run(yolk, [
      { transform: this.at(cx, y0 + fs * .2, 'scale(.6)'), opacity: 0 },
      { transform: this.at(cx, y0 + fs * .25, 'scale(1)'), opacity: 1, offset: .15 },
      { transform: this.at(cx, y1, 'scale(1,1.15)'), opacity: 1, offset: .8 },
      { transform: this.at(cx, y1 + 2, 'scale(1.5,.4)'), opacity: 0 }
    ], { duration: 520, delay: 280, easing: 'ease-in' });
    this.ripple(cx, y1, 700);
  },

  /* ผง: โรยเม็ดเล็ก ๆ จากช้อน + ฝุ่นฟุ้งที่ผิว */
  powder(it, color, sY) {
    const { W, H } = this.geo(), cx = W * .5, y0 = H * .02, y1 = sY / 260 * H;
    if (it) {
      const v = this.el('cf-emo', it.e, `font-size:${(W * .11).toFixed(0)}px`);
      this.run(v, [
        { transform: this.at(cx - W * .05, y0 - W * .06, 'rotate(0deg)'), opacity: this._landed ? 1 : 0 },
        { transform: this.at(cx - W * .05, y0 - W * .06, 'rotate(-30deg)'), opacity: 1, offset: .2 },
        { transform: this.at(cx - W * .03, y0 - W * .06, 'rotate(-20deg)'), opacity: 1, offset: .5 },
        { transform: this.at(cx - W * .05, y0 - W * .06, 'rotate(-30deg)'), opacity: 1, offset: .75 },
        { transform: this.at(cx - W * .05, y0 - W * .1, 'rotate(0deg)'), opacity: 0 }
      ], { duration: 800 });
    }
    const n = Env.lite ? 7 : 12;
    for (let i = 0; i < n; i++) {
      const g = this.el('cf-grain', '', `background:${color}`);
      const xs = cx + (Math.random() - .5) * W * .08, xe = cx + (Math.random() - .5) * W * .34, ye = y1 + (Math.random() - .5) * 6;
      this.run(g, [{ transform: this.at(xs, y0 + W * .02), opacity: 0 }, { transform: this.at(xs, y0 + W * .03), opacity: 1, offset: .1 },
        { transform: this.at(xe, ye), opacity: .9 }], { duration: 420 + Math.random() * 220, delay: 120 + i * 26, easing: 'ease-in' });
    }
    this.puff(cx, y1, 420);
  },
  puff(x, y, delay = 0) {
    const { W } = this.geo(), w = W * .3;
    const p = this.el('cf-puff', '', `width:${w.toFixed(0)}px;height:${(w * .55).toFixed(0)}px;margin:${(-w * .4).toFixed(0)}px 0 0 ${(-w / 2).toFixed(0)}px`);
    this.run(p, [{ transform: this.at(x, y, 'scale(.3)'), opacity: .95 }, { transform: this.at(x, y - w * .25, 'scale(1.3)'), opacity: 0 }],
      { duration: 720, delay, easing: 'ease-out' });
  },

  /* ของแข็ง: ตกตุ๋ม + น้ำกระเด็น */
  solid(it, color, sY) {
    const { W, H } = this.geo(), cx = W * .5 + (Math.random() - .5) * W * .06, y0 = -H * .06, y1 = sY / 260 * H, fs = W * .12;
    const o = this.el('cf-emo', it.e, `font-size:${fs.toFixed(0)}px;margin:${(-fs / 2).toFixed(0)}px 0 0 ${(-fs / 2).toFixed(0)}px`);
    this.run(o, [
      { transform: this.at(cx, y0, 'rotate(-20deg) scale(1.1)'), opacity: 1 },
      { transform: this.at(cx, y1 - fs * .2, 'rotate(15deg) scale(1)'), opacity: 1, offset: .75 },
      { transform: this.at(cx, y1 + fs * .1, 'rotate(20deg) scale(.4,.25)'), opacity: 0 }
    ], { duration: 560, easing: 'ease-in' });
    for (let i = 0; i < 5; i++) {
      const dx = (i - 2) * W * .045 + (Math.random() - .5) * 6, up = H * (.07 + Math.random() * .08), d = 5 + Math.random() * 4;
      const dr = this.el('cf-drop', '', `width:${d.toFixed(0)}px;height:${d.toFixed(0)}px;background:${color}`);
      this.run(dr, [{ transform: this.at(cx, y1), opacity: 1 }, { transform: this.at(cx + dx * .7, y1 - up), opacity: 1, offset: .45, easing: 'ease-in' },
        { transform: this.at(cx + dx, y1 + 4), opacity: 0 }], { duration: 560, delay: 400, easing: 'ease-out' });
    }
    this.ripple(cx, y1, 420);
  },

  /* เทลงถ้วยที่ i (ขั้นแตะ: คาราเมล/แป้ง) — พิกัดเดียวกับ cupsSVG ใน stage.js */
  pourCup(i, n, color) {
    if (!Env.motion || !$('#stage')) return;
    const xs = n === 3 ? [60, 160, 260] : [50, 125, 200, 275], { W } = this.geo();
    const x = (xs[i] != null ? xs[i] : 160) / 320 * W;
    safeCall(() => this.liquid(null, color, 150, x), 'CookFx.cup');
  },
  /* ร่อนแป้ง: ฝุ่นฟุ้งที่ผิวในชาม */
  dust(S) {
    if (!Env.motion || !$('#stage')) return;
    const { W, H } = this.geo();
    safeCall(() => this.puff(W * .5 + (Math.random() - .5) * W * .12, this.surf(S, S.fill) / 260 * H), 'CookFx.dust');
  },

  /* เริ่มขั้นใหม่: ระดับ/สีที่ยังค่อย ๆ เปลี่ยนอยู่ → ไปถึงค่าสุดท้ายทันที (ขั้นถัดไปเริ่มจากค่าที่ถูกต้องเสมอ) */
  settle() {
    const w = this.tw;
    cancelAnimationFrame(this.raf); this.raf = 0; this.tw = null;
    if (w && G.S === w.S && w.S.fill === w.lf && w.S.liquid === w.lc) { w.S.fill = w.f1; w.S.liquid = w.c1; }
  },

  /* ออกจากครัว/เริ่มเมนูใหม่: หยุดการเปลี่ยนค่า ลบเอฟเฟกต์ที่ค้าง */
  stop() {
    cancelAnimationFrame(this.raf); this.raf = 0; this.tw = null; this.pend = null; this.pn = 0; this.qAt = 0;
    $$('#stage .cookfx .cf').forEach(d => d.remove());
  }
};
